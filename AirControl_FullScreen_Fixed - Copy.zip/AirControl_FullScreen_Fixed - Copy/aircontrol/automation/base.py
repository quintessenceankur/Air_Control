"""The desktop-automation boundary.

Everything that touches the operating system sits behind
:class:`ActionExecutor`. Tests substitute
:class:`aircontrol.automation.recorder.RecordingExecutor`, so no automated
test ever moves a real cursor or types a real key.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


class ExecutorUnavailable(RuntimeError):
    """Raised when the platform backend cannot be loaded.

    On Windows this means ``pynput`` failed to import; everywhere else it is
    the expected state, and the UI shows gesture control as unavailable
    instead of crashing.
    """


@runtime_checkable
class ActionExecutor(Protocol):
    """OS effects AirControl is allowed to perform.

    Deliberately small: keys, media keys, pointer movement, clicks, scroll
    and window focus. No shell, no file system, no network.
    """

    def send_key(self, combo: str) -> None:
        """Press and release a key or key combination, e.g. ``"right"``,
        ``"ctrl+alt+a"``."""

    def media_key(self, name: str) -> None:
        """Fire a system media key: play_pause, next, previous, volume_up,
        volume_down, mute."""

    def move_mouse(self, dx: int, dy: int) -> None:
        """Move the pointer by a relative offset."""

    def move_mouse_to(self, x: int, y: int) -> None:
        """Move the pointer to an absolute screen position."""

    def click(self, button: str = "left", double: bool = False) -> None:
        """Click a mouse button."""

    def mouse_down(self, button: str = "left") -> None:
        """Press and hold a mouse button (drag start)."""

    def mouse_up(self, button: str = "left") -> None:
        """Release a mouse button (drag end)."""

    def scroll(self, amount: int) -> None:
        """Scroll vertically; positive is up."""

    def focus_window(self, title_pattern: str) -> bool:
        """Bring a window to the front; ``False`` when it is not found."""


class NullExecutor:
    """Executor that does nothing and records the fact.

    Used when gesture control is disabled, when the platform backend is
    unavailable, and in ``--selftest`` runs. It keeps every caller free of
    ``if executor is None`` branches.
    """

    def __init__(self) -> None:
        self.suppressed = 0

    def _noop(self, *_args, **_kwargs) -> None:
        self.suppressed += 1

    def send_key(self, combo: str) -> None:  # noqa: D102 - see protocol
        self._noop(combo)

    def media_key(self, name: str) -> None:  # noqa: D102
        self._noop(name)

    def move_mouse(self, dx: int, dy: int) -> None:  # noqa: D102
        self._noop(dx, dy)

    def move_mouse_to(self, x: int, y: int) -> None:  # noqa: D102
        self._noop(x, y)

    def click(self, button: str = "left", double: bool = False) -> None:  # noqa: D102
        self._noop(button, double)

    def mouse_down(self, button: str = "left") -> None:  # noqa: D102
        self._noop(button)

    def mouse_up(self, button: str = "left") -> None:  # noqa: D102
        self._noop(button)

    def scroll(self, amount: int) -> None:  # noqa: D102
        self._noop(amount)

    def focus_window(self, title_pattern: str) -> bool:  # noqa: D102
        self._noop(title_pattern)
        return False
