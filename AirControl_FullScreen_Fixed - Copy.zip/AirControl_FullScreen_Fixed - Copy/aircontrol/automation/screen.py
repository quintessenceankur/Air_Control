"""Screen bounds in the coordinate space the mouse injector actually uses.

Why this module exists
----------------------
Qt reports geometry in *logical* pixels (device-independent), while a mouse
injector writes *device* coordinates. On a 125% display those differ by the
device pixel ratio: Qt says 1536x864, the desktop is 1920x1080. Passing Qt's
number to a mapping routine that feeds ``SetCursorPos`` caps the cursor at 80%
of the desktop, which is exactly the "cannot reach the taskbar" symptom.

The fix cannot simply multiply by ``devicePixelRatio`` either, because the
correct space depends on the process DPI awareness: a DPI-unaware process gets
virtualised (scaled) coordinates from *both* ``GetSystemMetrics`` and
``SetCursorPos``, and multiplying would then overshoot.

So the space is queried from the same API family the injector uses.
``GetSystemMetrics(SM_CXSCREEN/SM_CYSCREEN)`` is virtualised by Windows in
exactly the same way as ``SetCursorPos``, for both awareness modes, so the two
always agree. Qt is kept as a fallback for platforms without Win32.

Multi-monitor: this reports the **primary** monitor only. AirControl maps the
primary screen; the virtual desktop spanning several monitors is not
supported (documented in docs/ARCHITECTURE.md).
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any, Protocol

log = logging.getLogger(__name__)

#: Win32 ``GetSystemMetrics`` indices.
SM_CXSCREEN = 0
SM_CYSCREEN = 1
SM_XVIRTUALSCREEN = 76
SM_YVIRTUALSCREEN = 77
SM_CXVIRTUALSCREEN = 78
SM_CYVIRTUALSCREEN = 79


@dataclass(frozen=True)
class ScreenBounds:
    """A rectangular pixel space, with the top-left pixel at the origin."""

    width: int
    height: int
    origin_x: int = 0
    origin_y: int = 0
    source: str = "unknown"

    def __post_init__(self) -> None:
        if self.width < 1 or self.height < 1:
            raise ValueError(f"invalid screen size {self.width}x{self.height}")

    @property
    def max_x(self) -> int:
        """Largest addressable x (width - 1)."""
        return self.origin_x + self.width - 1

    @property
    def max_y(self) -> int:
        return self.origin_y + self.height - 1

    def as_tuple(self) -> tuple[int, int]:
        return (self.width, self.height)

    def clamp(self, x: float, y: float) -> tuple[int, int]:
        """Clamp a pixel position into this space and round it."""
        cx = min(self.max_x, max(self.origin_x, int(round(x))))
        cy = min(self.max_y, max(self.origin_y, int(round(y))))
        return (cx, cy)

    def contains(self, x: float, y: float, tolerance: float = 0.5) -> bool:
        return (self.origin_x - tolerance <= x <= self.max_x + tolerance
                and self.origin_y - tolerance <= y <= self.max_y + tolerance)

    def describe(self) -> str:
        return (f"{self.width}x{self.height} at ({self.origin_x},{self.origin_y}) "
                f"[{self.source}]")


class _QtScreen(Protocol):  # pragma: no cover - structural typing only
    def geometry(self) -> Any: ...

    def devicePixelRatio(self) -> float: ...


def query_primary_screen() -> ScreenBounds | None:
    """Primary monitor size in the injector's coordinate space (Windows only).

    Returns ``None`` on other platforms or if the query fails, so callers can
    fall back to Qt.
    """
    if os.name != "nt":
        return None
    try:  # pragma: no cover - exercised on Windows only
        import ctypes

        user32 = ctypes.windll.user32
        width = int(user32.GetSystemMetrics(SM_CXSCREEN))
        height = int(user32.GetSystemMetrics(SM_CYSCREEN))
        if width <= 0 or height <= 0:
            return None
        return ScreenBounds(width, height, source="win32 GetSystemMetrics")
    except Exception as exc:  # pragma: no cover - defensive
        log.debug("GetSystemMetrics failed: %s", exc)
        return None


def virtual_desktop_size() -> tuple[int, int, int, int] | None:
    """``(x, y, width, height)`` of the whole virtual desktop, or ``None``.

    Used only to warn when several monitors are attached: AirControl maps the
    primary monitor, so a user with a second display should know that.
    """
    if os.name != "nt":
        return None
    try:  # pragma: no cover - exercised on Windows only
        import ctypes

        user32 = ctypes.windll.user32
        x = int(user32.GetSystemMetrics(SM_XVIRTUALSCREEN))
        y = int(user32.GetSystemMetrics(SM_YVIRTUALSCREEN))
        width = int(user32.GetSystemMetrics(SM_CXVIRTUALSCREEN))
        height = int(user32.GetSystemMetrics(SM_CYVIRTUALSCREEN))
        if width <= 0 or height <= 0:
            return None
        return (x, y, width, height)
    except Exception:  # pragma: no cover - defensive
        return None


def bounds_from_qt(screen: _QtScreen | None) -> ScreenBounds | None:
    """Physical pixel bounds derived from a Qt screen.

    ``geometry()`` is logical; multiplying by the device pixel ratio gives the
    physical size. On a DPI-unaware process Qt already reports physical pixels
    and the ratio is 1.0, so the result is right in both cases.
    """
    if screen is None:
        return None
    try:
        geometry = screen.geometry()
        ratio = float(screen.devicePixelRatio() or 1.0)
        width = int(round(geometry.width() * ratio))
        height = int(round(geometry.height() * ratio))
        if width <= 0 or height <= 0:
            return None
        return ScreenBounds(width, height, source=f"qt geometry x{ratio:g} dpr")
    except Exception as exc:  # pragma: no cover - defensive
        log.debug("could not read Qt screen geometry: %s", exc)
        return None


def resolve_screen_bounds(screen: _QtScreen | None = None,
                          fallback: tuple[int, int] = (1920, 1080)) -> ScreenBounds:
    """Best available bounds: Win32 first, then Qt, then a safe default.

    Win32 wins because it is the space the injector writes to. Qt is a
    fallback for platforms without Win32 (development on Linux, where actions
    are suppressed anyway).
    """
    bounds = query_primary_screen()
    if bounds is not None:
        return bounds
    bounds = bounds_from_qt(screen)
    if bounds is not None:
        return bounds
    log.warning("could not determine the screen size; assuming %sx%s", *fallback)
    return ScreenBounds(fallback[0], fallback[1], source="fallback default")


def describe_environment(screen: _QtScreen | None) -> list[str]:
    """Diagnostic lines for the log: every coordinate space we know about."""
    lines: list[str] = []
    if screen is not None:
        try:
            geometry = screen.geometry()
            ratio = float(screen.devicePixelRatio() or 1.0)
            available = screen.availableGeometry()
            lines.append(
                f"qt geometry {geometry.width()}x{geometry.height()} logical, "
                f"available {available.width()}x{available.height()}, "
                f"dpr {ratio:g} -> physical "
                f"{int(round(geometry.width() * ratio))}x"
                f"{int(round(geometry.height() * ratio))}")
        except Exception:  # pragma: no cover - defensive
            pass
    bounds = query_primary_screen()
    if bounds is not None:
        lines.append(f"injector space {bounds.describe()}")
    virtual = virtual_desktop_size()
    if virtual is not None:
        x, y, width, height = virtual
        lines.append(f"virtual desktop {width}x{height} at ({x},{y})")
        if bounds is not None and (width, height) != bounds.as_tuple():
            lines.append(
                "NOTE: multiple monitors detected; AirControl maps the primary "
                "monitor only")
    return lines
