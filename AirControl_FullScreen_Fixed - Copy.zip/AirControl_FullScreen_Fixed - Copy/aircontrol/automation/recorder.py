"""Test double: an executor that records calls instead of touching the OS.

Every end-to-end test asserts on this recorder, which is what guarantees the
test suite never moves a real cursor or types a real key.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Call:
    method: str
    args: tuple = ()
    kwargs: dict = field(default_factory=dict)

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"Call({self.method}{self.args})"


class RecordingExecutor:
    """Implements the executor interface by appending to :attr:`calls`."""

    def __init__(self) -> None:
        self.calls: list[Call] = []

    # -- executor interface ---------------------------------------------------
    def send_key(self, combo: str) -> None:
        self.calls.append(Call("send_key", (combo,)))

    def media_key(self, name: str) -> None:
        self.calls.append(Call("media_key", (name,)))

    def move_mouse(self, dx: int, dy: int) -> None:
        self.calls.append(Call("move_mouse", (dx, dy)))

    def move_mouse_to(self, x: int, y: int) -> None:
        self.calls.append(Call("move_mouse_to", (x, y)))

    def click(self, button: str = "left", double: bool = False) -> None:
        self.calls.append(Call("click", (button, double)))

    def mouse_down(self, button: str = "left") -> None:
        self.calls.append(Call("mouse_down", (button,)))

    def mouse_up(self, button: str = "left") -> None:
        self.calls.append(Call("mouse_up", (button,)))

    def scroll(self, amount: int) -> None:
        self.calls.append(Call("scroll", (amount,)))

    def focus_window(self, title_pattern: str) -> bool:
        self.calls.append(Call("focus_window", (title_pattern,)))
        return True

    # -- test helpers ---------------------------------------------------------
    def clear(self) -> None:
        self.calls.clear()

    def methods(self) -> list[str]:
        return [c.method for c in self.calls]

    def of(self, method: str) -> list[Call]:
        return [c for c in self.calls if c.method == method]

    def __len__(self) -> int:
        return len(self.calls)
