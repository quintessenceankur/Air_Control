
"""Keyboard and media-key injection (Windows backend via ``pynput``).

Imported lazily: :mod:`aircontrol.automation.base` and every test path stay
free of ``pynput``, which on Linux needs ``evdev`` and would otherwise make
the suite uninstallable there.
"""

from __future__ import annotations

import logging

from aircontrol.automation.base import ExecutorUnavailable

log = logging.getLogger(__name__)

#: Media action names (from ``core.actions.MEDIA_TARGETS``) to pynput keys.
MEDIA_KEYS: dict[str, str] = {
    "play_pause": "media_play_pause",
    "next": "media_next",
    "previous": "media_previous",
    "volume_up": "media_volume_up",
    "volume_down": "media_volume_down",
    "mute": "media_volume_mute",
}

#: Presentation action names to key names.
PRESENTATION_KEYS: dict[str, str] = {
    "next_slide": "right",
    "previous_slide": "left",
    "start_presentation": "f5",
    "exit_presentation": "escape",
}

#: Modifier aliases accepted in a key combo.
_MODIFIERS = {
    "ctrl": "ctrl",
    "control": "ctrl",
    "alt": "alt",
    "shift": "shift",
    "win": "cmd",
    "cmd": "cmd",
    "super": "cmd",
}

#: Key aliases accepted by the keyboard resolver.
_KEY_ALIASES = {
    "escape": "esc",
    "return": "enter",
}


class KeyboardExecutor:
    """Sends key presses and media keys through ``pynput``."""

    def __init__(self) -> None:
        try:
            from pynput.keyboard import Controller, Key  # noqa: WPS433 (lazy)
        except Exception as exc:  # pragma: no cover - platform dependent
            raise ExecutorUnavailable(
                f"keyboard backend unavailable: {exc}"
            ) from exc

        self._controller = Controller()
        self._key = Key

    # -- public API ---------------------------------------------------------

    def send_key(self, combo: str) -> None:
        """Press ``combo`` (e.g. ``"right"``, ``"ctrl+alt+a"``)."""
        modifiers, key = self._parse(combo)

        for modifier in modifiers:
            self._controller.press(modifier)

        try:
            self._controller.press(key)
            self._controller.release(key)
        finally:
            for modifier in reversed(modifiers):
                self._controller.release(modifier)

    def media_key(self, name: str) -> None:
        """Fire a media key by action name."""
        attribute = MEDIA_KEYS.get(name)

        if attribute is None:
            raise ValueError(f"unknown media key {name!r}")

        key = getattr(self._key, attribute, None)

        if key is None:  # pragma: no cover - old pynput builds
            raise ExecutorUnavailable(
                f"pynput has no {attribute} key"
            )

        self._controller.press(key)
        self._controller.release(key)

    def presentation_key(self, action: str) -> None:
        """Map a presentation action to its slide-navigation key."""
        if action not in PRESENTATION_KEYS:
            raise ValueError(f"unknown presentation action {action!r}")

        self.send_key(PRESENTATION_KEYS[action])

    # -- internals ----------------------------------------------------------

    def _parse(self, combo: str) -> tuple[list, object]:
        parts = [
            part.strip().lower()
            for part in combo.split("+")
            if part.strip()
        ]

        if not parts:
            raise ValueError("empty key combo")

        modifiers = []

        for part in parts[:-1]:
            name = _MODIFIERS.get(part)

            if name is None:
                raise ValueError(
                    f"unknown modifier {part!r} in {combo!r}"
                )

            modifiers.append(getattr(self._key, name))

        return modifiers, self._resolve(parts[-1])

    def _resolve(self, name: str) -> object:
        """Resolve a key name, including common aliases."""

        name = name.strip().lower()
        name = _KEY_ALIASES.get(name, name)

        if len(name) == 1:
            return name

        key = getattr(self._key, name, None)

        if key is None:
            raise ValueError(f"unknown key {name!r}")

        return key
