"""The real Windows executor: keyboard + mouse + window focus.

:class:`SystemExecutor` is the only object in the application allowed to
produce OS input events. It is created once, in the UI layer, and handed to
the controllers behind the :class:`~aircontrol.automation.base.ActionExecutor`
protocol.
"""

from __future__ import annotations

import logging
import os

from aircontrol.automation.base import ExecutorUnavailable
from aircontrol.automation.keyboard import PRESENTATION_KEYS, KeyboardExecutor
from aircontrol.automation.mouse import MouseExecutor

log = logging.getLogger(__name__)


class SystemExecutor:
    """Facade over the platform keyboard and mouse backends."""

    def __init__(self) -> None:
        self.keyboard = KeyboardExecutor()
        self.mouse = MouseExecutor()

    # -- keyboard -----------------------------------------------------------
    def send_key(self, combo: str) -> None:
        # Presentation actions are named in the binding table, not as keys.
        if combo in PRESENTATION_KEYS:
            combo = PRESENTATION_KEYS[combo]
        self.keyboard.send_key(combo)

    def media_key(self, name: str) -> None:
        self.keyboard.media_key(name)

    # -- mouse --------------------------------------------------------------
    def move_mouse(self, dx: int, dy: int) -> None:
        self.mouse.move_mouse(dx, dy)

    def move_mouse_to(self, x: int, y: int) -> None:
        self.mouse.move_mouse_to(x, y)

    def click(self, button: str = "left", double: bool = False) -> None:
        self.mouse.click(button, double)

    def mouse_down(self, button: str = "left") -> None:
        self.mouse.mouse_down(button)

    def mouse_up(self, button: str = "left") -> None:
        self.mouse.mouse_up(button)

    def scroll(self, amount: int) -> None:
        self.mouse.scroll(amount)

    def screen_size(self) -> tuple[int, int]:
        return self.mouse.screen_size()

    # -- windows ------------------------------------------------------------
    def focus_window(self, title_pattern: str) -> bool:
        """Bring the first window whose title contains ``title_pattern`` up.

        Uses ``ctypes`` against ``user32`` so the app does not depend on
        pywin32. Returns ``False`` on any non-Windows platform or when no
        window matches.
        """
        if os.name != "nt":  # pragma: no cover - exercised on Windows only
            return False
        try:  # pragma: no cover - Windows only
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.windll.user32
            match = []

            @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
            def _callback(hwnd, _lparam):
                length = user32.GetWindowTextLengthW(hwnd)
                if length:
                    buffer = ctypes.create_unicode_buffer(length + 1)
                    user32.GetWindowTextW(hwnd, buffer, length + 1)
                    if title_pattern.lower() in buffer.value.lower():
                        match.append(hwnd)
                        return False
                return True

            user32.EnumWindows(_callback, 0)
            if not match:
                return False
            user32.ShowWindow(match[0], 9)  # SW_RESTORE
            user32.SetForegroundWindow(match[0])
            return True
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("focus_window failed: %s", exc)
            return False


def build_executor():
    """Return a working executor, or ``None`` when the backend is missing.

    The caller decides what to show the user; this function never raises for
    an unavailable platform, because a missing backend on Linux is normal
    during development.
    """
    try:
        return SystemExecutor()
    except ExecutorUnavailable as exc:
        log.warning("desktop automation unavailable: %s", exc)
        return None
