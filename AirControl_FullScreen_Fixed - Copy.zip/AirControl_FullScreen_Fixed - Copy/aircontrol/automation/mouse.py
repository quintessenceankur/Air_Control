"""Mouse injection (Windows backend via ``pynput``)."""

from __future__ import annotations

import logging

from aircontrol.automation.base import ExecutorUnavailable

log = logging.getLogger(__name__)

_BUTTONS = {"left": "left", "right": "right", "middle": "middle"}


class MouseExecutor:
    """Absolute and relative pointer movement, clicks, drags and scroll."""

    def __init__(self) -> None:
        try:
            from pynput.mouse import Button, Controller  # noqa: WPS433 (lazy)
        except Exception as exc:  # pragma: no cover - platform dependent
            raise ExecutorUnavailable(f"mouse backend unavailable: {exc}") from exc
        self._controller = Controller()
        self._button_enum = Button

    def screen_size(self) -> tuple[int, int]:
        """Primary screen size in the space ``SetCursorPos`` writes to.

        Previously this returned ``Controller().position`` -- the *cursor
        position*, not a screen size -- so any caller that clamped to it was
        clamping to a point. It now asks Win32 for the real metrics, which are
        virtualised the same way as the injector (see
        :mod:`aircontrol.automation.screen`).
        """
        from aircontrol.automation.screen import query_primary_screen

        bounds = query_primary_screen()
        if bounds is not None:
            return bounds.as_tuple()
        log.debug("screen size unavailable on this platform; assuming 1920x1080")
        return (1920, 1080)

    def move_mouse(self, dx: int, dy: int) -> None:
        self._controller.move(int(dx), int(dy))

    def move_mouse_to(self, x: int, y: int) -> None:
        self._controller.position = (int(x), int(y))

    def click(self, button: str = "left", double: bool = False) -> None:
        self._controller.click(self._button(button), 2 if double else 1)

    def mouse_down(self, button: str = "left") -> None:
        self._controller.press(self._button(button))

    def mouse_up(self, button: str = "left") -> None:
        self._controller.release(self._button(button))

    def scroll(self, amount: int) -> None:
        self._controller.scroll(0, int(amount))

    def _button(self, name: str):
        key = _BUTTONS.get(name)
        if key is None:
            raise ValueError(f"unknown mouse button {name!r}")
        return getattr(self._button_enum, key)
