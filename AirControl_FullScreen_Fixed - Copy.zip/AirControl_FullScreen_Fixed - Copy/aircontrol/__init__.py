"""AirControl -- gesture control for the Windows desktop."""

__version__ = "1.0.1"
APP_NAME = "AirControl"
