"""Frame and landmark painting.

Converts a BGR OpenCV frame to a :class:`QImage` and paints the hand skeleton
plus a small HUD. All Qt work happens here; the vision and core layers stay
free of it.
"""

from __future__ import annotations

import numpy as np
from PySide6.QtCore import QPointF, QRect, Qt
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPen, QPolygonF

from aircontrol.core.gestures.events import RecognitionState
from aircontrol.core.landmarks import HAND_CONNECTIONS, HandFrame
from aircontrol.ui.theme import PALETTE


def frame_to_qimage(frame: np.ndarray) -> QImage:
    """Convert a BGR ``numpy`` frame to a standalone QImage (deep copy)."""
    if frame is None or frame.size == 0:
        raise ValueError("empty frame")
    if frame.ndim == 2:
        rgb = np.stack([frame] * 3, axis=-1)
    else:
        rgb = frame[:, :, ::-1]
    rgb = np.ascontiguousarray(rgb)
    height, width, channels = rgb.shape
    image = QImage(rgb.data, width, height, channels * width,
                   QImage.Format_RGB888)
    return image.copy()  # detach from the numpy buffer


def draw_landmarks(painter: QPainter, hand: HandFrame, width: int, height: int,
                   colour: str = PALETTE.success) -> None:
    """Draw one hand's 21 landmarks and the bone connections."""
    points = [QPointF(p.x * width, p.y * height) for p in hand.landmarks]
    if len(points) != 21:
        return
    painter.setPen(QPen(QColor(colour), 2))
    for start, end in HAND_CONNECTIONS:
        painter.drawLine(points[start], points[end])
    painter.setPen(Qt.NoPen)
    painter.setBrush(QColor(colour))
    for index, point in enumerate(points):
        radius = 5.0 if index in (0, 4, 8, 12, 16, 20) else 3.0
        painter.drawEllipse(point, radius, radius)
    # Fingertips get a ring so the pointer finger is easy to see.
    painter.setBrush(Qt.NoBrush)
    painter.setPen(QPen(QColor(PALETTE.accent), 2))
    painter.drawEllipse(points[8], 9, 9)


def draw_hud(painter: QPainter, state: RecognitionState, width: int, height: int,
             *, fps: float = 0.0, mode_label: str = "") -> None:
    """Gesture label, confidence and tracking status in the top-left corner."""
    painter.setRenderHint(QPainter.Antialiasing, True)
    box = QRect(14, 14, 268, 84)
    painter.setPen(Qt.NoPen)
    painter.setBrush(QColor(10, 14, 21, 190))
    painter.drawRoundedRect(box, 12, 12)

    gesture = state.stable or ("No gesture" if state.tracking else "No hand")
    colour = PALETTE.success if state.stable else PALETTE.text_muted
    font = QFont("Segoe UI", 13)
    font.setBold(True)
    painter.setFont(font)
    painter.setPen(QColor(colour))
    painter.drawText(QRect(28, 24, 240, 22), Qt.AlignLeft | Qt.AlignVCenter,
                     gesture.replace("_", " ").title())

    small = QFont("Segoe UI", 9)
    painter.setFont(small)
    painter.setPen(QColor(PALETTE.text_muted))
    confidence = f"confidence {state.confidence:.2f}" if state.tracking else "waiting for a hand"
    painter.drawText(QRect(28, 46, 240, 18), Qt.AlignLeft, confidence)

    # Confidence meter.
    bar = QRect(28, 70, 240, 6)
    painter.setBrush(QColor(PALETTE.surface_alt))
    painter.drawRoundedRect(bar, 3, 3)
    filled = QRect(28, 70, int(240 * max(0.0, min(1.0, state.confidence))), 6)
    painter.setBrush(QColor(colour))
    painter.drawRoundedRect(filled, 3, 3)

    if fps or mode_label:
        text = "  ".join(part for part in (
            f"{fps:.0f} fps" if fps else "", mode_label) if part)
        painter.setPen(QColor(PALETTE.text_muted))
        painter.drawText(QRect(width - 200, height - 30, 186, 18),
                         Qt.AlignRight, text)


def render_frame(frame: np.ndarray, hands: list[HandFrame], state: RecognitionState,
                 *, show_landmarks: bool = True, fps: float = 0.0,
                 mode_label: str = "") -> QImage:
    """Produce the preview image: camera frame + skeleton + HUD."""
    image = frame_to_qimage(frame)
    painter = QPainter(image)
    try:
        if show_landmarks:
            for hand in hands:
                draw_landmarks(painter, hand, image.width(), image.height())
        draw_hud(painter, state, image.width(), image.height(), fps=fps,
                 mode_label=mode_label)
    finally:
        painter.end()
    return image


def placeholder_image(width: int = 960, height: int = 540, message: str = "") -> QImage:
    """What the preview shows before the camera produces a frame."""
    image = QImage(width, height, QImage.Format_RGB888)
    image.fill(QColor(PALETTE.background_alt))
    painter = QPainter(image)
    try:
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(QPen(QColor(PALETTE.border), 2))
        painter.drawRoundedRect(QRect(8, 8, width - 16, height - 16), 14, 14)
        painter.setPen(QColor(PALETTE.text_muted))
        painter.setFont(QFont("Segoe UI", 12))
        painter.drawText(QRect(0, 0, width, height), Qt.AlignCenter,
                         message or "Camera preview")
    finally:
        painter.end()
    return image


def scale_point(x: float, y: float, width: int, height: int) -> QPolygonF:
    """Helper for callers that need a single scaled point as a polygon."""
    return QPolygonF([QPointF(x * width, y * height)])
