"""Settings page: camera, recognition, safety, privacy and maintenance."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from aircontrol.config import user_data_dir
from aircontrol.data.db import backup
from aircontrol.ui.components import (
    Card,
    SliderRow,
    ToggleRow,
    danger_button,
    section_title,
)
from aircontrol.ui.context import AppContext
from aircontrol.ui.pages.base import Page


class SettingsPage(Page):
    """All persistent configuration in one place."""

    title = "Settings"
    subtitle = "Camera, recognition sensitivity, safety and data."

    def __init__(self, context: AppContext, parent: QWidget | None = None):
        super().__init__(context, parent)
        self._build()

    def _build(self) -> None:
        config = self.context.config
        self.body.addWidget(section_title(
            "Settings",
            "Changes are saved to your user profile and applied to new sessions."))

        # -- camera ----------------------------------------------------------
        camera = Card("Camera")
        row = QHBoxLayout()
        row.setSpacing(12)
        self.camera_index = QSpinBox()
        self.camera_index.setRange(0, 9)
        self.camera_index.setValue(config.camera.index)
        self.resolution = QComboBox()
        for width, height in ((640, 480), (1280, 720), (1920, 1080)):
            self.resolution.addItem(f"{width} x {height}", (width, height))
        current = (config.camera.width, config.camera.height)
        index = self.resolution.findData(current)
        self.resolution.setCurrentIndex(index if index >= 0 else 1)
        row.addWidget(QLabel("Camera device"))
        row.addWidget(self.camera_index)
        row.addSpacing(16)
        row.addWidget(QLabel("Resolution"))
        row.addWidget(self.resolution)
        row.addStretch(1)
        camera.body().addLayout(row)
        self.mirror_toggle = ToggleRow(
            "Mirror preview",
            "Flip the image so moving your hand right moves the pointer right.",
            config.camera.mirror)
        camera.body().addWidget(self.mirror_toggle)
        self.landmark_toggle = ToggleRow(
            "Show hand skeleton", "Draw the 21 landmarks on the preview.",
            config.ui.show_landmarks)
        camera.body().addWidget(self.landmark_toggle)
        self.body.addWidget(camera)

        # -- recognition -----------------------------------------------------
        recognition = Card("Recognition",
                           "Raising sensitivity makes gestures easier to trigger; "
                           "lowering it makes false positives rarer.")
        self.smoothing = SliderRow("Landmark smoothing", 0, 90,
                                   int(config.recognition.ema_alpha * 100), "%")
        self.presence = SliderRow("Detection confidence", 30, 90,
                                  int(config.recognition.min_presence * 100), "%")
        recognition.body().addWidget(self.smoothing)
        recognition.body().addWidget(self.presence)
        self.ml_toggle = ToggleRow(
            "Use the experimental ML classifier",
            "Blends a small trained model with the geometric rules. Off by "
            "default: the geometric path is the tested one, and the shipped "
            "model was trained on synthetic poses only.",
            config.recognition.ml_enabled)
        recognition.body().addWidget(self.ml_toggle)
        self.body.addWidget(recognition)

        # -- safety ----------------------------------------------------------
        safety = Card("Safety")
        self.start_enabled = ToggleRow(
            "Start with gesture control enabled",
            "Off by default. Control must be enabled deliberately.",
            config.safety.start_enabled)
        safety.body().addWidget(self.start_enabled)
        hotkeys = QLabel(
            f"Global hotkeys: {config.safety.toggle_hotkey} toggles control, "
            f"{config.safety.emergency_hotkey} is the emergency stop.")
        hotkeys.setObjectName("muted")
        hotkeys.setWordWrap(True)
        safety.body().addWidget(hotkeys)
        stop_row = QHBoxLayout()
        stop_row.addWidget(danger_button("Emergency stop now"))
        stop_row.itemAt(0).widget().clicked.connect(self.context.emergency_stop)
        stop_row.addStretch(1)
        safety.body().addLayout(stop_row)
        self.body.addWidget(safety)

        # -- privacy ---------------------------------------------------------
        privacy = Card("Privacy")
        privacy_text = QLabel(
            "AirControl never records video, never stores images or landmarks, and "
            "makes no network requests. Usage counters and settings live in "
            f"{user_data_dir()}.")
        privacy_text.setObjectName("muted")
        privacy_text.setWordWrap(True)
        privacy.body().addWidget(privacy_text)
        self.body.addWidget(privacy)

        # -- maintenance -----------------------------------------------------
        maintenance = Card("Data")
        buttons = QHBoxLayout()
        save = QPushButton("Save settings")
        save.setObjectName("primary")
        save.clicked.connect(self._save)
        backup_button = QPushButton("Back up database")
        backup_button.clicked.connect(self._backup)
        defaults = danger_button("Restore defaults")
        defaults.clicked.connect(self._restore)
        buttons.addWidget(save)
        buttons.addWidget(backup_button)
        buttons.addWidget(defaults)
        buttons.addStretch(1)
        maintenance.body().addLayout(buttons)
        self.status = QLabel("")
        self.status.setObjectName("muted")
        maintenance.body().addWidget(self.status)
        self.body.addWidget(maintenance)
        self.body.addStretch(1)

    # -- actions ------------------------------------------------------------
    def _save(self) -> None:
        config = self.context.config
        config.camera.index = self.camera_index.value()
        width, height = self.resolution.currentData()
        config.camera.width, config.camera.height = width, height
        config.camera.mirror = self.mirror_toggle.is_checked()
        config.ui.show_landmarks = self.landmark_toggle.is_checked()
        config.recognition.ema_alpha = max(0.05, self.smoothing.value() / 100.0)
        config.recognition.min_presence = self.presence.value() / 100.0
        config.recognition.ml_enabled = self.ml_toggle.is_checked()
        config.safety.start_enabled = self.start_enabled.is_checked()
        try:
            config.validate()
            self.context.save_config()
        except ValueError as exc:
            self.status.setText(f"Not saved: {exc}")
            return
        self.context.engine.config = type(self.context.engine.config)(
            ema_alpha=config.recognition.ema_alpha,
            min_presence=config.recognition.min_presence,
            pinch_enter_ratio=config.recognition.pinch_enter_ratio,
            pinch_exit_ratio=config.recognition.pinch_exit_ratio,
            ml_weight=config.recognition.ml_weight if config.recognition.ml_enabled else 0.0,
        )
        self.status.setText("Settings saved.")

    def _backup(self) -> None:
        repository = self.context.repository
        if repository is None:
            self.status.setText("No database to back up.")
            return
        target, _filter = QFileDialog.getSaveFileName(
            self, "Back up database", str(user_data_dir() / "aircontrol-backup.db"),
            "SQLite database (*.db)")
        if not target:
            return
        try:
            path = backup(repository.conn, Path(target))
            self.status.setText(f"Backup written to {path}")
        except Exception as exc:  # pragma: no cover - filesystem dependent
            self.status.setText(f"Backup failed: {exc}")

    def _restore(self) -> None:
        confirm = QMessageBox.question(
            self, "Restore defaults",
            "Reset settings, mappings, calibration and usage history? This cannot "
            "be undone.", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if confirm != QMessageBox.Yes:
            return
        self.context.on_restore_defaults()
        self.status.setText("Defaults restored. Restart AirControl to apply camera changes.")

    def refresh(self) -> None:
        self.camera_index.setValue(self.context.config.camera.index)
