"""Presentation Controls page."""

from __future__ import annotations

from PySide6.QtWidgets import QHBoxLayout, QLabel, QLineEdit, QPushButton

from aircontrol.automation.keyboard import PRESENTATION_KEYS
from aircontrol.core.actions import PRESENTATION_TARGETS, ControlMode
from aircontrol.ui.components import Card, Pill, section_title
from aircontrol.ui.context import AppContext
from aircontrol.ui.pages.base import Page
from aircontrol.ui.pages.binding_editor import BindingEditor


class PresentationPage(Page):
    """Slide navigation by gesture, with an optional window guard."""

    title = "Presentation Controls"
    subtitle = "Drive slides from across the room without a clicker."

    def __init__(self, context: AppContext, parent: QWidget | None = None):
        super().__init__(context, parent)
        self._build()

    def _build(self) -> None:
        self.body.addWidget(section_title(
            "Presentation Controls",
            "Navigation uses the standard slide keys, so it works with PowerPoint, "
            "LibreOffice Impress and browser-based decks."))

        control = Card("Control")
        row = QHBoxLayout()
        self.activate = QPushButton("Activate Presentation mode")
        self.activate.setObjectName("primary")
        self.activate.clicked.connect(self._activate)
        stop = QPushButton("Stop")
        stop.setObjectName("danger")
        stop.clicked.connect(self._deactivate)
        self.state_pill = Pill("Idle", "off")
        row.addWidget(self.activate)
        row.addWidget(stop)
        row.addWidget(self.state_pill)
        row.addStretch(1)
        control.body().addLayout(row)

        keys = QLabel("Keys sent: " + ", ".join(
            f"{name} -> {key.upper()}" for name, key in PRESENTATION_KEYS.items()))
        keys.setObjectName("muted")
        keys.setWordWrap(True)
        control.body().addWidget(keys)
        self.body.addWidget(control)

        guard = Card("Window guard",
                     "Optional. When set, slide keys are only sent while a window "
                     "whose title contains this text is focused.")
        guard_row = QHBoxLayout()
        self.focus_input = QLineEdit(self.context.manager.presentation.focus_window)
        self.focus_input.setPlaceholderText("e.g. PowerPoint")
        apply_button = QPushButton("Apply guard")
        apply_button.clicked.connect(self._apply_guard)
        guard_row.addWidget(self.focus_input, 1)
        guard_row.addWidget(apply_button)
        guard.body().addLayout(guard_row)
        self.body.addWidget(guard)

        mapping = Card("Slide mapping",
                       "Proposed defaults: change any row, then save.")
        self.editor = BindingEditor(self.context, ControlMode.PRESENTATION,
                                    PRESENTATION_TARGETS, "key")
        mapping.body().addWidget(self.editor)
        self.body.addWidget(mapping)
        self.body.addStretch(1)

    def _activate(self) -> None:
        self.context.set_mode(ControlMode.PRESENTATION)
        self.context.set_enabled(True)
        self._sync()

    def _deactivate(self) -> None:
        self.context.set_mode(ControlMode.NONE)
        self._sync()

    def _apply_guard(self) -> None:
        self.context.manager.presentation.focus_window = self.focus_input.text().strip()
        self.context.config.storage.log_level = self.context.config.storage.log_level
        self.context.save_config()

    def _sync(self) -> None:
        active = (self.context.manager.enabled
                  and self.context.manager.mode is ControlMode.PRESENTATION)
        self.state_pill.set_state("on" if active else "off",
                                  "Presentation active" if active else "Idle")
        self.activate.setText("Presentation mode active" if active
                              else "Activate Presentation mode")

    def refresh(self) -> None:
        self.editor.reload()
        self._sync()

    def on_mode_changed(self) -> None:
        self._sync()

    def on_enabled_changed(self, enabled: bool) -> None:
        self._sync()
