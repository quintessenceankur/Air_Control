"""Dashboard: is AirControl working, and what is it doing right now?"""

from __future__ import annotations

import time

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from aircontrol.core.actions import ControlMode
from aircontrol.core.gestures.spec import GESTURE_SPECS
from aircontrol.ui.components import (
    Card,
    MeterBar,
    Pill,
    Sparkline,
    StatTile,
    danger_button,
    primary_button,
    section_title,
)
from aircontrol.ui.context import AppContext
from aircontrol.ui.pages.base import Page
from aircontrol.ui.theme import PALETTE


class DashboardPage(Page):
    """Status, quick actions, usage statistics and recent activity."""

    title = "Dashboard"
    subtitle = "Live status and a quick way to start or stop gesture control."

    def __init__(self, context: AppContext, parent: QWidget | None = None):
        super().__init__(context, parent)
        self._build()

    def _build(self) -> None:
        self.body.addWidget(section_title(
            "Welcome back",
            "AirControl reads hand gestures from your webcam and turns them into "
            "desktop actions. Nothing is sent anywhere."))

        # -- status row -----------------------------------------------------
        status_card = Card("System status")
        row = QHBoxLayout()
        row.setSpacing(18)
        self.camera_pill = Pill("Camera", "off")
        self.control_pill = Pill("Control", "off")
        self.mode_pill = Pill("Mode: idle", "off")
        self.gesture_label = QLabel("No gesture")
        self.gesture_label.setObjectName("h2")
        self.confidence_bar = MeterBar(0.0, PALETTE.accent, target=0.8)
        self.fps_label = QLabel("0 fps")
        self.fps_label.setObjectName("muted")

        left = QVBoxLayout()
        pills = QHBoxLayout()
        pills.setSpacing(8)
        for pill in (self.camera_pill, self.control_pill, self.mode_pill):
            pills.addWidget(pill)
        pills.addStretch(1)
        left.addLayout(pills)
        left.addWidget(self.gesture_label)
        left.addWidget(self.confidence_bar)
        row.addLayout(left, 2)

        right = QVBoxLayout()
        right.addWidget(self.fps_label, 0, Qt.AlignRight)
        right.addStretch(1)
        row.addLayout(right, 1)
        status_card.body().addLayout(row)
        self.body.addWidget(status_card)

        # -- stats ----------------------------------------------------------
        self.session_tile = StatTile("Session", "0", "Gestures this session",
                                     accent=PALETTE.accent)
        self.action_tile = StatTile("Actions", "0", "OS actions performed",
                                    accent=PALETTE.success)
        self.total_tile = StatTile("All time", "0", "Gestures recorded",
                                   accent=PALETTE.purple)
        self.accuracy_tile = StatTile("Practice", "n/a", "Recognition accuracy in training",
                                      accent=PALETTE.warning)
        stats = QHBoxLayout()
        stats.setSpacing(14)
        for tile in (self.session_tile, self.action_tile, self.total_tile,
                     self.accuracy_tile):
            stats.addWidget(tile)
        holder = QWidget()
        holder.setLayout(stats)
        self.body.addWidget(holder)

        # -- quick actions --------------------------------------------------
        actions_card = Card("Quick actions",
                            "Control starts disabled. Turn it on deliberately, and "
                            "use the emergency stop if anything misbehaves.")
        buttons = QHBoxLayout()
        buttons.setSpacing(10)
        self.enable_button = primary_button("Enable gesture control")
        self.enable_button.clicked.connect(self._toggle_control)
        self.stop_button = danger_button("Emergency stop")
        self.stop_button.clicked.connect(self.context.emergency_stop)
        buttons.addWidget(self.enable_button)
        buttons.addWidget(self.stop_button)
        buttons.addStretch(1)
        for mode in (ControlMode.AIR_MOUSE, ControlMode.MEDIA,
                     ControlMode.PRESENTATION):
            button = QPushButton(mode.label)
            button.clicked.connect(lambda _=False, m=mode: self.context.set_mode(m))
            buttons.addWidget(button)
        actions_card.body().addLayout(buttons)
        self.body.addWidget(actions_card)

        # -- activity -------------------------------------------------------
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        activity = Card("Activity, last 14 days")
        self.sparkline = Sparkline()
        activity.body().addWidget(self.sparkline)
        grid.addWidget(activity, 0, 0)

        recent = Card("Recent gestures")
        self.recent_layout = QVBoxLayout()
        self.recent_layout.setSpacing(6)
        recent.body().addLayout(self.recent_layout)
        grid.addWidget(recent, 0, 1)
        grid.setColumnStretch(0, 3)
        grid.setColumnStretch(1, 2)
        grid_holder = QWidget()
        grid_holder.setLayout(grid)
        self.body.addWidget(grid_holder)
        self.body.addStretch(1)

    # -- state --------------------------------------------------------------
    def refresh(self) -> None:
        analytics = self.context.analytics
        if analytics is not None:
            snapshot = analytics.snapshot()
            self.total_tile.set_value(str(snapshot.total_gestures),
                                      f"{snapshot.total_sessions} sessions recorded")
            if snapshot.total_practice:
                self.accuracy_tile.set_value(
                    f"{snapshot.practice_accuracy * 100:.0f}%",
                    f"{snapshot.practice_correct}/{snapshot.total_practice} practice attempts")
            else:
                self.accuracy_tile.set_value("n/a", "No practice attempts yet")
            self.sparkline.set_values([count for _day, count in snapshot.daily])
        self._refresh_recent()
        self._refresh_control_state()
        self.camera_pill.set_state("on" if self.context.camera_available else "warn",
                                   "Camera ready" if self.context.camera_available
                                   else "Camera unavailable")

    def _refresh_recent(self) -> None:
        while self.recent_layout.count():
            item = self.recent_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        repository = self.context.repository
        rows = repository.recent_events(6) if repository is not None else []
        if not rows:
            empty = QLabel("No gestures recorded yet. Enable control and hold a pose.")
            empty.setObjectName("muted")
            empty.setWordWrap(True)
            self.recent_layout.addWidget(empty)
            return
        for row in rows:
            line = QLabel(
                f"{row.gesture.replace('_', ' ').title()}   "
                f"{time.strftime('%H:%M:%S', time.localtime(row.occurred_at))}   "
                f"{'executed' if row.executed else 'observed'}")
            line.setObjectName("muted")
            self.recent_layout.addWidget(line)

    def _refresh_control_state(self) -> None:
        enabled = self.context.manager.enabled
        self.control_pill.set_state("on" if enabled else "off",
                                    "Control on" if enabled else "Control off")
        self.enable_button.setText("Disable gesture control" if enabled
                                   else "Enable gesture control")
        mode = self.context.manager.mode
        self.mode_pill.set_state("on" if enabled and mode is not ControlMode.NONE else "off",
                                 f"Mode: {mode.label}")

    def _toggle_control(self) -> None:
        self.context.set_enabled(not self.context.manager.enabled)
        self._refresh_control_state()

    def on_state(self, payload: dict) -> None:
        state = payload.get("state")
        self.fps_label.setText(f"{payload.get('fps', 0):.0f} fps")
        if state is None:
            return
        if state.stable:
            self.gesture_label.setText(state.stable.replace("_", " ").title())
        elif state.tracking:
            self.gesture_label.setText("No gesture")
        else:
            self.gesture_label.setText("No hand detected")
        self.confidence_bar.set_value(state.confidence)
        self.camera_pill.set_state("on" if state.tracking else "warn",
                                   "Camera active" if state.tracking else "Camera idle")
        session = self.context.session
        gestures = session.stats.gestures if session is not None else 0
        self.session_tile.set_value(str(gestures), "Gestures this session")
        self.action_tile.set_value(str(self.context.manager.actions_fired),
                                   self.context.manager.last_action or "OS actions performed")
        self._refresh_control_state()

    def on_enabled_changed(self, enabled: bool) -> None:
        self._refresh_control_state()

    def on_mode_changed(self) -> None:
        self._refresh_control_state()
