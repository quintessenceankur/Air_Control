"""Page base class.

A page renders state and forwards user intent to the context. It never runs
recognition and never calls the executor directly, except where a page is
explicitly a controller page (Air Mouse, Media, Presentation) -- and even
there it goes through the manager's controller objects.
"""

from __future__ import annotations

from PySide6.QtWidgets import QScrollArea, QVBoxLayout, QWidget

from aircontrol.ui.context import AppContext


class Page(QWidget):
    """Scrollable page with a vertical body layout."""

    title: str = ""
    subtitle: str = ""

    def __init__(self, context: AppContext, parent: QWidget | None = None):
        super().__init__(parent)
        self.context = context
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        container = QWidget()
        self.body = QVBoxLayout(container)
        self.body.setContentsMargins(28, 24, 28, 28)
        self.body.setSpacing(16)
        scroll.setWidget(container)
        outer.addWidget(scroll)

    # -- hooks --------------------------------------------------------------
    def refresh(self) -> None:
        """Called when the page becomes visible or the data changes."""

    def on_state(self, payload: dict) -> None:
        """Called ~15 times a second with the live recognition state."""

    def on_event(self, event) -> None:
        """Called when a gesture activation fires."""

    def on_mode_changed(self) -> None:
        """Called when the active controller changes."""

    def on_enabled_changed(self, enabled: bool) -> None:
        """Called when gesture control is enabled or disabled."""

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt naming
        event.accept()
