"""Gesture Training Arena: practise a pose and see whether it was recognised."""

from __future__ import annotations

import time

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from aircontrol.core.gestures.spec import GESTURE_SPECS, VOCABULARY
from aircontrol.ui.components import Card, MeterBar, Pill, section_title
from aircontrol.ui.context import AppContext
from aircontrol.ui.pages.base import Page
from aircontrol.ui.theme import PALETTE


class TrainingPage(Page):
    """A practice loop with live feedback and an honest accuracy count.

    This screen does not train a model. It measures how often the recogniser
    names the pose the user was asked to hold, and stores those attempts so
    the calibration screen has real data to work from.
    """

    title = "Gesture Training Arena"
    subtitle = "Practise each pose and watch your recognition rate."

    def __init__(self, context: AppContext, parent: QWidget | None = None):
        super().__init__(context, parent)
        self._last_correct: bool | None = None
        self._build()

    def _build(self) -> None:
        self.body.addWidget(section_title(
            "Gesture Training Arena",
            "Choose a gesture, hold it, and AirControl tells you what it saw. "
            "This records your hit rate; it does not train a machine-learning "
            "model."))

        setup = Card("Practice session")
        row = QHBoxLayout()
        row.setSpacing(12)
        self.target = QComboBox()
        for gesture in VOCABULARY:
            self.target.addItem(gesture.replace("_", " ").title(), gesture)
        self.start_button = QPushButton("Start practice")
        self.start_button.setObjectName("primary")
        self.start_button.clicked.connect(self._start)
        self.stop_button = QPushButton("Stop")
        self.stop_button.clicked.connect(self._stop)
        self.state_pill = Pill("Not practising", "off")
        row.addWidget(QLabel("Target gesture"))
        row.addWidget(self.target)
        row.addWidget(self.start_button)
        row.addWidget(self.stop_button)
        row.addWidget(self.state_pill)
        row.addStretch(1)
        setup.body().addLayout(row)

        self.instruction = QLabel("Pick a gesture and press Start practice.")
        self.instruction.setObjectName("muted")
        self.instruction.setWordWrap(True)
        setup.body().addWidget(self.instruction)
        self.body.addWidget(setup)

        # -- live feedback ---------------------------------------------------
        live = QHBoxLayout()
        live.setSpacing(14)
        feedback = Card("Live feedback")
        self.recognised = QLabel("Waiting")
        self.recognised.setObjectName("h1")
        self.confidence = QLabel("confidence 0.00")
        self.confidence.setObjectName("muted")
        self.confidence_bar = MeterBar(0.0, PALETTE.accent, target=0.8)
        self.result_pill = Pill("Idle", "off")
        feedback.body().addWidget(self.recognised)
        feedback.body().addWidget(self.confidence)
        feedback.body().addWidget(self.confidence_bar)
        feedback.body().addWidget(self.result_pill, 0, Qt.AlignLeft)
        live.addWidget(feedback, 2)

        score = Card("Your score")
        grid = QGridLayout()
        self.correct_label = QLabel("0")
        self.correct_label.setObjectName("statValue")
        self.incorrect_label = QLabel("0")
        self.incorrect_label.setObjectName("statValue")
        self.accuracy_label = QLabel("-")
        self.accuracy_label.setObjectName("statValue")
        grid.addWidget(QLabel("Correct"), 0, 0)
        grid.addWidget(QLabel("Incorrect"), 0, 1)
        grid.addWidget(QLabel("Accuracy"), 0, 2)
        grid.addWidget(self.correct_label, 1, 0)
        grid.addWidget(self.incorrect_label, 1, 1)
        grid.addWidget(self.accuracy_label, 1, 2)
        score.body().addLayout(grid)
        live.addWidget(score, 1)
        holder = QWidget()
        holder.setLayout(live)
        self.body.addWidget(holder)

        # -- history ---------------------------------------------------------
        history = Card("Recent attempts")
        self.history_layout = QVBoxLayout()
        self.history_layout.setSpacing(3)
        history.body().addWidget(QLabel(""))
        history.body().addLayout(self.history_layout)
        self.body.addWidget(history)
        self.body.addStretch(1)

    # -- actions ------------------------------------------------------------
    def _start(self) -> None:
        gesture = self.target.currentData()
        service = self.context.practice
        if service is not None:
            service.start(gesture)
        self.state_pill.set_state("on", "Practising")
        spec = GESTURE_SPECS[gesture]
        self.instruction.setText(
            f"Hold {gesture.replace('_', ' ').title()}: {spec.description} "
            "Keep your hand still for a moment so the dwell completes.")
        self._refresh_score()

    def _stop(self) -> None:
        service = self.context.practice
        if service is not None:
            service.stop()
        self.state_pill.set_state("off", "Not practising")
        self.result_pill.set_state("off", "Idle")

    def _refresh_score(self) -> None:
        service = self.context.practice
        session = service.session if service is not None else None
        if session is None:
            self.correct_label.setText("0")
            self.incorrect_label.setText("0")
            self.accuracy_label.setText("-")
            return
        self.correct_label.setText(str(session.correct))
        self.incorrect_label.setText(str(session.incorrect))
        self.accuracy_label.setText(f"{session.accuracy * 100:.0f}%")

    def _add_history(self, text: str) -> None:
        line = QLabel(text)
        line.setObjectName("muted")
        self.history_layout.insertWidget(0, line)
        while self.history_layout.count() > 8:
            item = self.history_layout.takeAt(self.history_layout.count() - 1)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    # -- live ---------------------------------------------------------------
    def on_state(self, payload: dict) -> None:
        state = payload.get("state")
        if state is None:
            return
        if state.stable:
            self.recognised.setText(state.stable.replace("_", " ").title())
        elif state.tracking:
            self.recognised.setText("No gesture")
        else:
            self.recognised.setText("No hand")
        self.confidence.setText(f"confidence {state.confidence:.2f}")
        self.confidence_bar.set_value(state.confidence)

    def on_event(self, event) -> None:
        service = self.context.practice
        if service is None or service.session is None:
            return
        attempt = service.record(event.name, event.confidence)
        if attempt is None:
            return
        if attempt.correct:
            self.result_pill.set_state("on", "Correct")
        else:
            self.result_pill.set_state("warn",
                                       f"Saw {event.name.replace('_', ' ').title()}")
        self._add_history(
            f"{time.strftime('%H:%M:%S')}  target {attempt.target.replace('_', ' ').title()}"
            f"  saw {(attempt.recognized or 'nothing').replace('_', ' ').title()}"
            f"  {'OK' if attempt.correct else 'miss'}")
        self._refresh_score()

    def refresh(self) -> None:
        self._refresh_score()
