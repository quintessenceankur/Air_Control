"""Media Controls page."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from aircontrol.core.actions import MEDIA_TARGETS, ControlMode
from aircontrol.ui.components import Card, Pill, section_title
from aircontrol.ui.context import AppContext
from aircontrol.ui.pages.base import Page
from aircontrol.ui.pages.binding_editor import BindingEditor

MEDIA_LABELS = {
    "play_pause": "Play / pause",
    "next": "Next track",
    "previous": "Previous track",
    "volume_up": "Volume up",
    "volume_down": "Volume down",
    "mute": "Mute / unmute",
}


class MediaPage(Page):
    """Enable media control and choose which gesture does what."""

    title = "Media Controls"
    subtitle = "Play, pause, skip and change volume without touching the keyboard."

    def __init__(self, context: AppContext, parent: QWidget | None = None):
        super().__init__(context, parent)
        self._build()

    def _build(self) -> None:
        self.body.addWidget(section_title(
            "Media Controls",
            "Media keys are sent with a 250 ms guard interval, so a gesture that "
            "flickers cannot raise the volume twice."))

        control = Card("Control")
        row = QHBoxLayout()
        self.activate = QPushButton("Activate Media mode")
        self.activate.setObjectName("primary")
        self.activate.clicked.connect(self._activate)
        stop = QPushButton("Stop")
        stop.setObjectName("danger")
        stop.clicked.connect(self._deactivate)
        self.state_pill = Pill("Idle", "off")
        self.last_action = QLabel("No action yet")
        self.last_action.setObjectName("muted")
        row.addWidget(self.activate)
        row.addWidget(stop)
        row.addWidget(self.state_pill)
        row.addStretch(1)
        row.addWidget(self.last_action)
        control.body().addLayout(row)
        self.body.addWidget(control)

        actions_card = Card("Available actions")
        grid = QVBoxLayout()
        grid.setSpacing(3)
        for name, label in MEDIA_LABELS.items():
            line = QLabel(f"{label}  ({name})")
            line.setObjectName("muted")
            grid.addWidget(line)
        actions_card.body().addLayout(grid)
        self.body.addWidget(actions_card)

        mapping = Card("Gesture mapping",
                       "These bindings are proposed defaults -- change them freely.")
        self.editor = BindingEditor(self.context, ControlMode.MEDIA,
                                    MEDIA_TARGETS, "media")
        mapping.body().addWidget(self.editor)
        self.body.addWidget(mapping)
        self.body.addStretch(1)

    def _activate(self) -> None:
        self.context.set_mode(ControlMode.MEDIA)
        self.context.set_enabled(True)
        self._sync()

    def _deactivate(self) -> None:
        self.context.set_mode(ControlMode.NONE)
        self._sync()

    def _sync(self) -> None:
        active = (self.context.manager.enabled
                  and self.context.manager.mode is ControlMode.MEDIA)
        self.state_pill.set_state("on" if active else "off",
                                  "Media active" if active else "Idle")
        self.activate.setText("Media mode active" if active
                              else "Activate Media mode")

    def refresh(self) -> None:
        self.editor.reload()
        self._sync()

    def on_state(self, payload: dict) -> None:
        if payload.get("mode") == ControlMode.MEDIA.value:
            action = payload.get("last_action") or ""
            if action:
                self.last_action.setText(action)
        self._sync()

    def on_mode_changed(self) -> None:
        self._sync()

    def on_enabled_changed(self, enabled: bool) -> None:
        self._sync()
