"""Shared editor for gesture -> action mapping tables."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QHeaderView,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from aircontrol.core.actions import NONE, Action, ControlMode
from aircontrol.core.gestures.spec import VOCABULARY
from aircontrol.ui.context import AppContext

UNBOUND = "Unbound"


class BindingEditor(QWidget):
    """Editable table of gesture -> target for one controller mode."""

    def __init__(self, context: AppContext, mode: ControlMode,
                 targets: tuple[str, ...], kind: str,
                 parent: QWidget | None = None):
        super().__init__(parent)
        self.context = context
        self.mode = mode
        self.targets = targets
        self.kind = kind
        self._combos: dict[str, QComboBox] = {}

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        self.table = QTableWidget(len(VOCABULARY), 2)
        self.table.setHorizontalHeaderLabels(["Gesture", "Action"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionMode(QTableWidget.NoSelection)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        layout.addWidget(self.table)

        self.save_button = QPushButton("Save mapping")
        self.save_button.clicked.connect(self.save)
        layout.addWidget(self.save_button, 0, Qt.AlignLeft)
        self.hint = QLabel("")
        self.hint.setObjectName("muted")
        layout.addWidget(self.hint)
        self.reload()

    # -- data ---------------------------------------------------------------
    def reload(self) -> None:
        bindings = self.context.bindings(self.mode)
        for row, gesture in enumerate(VOCABULARY):
            item = QTableWidgetItem(gesture.replace("_", " ").title())
            self.table.setItem(row, 0, item)
            combo = QComboBox()
            combo.addItem(UNBOUND)
            combo.addItems([t.replace("_", " ").title() for t in self.targets])
            action = bindings.get(gesture)
            if action is not None and action.kind != NONE and action.target in self.targets:
                combo.setCurrentIndex(self.targets.index(action.target) + 1)
            self._combos[gesture] = combo
            self.table.setCellWidget(row, 1, combo)

    def save(self) -> None:
        bindings: dict[str, Action] = {}
        for gesture, combo in self._combos.items():
            index = combo.currentIndex()
            if index <= 0:
                bindings[gesture] = Action(NONE, "", "Unbound")
            else:
                target = self.targets[index - 1]
                bindings[gesture] = Action(
                    self.kind, target, target.replace("_", " ").title())
        try:
            self.context.save_bindings(self.mode, bindings)
        except Exception as exc:  # pragma: no cover - validation guard
            self.hint.setText(f"Could not save: {exc}")
            return
        self.hint.setText("Saved. The mapping is active immediately.")

    def current_bindings(self) -> dict[str, Action]:
        bindings: dict[str, Action] = {}
        for gesture, combo in self._combos.items():
            index = combo.currentIndex()
            bindings[gesture] = (Action(NONE, "", "Unbound") if index <= 0
                                 else Action(self.kind, self.targets[index - 1]))
        return bindings
