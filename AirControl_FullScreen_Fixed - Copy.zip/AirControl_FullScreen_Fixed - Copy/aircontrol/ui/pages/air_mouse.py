"""Air Mouse page: cursor tuning, gesture roles and live pointer status."""

from __future__ import annotations

from dataclasses import replace

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from aircontrol.core.actions import DEFAULT_AIR_MOUSE_ROLES, ControlMode
from aircontrol.ui.components import (
    Card,
    Pill,
    SliderRow,
    ToggleRow,
    section_title,
)
from aircontrol.ui.context import AppContext
from aircontrol.ui.pages.base import Page
from aircontrol.ui.theme import PALETTE


class AirMousePage(Page):
    """Enable the air mouse and tune how the pointer behaves."""

    title = "Air Mouse"
    subtitle = "Move the cursor with your index fingertip; pinch to click or drag."

    def __init__(self, context: AppContext, parent: QWidget | None = None):
        super().__init__(context, parent)
        self._build()

    def _build(self) -> None:
        self.body.addWidget(section_title(
            "Air Mouse",
            "The pointer follows the index fingertip of the pose bound to "
            "'pointer'. Pinch quickly for a click, hold the pinch to drag."))

        control_card = Card("Control")
        row = QHBoxLayout()
        self.activate = QPushButton("Activate Air Mouse")
        self.activate.setObjectName("primary")
        self.activate.clicked.connect(self._activate)
        self.deactivate = QPushButton("Stop")
        self.deactivate.setObjectName("danger")
        self.deactivate.clicked.connect(self._deactivate)
        row.addWidget(self.activate)
        row.addWidget(self.deactivate)
        row.addStretch(1)
        self.state_pill = Pill("Idle", "off")
        self.paused_pill = Pill("Running", "off")
        self.drag_pill = Pill("Not dragging", "off")
        row.addWidget(self.state_pill)
        row.addWidget(self.paused_pill)
        row.addWidget(self.drag_pill)
        control_card.body().addLayout(row)
        self.body.addWidget(control_card)

        # -- tuning ----------------------------------------------------------
        tuning = QHBoxLayout()
        tuning.setSpacing(14)
        speed_card = Card("Cursor")
        config = self.context.config.air_mouse
        self.speed = SliderRow("Cursor speed", 20, 300, int(config.gain * 100), "%")
        self.sensitivity = SliderRow("Sensitivity", 20, 300,
                                     int(config.sensitivity * 100), "%")
        self.dead_zone = SliderRow("Dead zone", 0, 20, config.dead_zone_px, " px")
        speed_card.body().addWidget(self.speed)
        speed_card.body().addWidget(self.sensitivity)
        speed_card.body().addWidget(self.dead_zone)
        save = QPushButton("Apply cursor settings")
        save.clicked.connect(self._apply)
        speed_card.body().addWidget(save)
        tuning.addWidget(speed_card, 1)

        # -- desktop coverage ------------------------------------------------
        coverage = Card("Desktop coverage",
                        "AirControl maps the whole screen, taskbar and corners "
                        "included. These are the bounds it is using right now.")
        self.bounds_label = QLabel()
        self.bounds_label.setObjectName("h3")
        coverage.body().addWidget(self.bounds_label)
        self.bounds_hint = QLabel(
            "Cursor speed and sensitivity change how far the cursor travels for "
            "a given hand movement. They never shrink the reachable area: the "
            "screen edge is always reachable.")
        self.bounds_hint.setObjectName("muted")
        self.bounds_hint.setWordWrap(True)
        coverage.body().addWidget(self.bounds_hint)
        coverage_row = QHBoxLayout()
        redetect = QPushButton("Re-detect desktop size")
        redetect.clicked.connect(self._refresh_bounds)
        coverage_row.addWidget(redetect)
        coverage_row.addStretch(1)
        coverage.body().addLayout(coverage_row)
        self.body.addWidget(coverage)

        smoothing_card = Card("Smoothing",
                              "One Euro filtering removes jitter without adding lag "
                              "during fast movement.")
        self.smoothing = SliderRow("Smoothing strength", 0, 100,
                                   int(config.min_cutoff / 2.4 * 100), "%")
        self.region = SliderRow("Active area margin", 0, 40,
                                int(config.active_region * 100), "%")
        # The margin crops the camera frame, not the screen: it decides how far
        # the hand must travel to reach a screen edge, never whether it can.
        self.drag_delay = SliderRow("Drag delay", 5, 80,
                                    int(config.drag_delay_s * 100), " x10 ms")
        smoothing_card.body().addWidget(self.smoothing)
        smoothing_card.body().addWidget(self.region)
        smoothing_card.body().addWidget(self.drag_delay)
        tuning.addWidget(smoothing_card, 1)
        holder = QWidget()
        holder.setLayout(tuning)
        self.body.addWidget(holder)

        # -- roles -----------------------------------------------------------
        roles_card = Card("Gesture roles",
                          "Which gesture does what in Air Mouse mode. These are "
                          "proposed defaults; the owner's specification does not "
                          "assign them.")
        grid = QGridLayout()
        grid.setHorizontalSpacing(20)
        grid.setVerticalSpacing(6)
        for index, (gesture, role) in enumerate(DEFAULT_AIR_MOUSE_ROLES.items()):
            name = QLabel(gesture.replace("_", " ").title())
            name.setObjectName("h3")
            description = QLabel(role.replace("_", " ").title())
            description.setObjectName("muted")
            grid.addWidget(name, index, 0)
            grid.addWidget(description, index, 1)
        roles_card.body().addLayout(grid)
        self.status_label = QLabel("Cursor position: -")
        self.status_label.setObjectName("muted")
        roles_card.body().addWidget(self.status_label)
        self.body.addWidget(roles_card)
        self.body.addStretch(1)

    # -- actions ------------------------------------------------------------
    def _activate(self) -> None:
        self.context.set_mode(ControlMode.AIR_MOUSE)
        self.context.set_enabled(True)
        self._sync()

    def _deactivate(self) -> None:
        self.context.manager.air_mouse.reset()
        self.context.set_mode(ControlMode.NONE)
        self._sync()

    def _apply(self) -> None:
        """Write the sliders into the config and push them at the live controller.

        Assigning ``controller.config`` used to leave the pointer filter built
        from the old cutoff, so smoothing changes did nothing until restart;
        ``context.apply_air_mouse_config()`` rebuilds it.
        """
        updated = replace(
            self.context.config.air_mouse,
            gain=self.speed.value() / 100.0,
            sensitivity=self.sensitivity.value() / 100.0,
            dead_zone_px=self.dead_zone.value(),
            min_cutoff=max(0.3, self.smoothing.value() / 100.0 * 2.4),
            active_region=self.region.value() / 100.0,
            drag_delay_s=max(0.05, self.drag_delay.value() / 100.0),
        )
        try:
            # Validate through AppConfig so an out-of-range slider value cannot
            # reach the running controller.
            replace(self.context.config, air_mouse=updated).validate()
        except ValueError as exc:
            self.status_label.setText(f"Not applied: {exc}")
            return
        self.context.config.air_mouse = updated
        self.context.apply_air_mouse_config()
        self.context.save_config()
        self._update_bounds_label()
        self.status_label.setText("Cursor settings applied to the running controller.")

    def _refresh_bounds(self) -> None:
        bounds = self.context.refresh_screen_bounds()
        self._update_bounds_label()
        self.status_label.setText(f"Desktop re-detected: {bounds.describe()}")

    def _update_bounds_label(self) -> None:
        bounds = self.context.manager.screen_bounds
        self.bounds_label.setText(
            f"{bounds.width} x {bounds.height} pixels  "
            f"(x 0-{bounds.max_x}, y 0-{bounds.max_y})  [{bounds.source}]")

    def refresh(self) -> None:
        self._update_bounds_label()
        self._sync()

    def _sync(self) -> None:
        enabled = self.context.manager.enabled
        mode = self.context.manager.mode
        active = enabled and mode is ControlMode.AIR_MOUSE
        self.state_pill.set_state("on" if active else "off",
                                  "Air Mouse active" if active else "Idle")
        self.activate.setText("Air Mouse active" if active else "Activate Air Mouse")

    # -- live ---------------------------------------------------------------
    def on_state(self, payload: dict) -> None:
        status = payload.get("air_mouse")
        if status is not None:
            self.paused_pill.set_state("warn" if status.paused else "on",
                                       "Paused by fist" if status.paused else "Running")
            self.drag_pill.set_state("on" if status.dragging else "off",
                                     "Dragging" if status.dragging else "Not dragging")
            self.status_label.setText(
                f"Cursor: {status.cursor[0]:.0f}, {status.cursor[1]:.0f}"
                + (f"   last action: {status.last_action}" if status.last_action else ""))
        self._sync()

    def on_mode_changed(self) -> None:
        self._sync()

    def on_enabled_changed(self, enabled: bool) -> None:
        self._sync()
