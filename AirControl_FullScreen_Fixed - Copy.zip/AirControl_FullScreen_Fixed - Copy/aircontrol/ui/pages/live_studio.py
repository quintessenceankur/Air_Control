"""Live Gesture Studio: the webcam preview and what the engine sees."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QVBoxLayout,
    QWidget,
)

from aircontrol.core.gestures.spec import GESTURE_SPECS, VOCABULARY
from aircontrol.ui.components import Card, GestureChip, Pill, section_title
from aircontrol.ui.context import AppContext
from aircontrol.ui.overlay import placeholder_image
from aircontrol.ui.pages.base import Page
from aircontrol.ui.theme import PALETTE

FINGER_ORDER = ("thumb", "index", "middle", "ring", "pinky")


class LiveStudioPage(Page):
    """Preview, landmark overlay, recognised gesture and finger states."""

    title = "Live Gesture Studio"
    subtitle = "What the camera sees, and why the engine decided what it decided."

    def __init__(self, context: AppContext, parent: QWidget | None = None):
        super().__init__(context, parent)
        self._build()

    def _build(self) -> None:
        self.body.addWidget(section_title(
            "Live Gesture Studio",
            "Hold a pose and watch the score climb past the 0.80 activation "
            "threshold. A gesture fires once, then waits out its cooldown."))

        preview_card = Card("Camera preview")
        self.preview = QLabel()
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setMinimumHeight(360)
        self.preview.setPixmap(QPixmap.fromImage(placeholder_image(
            960, 540, "Waiting for the camera")))
        self.preview.setScaledContents(False)
        preview_card.body().addWidget(self.preview)
        self.preview.setStyleSheet(
            f"border-radius: 12px; background: {PALETTE.background_alt};")
        self.body.addWidget(preview_card)

        # -- live readouts ---------------------------------------------------
        info = QHBoxLayout()
        info.setSpacing(14)

        state_card = Card("Recognition")
        self.gesture_value = QLabel("No gesture")
        self.gesture_value.setObjectName("h1")
        self.confidence_value = QLabel("confidence 0.00")
        self.confidence_value.setObjectName("muted")
        self.tracking_pill = Pill("No hand", "off")
        self.handedness_value = QLabel("hand: -")
        self.handedness_value.setObjectName("muted")
        self.fps_value = QLabel("0 fps")
        self.fps_value.setObjectName("muted")
        state_card.body().addWidget(self.gesture_value)
        state_card.body().addWidget(self.confidence_value)
        state_card.body().addWidget(self.tracking_pill, 0, Qt.AlignLeft)
        state_card.body().addWidget(self.handedness_value)
        state_card.body().addWidget(self.fps_value)
        info.addWidget(state_card, 1)

        fingers_card = Card("Finger state",
                            "Extension score per finger, 0 (folded) to 1 (straight).")
        self.finger_labels: dict[str, QLabel] = {}
        grid = QGridLayout()
        grid.setHorizontalSpacing(18)
        for column, finger in enumerate(FINGER_ORDER):
            label = QLabel(finger.upper())
            label.setObjectName("caption")
            value = QLabel("0.00")
            value.setObjectName("h3")
            grid.addWidget(label, 0, column)
            grid.addWidget(value, 1, column)
            self.finger_labels[finger] = value
        fingers_card.body().addLayout(grid)
        self.pinch_value = QLabel("pinch ratio 0.00")
        self.pinch_value.setObjectName("muted")
        fingers_card.body().addWidget(self.pinch_value)
        info.addWidget(fingers_card, 2)

        holder = QWidget()
        holder.setLayout(info)
        self.body.addWidget(holder)

        # -- score board -----------------------------------------------------
        scores_card = Card("Gesture scores",
                           "Every gesture in the vocabulary, scored live. The tick "
                           "marks the activation threshold.")
        self.chips: dict[str, GestureChip] = {}
        grid = QGridLayout()
        grid.setHorizontalSpacing(26)
        grid.setVerticalSpacing(10)
        for index, gesture in enumerate(VOCABULARY):
            chip = GestureChip(gesture)
            self.chips[gesture] = chip
            grid.addWidget(chip, index // 2, index % 2)
        scores_card.body().addLayout(grid)
        self.body.addWidget(scores_card)

        vocab_card = Card("Vocabulary",
                          "These seven gestures are the owner's specification. "
                          "Shapes are fixed; what each one triggers is configurable.")
        self.vocab_layout = QVBoxLayout()
        self.vocab_layout.setSpacing(4)
        for gesture in VOCABULARY:
            spec = GESTURE_SPECS[gesture]
            line = QLabel(f"{gesture.replace('_', ' ').title()} - {spec.description}")
            line.setObjectName("muted")
            line.setWordWrap(True)
            self.vocab_layout.addWidget(line)
        vocab_card.body().addLayout(self.vocab_layout)
        self.body.addWidget(vocab_card)
        self.body.addStretch(1)

    # -- live updates -------------------------------------------------------
    def on_state(self, payload: dict) -> None:
        state = payload.get("state")
        self.fps_value.setText(f"{payload.get('fps', 0):.0f} fps")
        if state is None:
            return
        if state.stable:
            self.gesture_value.setText(state.stable.replace("_", " ").title())
        elif state.tracking:
            self.gesture_value.setText("No gesture")
        else:
            self.gesture_value.setText("No hand detected")
        self.confidence_value.setText(f"confidence {state.confidence:.2f}")
        self.tracking_pill.set_state(
            "on" if state.tracking else "off",
            "Tracking" if state.tracking else "No hand")
        self.handedness_value.setText(
            f"hand: {state.handedness}" if state.handedness else "hand: -")

        features = state.features
        if features is not None:
            for finger, label in self.finger_labels.items():
                label.setText(f"{features.extension[finger]:.2f}")
            self.pinch_value.setText(f"pinch ratio {features.pinch_ratio:.2f}")
        for gesture, chip in self.chips.items():
            chip.set_score(state.scores.get(gesture, 0.0))

    def show_frame(self, image) -> None:
        """Display a preview image, scaled to the widget while keeping ratio."""
        pixmap = QPixmap.fromImage(image)
        self.preview.setPixmap(pixmap.scaled(
            self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def resizeEvent(self, event) -> None:  # noqa: N802 - Qt naming
        super().resizeEvent(event)
        if self.preview.pixmap() is not None and not self.preview.pixmap().isNull():
            self.preview.setPixmap(self.preview.pixmap().scaled(
                self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
