"""Analytics page: measured usage, not decoration."""

from __future__ import annotations

import time

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from aircontrol.ui.components import Card, Sparkline, StatTile, section_title
from aircontrol.ui.context import AppContext
from aircontrol.ui.pages.base import Page
from aircontrol.ui.theme import PALETTE


class AnalyticsPage(Page):
    """Sessions, gesture usage, recognition statistics and practice accuracy."""

    title = "Analytics"
    subtitle = "Everything here is counted from your own recorded sessions."

    def __init__(self, context: AppContext, parent: QWidget | None = None):
        super().__init__(context, parent)
        self._build()

    def _build(self) -> None:
        self.body.addWidget(section_title(
            "Analytics",
            "Usage is stored locally in a SQLite database. No images, no landmark "
            "streams, no network."))

        tiles = QHBoxLayout()
        tiles.setSpacing(14)
        self.sessions_tile = StatTile("Sessions", "0", "Recorded sessions",
                                      accent=PALETTE.accent)
        self.gestures_tile = StatTile("Gestures", "0", "Total activations",
                                      accent=PALETTE.success)
        self.actions_tile = StatTile("Actions", "0", "Actions executed",
                                     accent=PALETTE.purple)
        self.time_tile = StatTile("Time", "0h", "Active control time",
                                  accent=PALETTE.warning)
        for tile in (self.sessions_tile, self.gestures_tile, self.actions_tile,
                     self.time_tile):
            tiles.addWidget(tile)
        holder = QWidget()
        holder.setLayout(tiles)
        self.body.addWidget(holder)

        chart = Card("Activity, last 14 days")
        self.sparkline = Sparkline()
        chart.body().addWidget(self.sparkline)
        self.body.addWidget(chart)

        tables = QHBoxLayout()
        tables.setSpacing(14)

        usage = Card("Gesture usage")
        self.usage_table = self._table(["Gesture", "Count"])
        usage.body().addWidget(self.usage_table)
        tables.addWidget(usage, 1)

        practice = Card("Practice accuracy",
                        "Measured in the Training Arena, per gesture.")
        self.practice_table = self._table(["Gesture", "Attempts", "Correct", "Rate"])
        practice.body().addWidget(self.practice_table)
        tables.addWidget(practice, 1)
        tables_holder = QWidget()
        tables_holder.setLayout(tables)
        self.body.addWidget(tables_holder)

        sessions_card = Card("Recent sessions")
        self.sessions_table = self._table(["Started", "Duration", "Gestures", "Actions"])
        sessions_card.body().addWidget(self.sessions_table)
        self.body.addWidget(sessions_card)

        self.confidence_label = QLabel("Mean recognition confidence: -")
        self.confidence_label.setObjectName("muted")
        self.body.addWidget(self.confidence_label)
        self.body.addStretch(1)

    @staticmethod
    def _table(headers: list[str]) -> QTableWidget:
        table = QTableWidget(0, len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.setSelectionMode(QTableWidget.NoSelection)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.setMinimumHeight(180)
        return table

    @staticmethod
    def _fill(table: QTableWidget, rows: list[list[str]]) -> None:
        table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            for column, value in enumerate(row):
                item = QTableWidgetItem(str(value))
                if column > 0:
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                table.setItem(row_index, column, item)

    def refresh(self) -> None:
        analytics = self.context.analytics
        if analytics is None:
            return
        snapshot = analytics.snapshot()
        self.sessions_tile.set_value(str(snapshot.total_sessions),
                                     f"{snapshot.average_session_s:.0f}s average session")
        self.gestures_tile.set_value(str(snapshot.total_gestures),
                                     f"{snapshot.total_actions} executed")
        self.actions_tile.set_value(str(snapshot.total_actions), "OS actions performed")
        self.time_tile.set_value(f"{snapshot.hours_active:.1f}h", "Active control time")
        self.sparkline.set_values([count for _day, count in snapshot.daily])
        self.confidence_label.setText(
            f"Mean recognition confidence: {snapshot.mean_confidence:.2f}"
            if snapshot.total_gestures else "Mean recognition confidence: -")

        self._fill(self.usage_table, [
            [gesture.replace("_", " ").title(), count]
            for gesture, count in snapshot.gesture_counts] or [["No gestures yet", 0]])

        self._fill(self.practice_table, [
            [gesture.replace("_", " ").title(), total, correct, f"{rate * 100:.0f}%"]
            for gesture, total, correct, rate in snapshot.per_gesture_practice]
            or [["No practice yet", 0, 0, "-"]])

        repository = self.context.repository
        rows = repository.sessions(8) if repository is not None else []
        self._fill(self.sessions_table, [
            [time.strftime("%d/%m %H:%M", time.localtime(session.started_at)),
             f"{session.duration_s:.0f}s", session.gestures_fired,
             session.actions_fired] for session in rows] or [["No sessions yet", "-", 0, 0]])
