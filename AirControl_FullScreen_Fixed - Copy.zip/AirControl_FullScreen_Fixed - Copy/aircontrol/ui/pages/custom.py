"""Custom Gesture Studio: remap any gesture to any supported action."""

from __future__ import annotations

from PySide6.QtWidgets import QComboBox, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from aircontrol.core.actions import (
    MEDIA_TARGETS,
    PRESENTATION_TARGETS,
    ControlMode,
)
from aircontrol.core.gestures.spec import VOCABULARY
from aircontrol.ui.components import Card, section_title
from aircontrol.ui.context import AppContext
from aircontrol.ui.pages.base import Page
from aircontrol.ui.pages.binding_editor import BindingEditor


class CustomGesturePage(Page):
    """One place to assign gestures for either controller, and to see the result."""

    title = "Custom Gesture Studio"
    subtitle = "Assign gestures to actions and see the mapping that is live now."

    def __init__(self, context: AppContext, parent: QWidget | None = None):
        super().__init__(context, parent)
        self._build()

    def _build(self) -> None:
        self.body.addWidget(section_title(
            "Custom Gesture Studio",
            "The gesture vocabulary is fixed -- AirControl recognises seven poses. "
            "What each pose triggers is entirely yours to assign."))

        picker = Card("Mapping target")
        row = QHBoxLayout()
        row.setSpacing(12)
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("Media controls", ControlMode.MEDIA)
        self.mode_combo.addItem("Presentation", ControlMode.PRESENTATION)
        self.mode_combo.currentIndexChanged.connect(self._switch_mode)
        row.addWidget(QLabel("Controller"))
        row.addWidget(self.mode_combo)
        row.addStretch(1)
        picker.body().addLayout(row)
        self.body.addWidget(picker)

        self.editor_card = Card("Assign actions")
        self.editor_holder = QVBoxLayout()
        self.editor_card.body().addLayout(self.editor_holder)
        self.body.addWidget(self.editor_card)

        reference = Card("Gesture reference")
        self.reference_layout = QVBoxLayout()
        self.reference_layout.setSpacing(4)
        for gesture in VOCABULARY:
            line = QLabel(gesture.replace("_", " ").title())
            line.setObjectName("h3")
            self.reference_layout.addWidget(line)
        reference.body().addLayout(self.reference_layout)
        self.body.addWidget(reference)

        live = Card("Currently active mapping")
        self.live_layout = QVBoxLayout()
        self.live_layout.setSpacing(3)
        live.body().addLayout(self.live_layout)
        refresh = QPushButton("Reload mapping")
        refresh.clicked.connect(self._reload_live)
        live.body().addWidget(refresh, 0)
        self.body.addWidget(live)
        self.body.addStretch(1)

        self.editor: BindingEditor | None = None
        self._build_editor(ControlMode.MEDIA)
        self._reload_live()

    # -- internals ----------------------------------------------------------
    def _build_editor(self, mode: ControlMode) -> None:
        while self.editor_holder.count():
            item = self.editor_holder.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        targets, kind = ((MEDIA_TARGETS, "media")
                         if mode is ControlMode.MEDIA
                         else (PRESENTATION_TARGETS, "key"))
        self.editor = BindingEditor(self.context, mode, targets, kind)
        self.editor_holder.addWidget(self.editor)

    def _switch_mode(self) -> None:
        mode = self.mode_combo.currentData()
        self._build_editor(mode)
        self._reload_live()

    def _reload_live(self) -> None:
        while self.live_layout.count():
            item = self.live_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        for mode in (ControlMode.MEDIA, ControlMode.PRESENTATION):
            bindings = self.context.bindings(mode)
            for gesture, action in bindings.items():
                if action.kind == "none":
                    continue
                line = QLabel(f"{mode.label}: {gesture.replace('_', ' ').title()} -> "
                              f"{action.target.replace('_', ' ').title()}")
                line.setObjectName("muted")
                self.live_layout.addWidget(line)

    def refresh(self) -> None:
        if self.editor is not None:
            self.editor.reload()
        self._reload_live()
