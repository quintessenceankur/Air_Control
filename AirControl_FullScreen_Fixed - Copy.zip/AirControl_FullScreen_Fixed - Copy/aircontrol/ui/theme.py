"""Dark theme: palette constants, Qt stylesheet and typography helpers.

One place to change the look. Pages use object names (``#card``, ``#h1``) and
the QSS below styles them, so no page contains colour literals.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Palette:
    background: str = "#0A0E15"
    background_alt: str = "#0F1520"
    surface: str = "#141B28"
    surface_alt: str = "#1B2434"
    border: str = "#243044"
    text: str = "#E8EEF9"
    text_muted: str = "#8B9AB3"
    accent: str = "#4C8DFF"
    accent_soft: str = "#1E3A66"
    success: str = "#31D0AA"
    warning: str = "#FFB347"
    danger: str = "#FF5C7A"
    purple: str = "#A78BFA"


PALETTE = Palette()

FONT_STACK = '"Segoe UI", "Inter", "Noto Sans", sans-serif'
MONO_STACK = '"Cascadia Mono", "Consolas", monospace'


def stylesheet() -> str:
    """The application stylesheet."""
    p = PALETTE
    return f"""
* {{
    font-family: {FONT_STACK};
    color: {p.text};
    font-size: 13px;
}}
QWidget#root {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 {p.background}, stop:0.55 {p.background_alt}, stop:1 #0C1220);
}}
QFrame#sidebar {{
    background: rgba(18, 25, 38, 0.92);
    border-right: 1px solid {p.border};
}}
QFrame#card {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 rgba(28, 38, 56, 0.92), stop:1 rgba(18, 25, 38, 0.92));
    border: 1px solid {p.border};
    border-radius: 16px;
}}
QFrame#card:hover {{
    border: 1px solid #2F405C;
}}
QLabel#h1 {{ font-size: 26px; font-weight: 700; letter-spacing: 0.2px; }}
QLabel#h2 {{ font-size: 18px; font-weight: 600; }}
QLabel#h3 {{ font-size: 14px; font-weight: 600; }}
QLabel#muted {{ color: {p.text_muted}; font-size: 12px; }}
QLabel#caption {{ color: {p.text_muted}; font-size: 11px; letter-spacing: 0.4px; }}
QLabel#statValue {{ font-size: 30px; font-weight: 700; color: {p.text}; }}
QLabel#statLabel {{ color: {p.text_muted}; font-size: 11px; text-transform: uppercase;
                   letter-spacing: 1.1px; }}
QLabel#brand {{ font-size: 19px; font-weight: 700; letter-spacing: 1px; }}
QLabel#badge {{
    background: rgba(76, 141, 255, 0.16);
    color: {p.accent};
    border: 1px solid rgba(76, 141, 255, 0.35);
    border-radius: 10px;
    padding: 3px 10px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.6px;
}}
QLabel#pillOn {{
    background: rgba(49, 208, 170, 0.14); color: {p.success};
    border: 1px solid rgba(49, 208, 170, 0.4); border-radius: 11px;
    padding: 3px 10px; font-size: 11px; font-weight: 600;
}}
QLabel#pillOff {{
    background: rgba(139, 154, 179, 0.12); color: {p.text_muted};
    border: 1px solid {p.border}; border-radius: 11px;
    padding: 3px 10px; font-size: 11px; font-weight: 600;
}}
QLabel#pillWarn {{
    background: rgba(255, 179, 71, 0.14); color: {p.warning};
    border: 1px solid rgba(255, 179, 71, 0.4); border-radius: 11px;
    padding: 3px 10px; font-size: 11px; font-weight: 600;
}}
QPushButton {{
    background: {p.surface_alt};
    border: 1px solid {p.border};
    border-radius: 10px;
    padding: 9px 16px;
    font-weight: 600;
}}
QPushButton:hover {{ background: #223047; border-color: #33455F; }}
QPushButton:pressed {{ background: #1A2434; }}
QPushButton:disabled {{ color: #5A687E; background: #121A26; }}
QPushButton#primary {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 {p.accent}, stop:1 #6FA8FF);
    color: #06101F; border: none;
}}
QPushButton#primary:hover {{ background: #6FA8FF; }}
QPushButton#danger {{
    background: rgba(255, 92, 122, 0.16);
    border: 1px solid rgba(255, 92, 122, 0.5);
    color: {p.danger};
}}
QPushButton#danger:hover {{ background: rgba(255, 92, 122, 0.28); }}
QPushButton#nav {{
    text-align: left;
    padding: 10px 14px;
    border: 1px solid transparent;
    border-radius: 10px;
    background: transparent;
    color: {p.text_muted};
    font-weight: 500;
}}
QPushButton#nav:hover {{ background: rgba(76, 141, 255, 0.08); color: {p.text}; }}
QPushButton#nav:checked {{
    background: rgba(76, 141, 255, 0.16);
    border: 1px solid rgba(76, 141, 255, 0.35);
    color: {p.text};
    font-weight: 600;
}}
QSlider::groove:horizontal {{
    height: 6px; background: {p.surface_alt}; border-radius: 3px;
}}
QSlider::sub-page:horizontal {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 {p.accent}, stop:1 {p.success});
    border-radius: 3px;
}}
QSlider::handle:horizontal {{
    background: #E8EEF9; width: 16px; margin: -6px 0; border-radius: 8px;
}}
QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox {{
    background: {p.surface_alt};
    border: 1px solid {p.border};
    border-radius: 9px;
    padding: 7px 10px;
    min-height: 18px;
}}
QComboBox:focus, QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus {{
    border-color: {p.accent};
}}
QComboBox QAbstractItemView {{
    background: {p.surface};
    border: 1px solid {p.border};
    selection-background-color: {p.accent_soft};
    outline: none;
}}
QCheckBox {{ spacing: 10px; color: {p.text}; }}
QCheckBox::indicator {{
    width: 38px; height: 20px; border-radius: 10px;
    background: {p.surface_alt}; border: 1px solid {p.border};
}}
QCheckBox::indicator:checked {{
    background: {p.accent}; border-color: {p.accent};
}}
QTableWidget {{
    background: transparent; border: none; gridline-color: {p.border};
    selection-background-color: rgba(76, 141, 255, 0.18);
}}
QHeaderView::section {{
    background: transparent; color: {p.text_muted}; border: none;
    padding: 6px 4px; font-size: 11px; text-transform: uppercase;
    letter-spacing: 0.8px;
}}
QScrollArea {{ background: transparent; border: none; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{
    background: #2A3648; border-radius: 5px; min-height: 30px;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QToolTip {{
    background: {p.surface}; color: {p.text};
    border: 1px solid {p.border}; padding: 6px; border-radius: 6px;
}}
QStatusBar {{ background: transparent; color: {p.text_muted}; }}
QSplitter::handle {{ background: {p.border}; }}
"""
