"""Reusable UI components.

Every page is built from these; no page paints its own chrome. Components are
presentational only -- they hold no recognition state and call no controller.
"""

from __future__ import annotations

from typing import Iterable, Sequence

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import (
    QCheckBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from aircontrol.ui.theme import PALETTE


class Card(QFrame):
    """A rounded, bordered surface with an optional title and subtitle."""

    def __init__(self, title: str = "", subtitle: str = "", parent: QWidget | None = None):
        super().__init__(parent)
        self.setObjectName("card")
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(18, 16, 18, 16)
        self._layout.setSpacing(10)
        if title:
            header = QVBoxLayout()
            header.setSpacing(2)
            title_label = QLabel(title)
            title_label.setObjectName("h2")
            header.addWidget(title_label)
            if subtitle:
                subtitle_label = QLabel(subtitle)
                subtitle_label.setObjectName("muted")
                subtitle_label.setWordWrap(True)
                header.addWidget(subtitle_label)
            self._layout.addLayout(header)

    def body(self) -> QVBoxLayout:
        return self._layout

    def add(self, widget: QWidget) -> QWidget:
        self._layout.addWidget(widget)
        return widget


class StatTile(Card):
    """A headline number with a label and a footnote."""

    def __init__(self, label: str, value: str = "0", caption: str = "",
                 accent: str | None = None, parent: QWidget | None = None):
        super().__init__(parent=parent)
        self.value_label = QLabel(value)
        self.value_label.setObjectName("statValue")
        if accent:
            self.value_label.setStyleSheet(f"color: {accent};")
        label_widget = QLabel(label)
        label_widget.setObjectName("statLabel")
        self._layout.addWidget(label_widget)
        self._layout.addWidget(self.value_label)
        self.caption_label = QLabel(caption)
        self.caption_label.setObjectName("caption")
        self.caption_label.setWordWrap(True)
        self._layout.addWidget(self.caption_label)
        self.setMinimumHeight(112)

    def set_value(self, value: str, caption: str | None = None) -> None:
        self.value_label.setText(value)
        if caption is not None:
            self.caption_label.setText(caption)


class Pill(QLabel):
    """A small state chip: on / off / warning."""

    def __init__(self, text: str = "", state: str = "off", parent: QWidget | None = None):
        super().__init__(text, parent)
        self.setAlignment(Qt.AlignCenter)
        self.set_state(state)

    def set_state(self, state: str, text: str | None = None) -> None:
        self.setObjectName({"on": "pillOn", "warn": "pillWarn"}.get(state, "pillOff"))
        if text is not None:
            self.setText(text)
        self.style().unpolish(self)
        self.style().polish(self)


class MeterBar(QWidget):
    """A thin horizontal bar showing a 0..1 value with an optional target tick."""

    def __init__(self, value: float = 0.0, colour: str = PALETTE.accent,
                 target: float | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self._value = max(0.0, min(1.0, value))
        self._colour = colour
        self._target = target
        self.setMinimumHeight(8)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def set_value(self, value: float) -> None:
        value = max(0.0, min(1.0, float(value)))
        if abs(value - self._value) > 1e-4:
            self._value = value
            self.update()

    def paintEvent(self, _event) -> None:  # noqa: N802 - Qt naming
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = self.rect().adjusted(0, 0, 0, -1)
        radius = rect.height() / 2
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(PALETTE.surface_alt))
        painter.drawRoundedRect(rect, radius, radius)
        filled = int(rect.width() * self._value)
        if filled > 0:
            painter.setBrush(QColor(self._colour))
            painter.drawRoundedRect(rect.adjusted(0, 0, -(rect.width() - filled), 0),
                                    radius, radius)
        if self._target is not None:
            x = int(rect.width() * self._target)
            painter.setPen(QPen(QColor(PALETTE.text_muted), 1, Qt.DashLine))
            painter.drawLine(x, 0, x, rect.height())


class Sparkline(QWidget):
    """Minimal bar chart for daily counts."""

    def __init__(self, values: Sequence[int] | None = None,
                 parent: QWidget | None = None):
        super().__init__(parent)
        self._values = list(values or [])
        self.setMinimumHeight(90)

    def set_values(self, values: Iterable[int]) -> None:
        self._values = [int(v) for v in values]
        self.update()

    def paintEvent(self, _event) -> None:  # noqa: N802 - Qt naming
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        values = self._values
        if not values:
            painter.setPen(QColor(PALETTE.text_muted))
            painter.drawText(self.rect(), Qt.AlignCenter, "No activity yet")
            return
        peak = max(values) or 1
        width = self.width()
        height = self.height()
        gap = 4
        bar_width = max(3, (width - gap * (len(values) - 1)) / max(1, len(values)))
        for index, value in enumerate(values):
            bar_height = max(2, (height - 6) * value / peak)
            x = index * (bar_width + gap)
            colour = QColor(PALETTE.accent if value else PALETTE.surface_alt)
            if value and value == peak:
                colour = QColor(PALETTE.success)
            painter.setPen(Qt.NoPen)
            painter.setBrush(colour)
            painter.drawRoundedRect(int(x), int(height - bar_height),
                                    int(bar_width), int(bar_height), 3, 3)


class GestureChip(QWidget):
    """Gesture name plus its live confidence bar."""

    def __init__(self, name: str, parent: QWidget | None = None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 2, 0, 2)
        layout.setSpacing(4)
        row = QHBoxLayout()
        self.name_label = QLabel(name.replace("_", " ").title())
        self.name_label.setObjectName("h3")
        self.score_label = QLabel("0.00")
        self.score_label.setObjectName("muted")
        self.score_label.setAlignment(Qt.AlignRight)
        row.addWidget(self.name_label)
        row.addStretch(1)
        row.addWidget(self.score_label)
        layout.addLayout(row)
        self.bar = MeterBar(0.0, PALETTE.accent, target=0.80)
        layout.addWidget(self.bar)

    def set_score(self, score: float) -> None:
        self.bar.set_value(score)
        self.score_label.setText(f"{score:.2f}")
        colour = PALETTE.success if score >= 0.8 else (
            PALETTE.warning if score >= 0.6 else PALETTE.text_muted)
        self.bar._colour = colour
        self.bar.update()


class ToggleRow(QWidget):
    """A labelled on/off switch with a one-line explanation."""

    def __init__(self, title: str, description: str = "", checked: bool = False,
                 parent: QWidget | None = None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 4, 0, 4)
        layout.setSpacing(12)
        text = QVBoxLayout()
        text.setSpacing(1)
        self.title = QLabel(title)
        self.title.setObjectName("h3")
        text.addWidget(self.title)
        if description:
            hint = QLabel(description)
            hint.setObjectName("muted")
            hint.setWordWrap(True)
            text.addWidget(hint)
        layout.addLayout(text, 1)
        self.checkbox = QCheckBox()
        self.checkbox.setChecked(checked)
        layout.addWidget(self.checkbox, 0, Qt.AlignRight)

    def is_checked(self) -> bool:
        return self.checkbox.isChecked()

    def set_checked(self, value: bool) -> None:
        self.checkbox.setChecked(bool(value))


class SliderRow(QWidget):
    """A labelled slider with a numeric readout."""

    def __init__(self, title: str, minimum: int, maximum: int, value: int,
                 suffix: str = "", parent: QWidget | None = None):
        super().__init__(parent)
        from PySide6.QtWidgets import QSlider

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 4, 0, 4)
        layout.setSpacing(4)
        header = QHBoxLayout()
        label = QLabel(title)
        label.setObjectName("h3")
        self.readout = QLabel(f"{value}{suffix}")
        self.readout.setObjectName("muted")
        header.addWidget(label)
        header.addStretch(1)
        header.addWidget(self.readout)
        layout.addLayout(header)
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(minimum, maximum)
        self.slider.setValue(value)
        self._suffix = suffix
        self.slider.valueChanged.connect(
            lambda v: self.readout.setText(f"{v}{self._suffix}"))
        layout.addWidget(self.slider)

    def value(self) -> int:
        return self.slider.value()


def section_title(text: str, subtitle: str = "") -> QWidget:
    """Page heading block."""
    holder = QWidget()
    layout = QVBoxLayout(holder)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(2)
    title = QLabel(text)
    title.setObjectName("h1")
    layout.addWidget(title)
    if subtitle:
        sub = QLabel(subtitle)
        sub.setObjectName("muted")
        sub.setWordWrap(True)
        layout.addWidget(sub)
    return holder


def hbox(*widgets: QWidget, spacing: int = 12) -> QWidget:
    holder = QWidget()
    layout = QHBoxLayout(holder)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(spacing)
    for widget in widgets:
        layout.addWidget(widget)
    return holder


def mono_label(text: str = "") -> QLabel:
    label = QLabel(text)
    label.setObjectName("muted")
    font = QFont("Cascadia Mono")
    font.setStyleHint(QFont.Monospace)
    font.setPointSize(9)
    label.setFont(font)
    return label


def primary_button(text: str) -> QPushButton:
    button = QPushButton(text)
    button.setObjectName("primary")
    button.setCursor(Qt.PointingHandCursor)
    return button


def danger_button(text: str) -> QPushButton:
    button = QPushButton(text)
    button.setObjectName("danger")
    button.setCursor(Qt.PointingHandCursor)
    return button
