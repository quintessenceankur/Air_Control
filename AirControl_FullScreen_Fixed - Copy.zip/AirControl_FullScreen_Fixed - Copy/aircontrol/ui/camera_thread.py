"""The camera thread: capture -> detect -> engine -> controllers.

This is the only place the vision, core and automation layers are wired
together, and it runs entirely off the Qt main thread. The UI talks to it
through signals only; it never touches a widget.
"""

from __future__ import annotations

import logging
import time

from PySide6.QtCore import QThread, Signal
from PySide6.QtGui import QImage

from aircontrol.config import AppConfig
from aircontrol.controllers.manager import ControllerManager
from aircontrol.core.gestures.engine import GestureEngine
from aircontrol.core.gestures.events import GestureEvent, RecognitionState
from aircontrol.services.session import SessionTracker
from aircontrol.ui.overlay import render_frame
from aircontrol.vision.capture import CameraCapture, CameraError
from aircontrol.vision.detector import DetectorError, HandLandmarkerDetector

log = logging.getLogger(__name__)


class CameraWorker(QThread):
    """Runs the recognition loop until :meth:`stop` is called.

    Signals:
        frame_ready(QImage): preview frame, throttled to ``preview_fps``.
        state_ready(dict): recognition state plus controller status.
        events_ready(list): gesture activations fired this frame.
        fps_ready(float): measured processing rate.
        failed(str): the camera or model could not be used.
        status(str): human-readable status line.
    """

    frame_ready = Signal(QImage)
    state_ready = Signal(dict)
    events_ready = Signal(list)
    fps_ready = Signal(float)
    failed = Signal(str)
    status = Signal(str)

    def __init__(self, config: AppConfig, engine: GestureEngine,
                 manager: ControllerManager, session: SessionTracker | None = None,
                 capture_factory=None, max_frames: int | None = None,
                 parent=None) -> None:
        super().__init__(parent)
        self.config = config
        self.engine = engine
        self.manager = manager
        self.session = session
        self._capture_factory = capture_factory
        self._max_frames = max_frames  # smoke-test hook: stop after N frames
        self.frames_processed = 0
        self._running = False
        self._last_frame_emit = 0.0
        self._last_state_emit = 0.0
        self._fps = 0.0
        self._frame_times: list[float] = []
        self.last_hands: list = []
        self.last_state: RecognitionState = RecognitionState()

    # -- control ------------------------------------------------------------
    def stop(self) -> None:
        """Ask the loop to finish. Call ``wait()`` afterwards."""
        self._running = False

    def run(self) -> None:  # noqa: D102 - QThread entry point
        capture = CameraCapture(self.config.camera, factory=self._capture_factory)
        detector = None
        try:
            self.status.emit("Starting camera")
            try:
                capture.open()
            except CameraError as exc:
                log.error("camera error: %s", exc)
                self.failed.emit(str(exc))
                return
            try:
                detector = HandLandmarkerDetector(
                    self.config.model_file(),
                    min_detection_confidence=self.config.recognition.min_presence,
                    min_presence_confidence=self.config.recognition.min_presence)
            except DetectorError as exc:
                log.error("detector error: %s", exc)
                self.failed.emit(str(exc))
                return

            self.status.emit("Tracking")
            self._running = True
            preview_interval = 1.0 / max(1, self.config.ui.preview_fps)
            while self._running:
                frame = capture.read()
                if frame is None:
                    continue
                hands = detector.detect(frame.image, int(frame.timestamp * 1000))
                events = self.engine.update(hands, now=frame.timestamp)
                state = self.engine.state
                acted = self.manager.handle(events, state, frame.timestamp)
                if self.session is not None:
                    for event in events:
                        self.session.record(event.name, event.confidence,
                                            event in acted,
                                            self.manager.mode.value, frame.timestamp)

                self.frames_processed += 1
                self._track_fps()
                self._emit_preview(frame, hands, state, preview_interval)
                self._emit_state(state, events)
                if self._max_frames is not None and self.frames_processed >= self._max_frames:
                    self._running = False

            self.status.emit("Stopped")
        except CameraError as exc:
            log.error("camera stopped: %s", exc)
            self.failed.emit(str(exc))
        except Exception as exc:  # pragma: no cover - defensive
            log.exception("camera loop crashed")
            self.failed.emit(f"Recognition loop stopped: {exc}")
        finally:
            if detector is not None:
                detector.close()
            capture.close()
            self._running = False

    # -- internals ----------------------------------------------------------
    def _track_fps(self) -> None:
        now = time.monotonic()
        self._frame_times.append(now)
        cutoff = now - 1.0
        while self._frame_times and self._frame_times[0] < cutoff:
            self._frame_times.pop(0)
        self._fps = float(len(self._frame_times))

    def _emit_preview(self, frame, hands, state: RecognitionState,
                      interval: float) -> None:
        now = time.monotonic()
        if now - self._last_frame_emit < interval:
            return
        self._last_frame_emit = now
        self.last_hands = hands
        self.last_state = state
        image = render_frame(frame.image, hands, state,
                             show_landmarks=self.config.ui.show_landmarks,
                             fps=self._fps,
                             mode_label=self.manager.mode.label
                             if self.manager.enabled else "Off")
        self.frame_ready.emit(image)

    def _emit_state(self, state: RecognitionState, events: list[GestureEvent]) -> None:
        now = time.monotonic()
        if events:
            self.events_ready.emit(events)
        if now - self._last_state_emit < 1.0 / 15.0:
            return
        self._last_state_emit = now
        self.fps_ready.emit(self._fps)
        self.state_ready.emit({
            "state": state,
            "fps": self._fps,
            "enabled": self.manager.enabled,
            "mode": self.manager.mode.value,
            "last_action": self.manager.last_action,
            "actions_fired": self.manager.actions_fired,
            "air_mouse": self.manager.air_mouse.status,
        })
