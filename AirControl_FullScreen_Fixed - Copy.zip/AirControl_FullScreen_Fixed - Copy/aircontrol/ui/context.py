"""Application context shared by the pages.

One object passed to every page instead of a web of imports: pages ask the
context for services and call its callbacks when something changes. That
keeps the UI free of business logic and makes each page testable with a fake
context.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from aircontrol.automation.base import ActionExecutor
from aircontrol.automation.screen import ScreenBounds
from aircontrol.config import AppConfig
from aircontrol.controllers.manager import ControllerManager
from aircontrol.core.actions import ControlMode
from aircontrol.core.gestures.engine import GestureEngine
from aircontrol.data.analytics import Analytics
from aircontrol.data.repository import Repository
from aircontrol.services.calibration import CalibrationService
from aircontrol.services.practice import PracticeService
from aircontrol.services.safety import SafetyManager
from aircontrol.services.session import SessionTracker


@dataclass
class AppContext:
    """Services the UI may use, plus the callbacks that change app state."""

    config: AppConfig
    engine: GestureEngine
    manager: ControllerManager
    safety: SafetyManager
    executor: ActionExecutor
    repository: Repository | None = None
    analytics: Analytics | None = None
    calibration: CalibrationService | None = None
    practice: PracticeService | None = None
    session: SessionTracker | None = None
    on_config_changed: Callable[[], None] = lambda: None
    on_mode_changed: Callable[[ControlMode], None] = lambda mode: None
    on_enabled_changed: Callable[[bool], None] = lambda enabled: None
    on_restore_defaults: Callable[[], None] = lambda: None
    camera_available: bool = True
    screen_resolver: Callable[[], ScreenBounds] | None = None
    """Re-queries the display; supplied by the app so pages need no Qt screen code."""

    # -- convenience --------------------------------------------------------
    def set_mode(self, mode: ControlMode) -> None:
        self.manager.set_mode(mode)
        self.on_mode_changed(mode)

    def set_enabled(self, enabled: bool) -> None:
        if enabled:
            self.safety.arm(confirm=True)
        else:
            self.safety.disarm()
        self.on_enabled_changed(self.manager.enabled)

    def emergency_stop(self) -> None:
        self.safety.emergency_stop()
        self.on_enabled_changed(False)

    def bindings(self, mode: ControlMode):
        if self.repository is None:
            from aircontrol.core.actions import bindings_for
            return bindings_for(mode)
        return self.repository.load_bindings(mode)

    def save_bindings(self, mode: ControlMode, bindings) -> None:
        if self.repository is not None:
            self.repository.save_bindings(mode, bindings)
        controller = (self.manager.media if mode is ControlMode.MEDIA
                      else self.manager.presentation)
        controller.bindings = dict(bindings)

    def apply_air_mouse_config(self) -> None:
        """Push the current air-mouse settings into the running controller.

        Called by the Air Mouse page after the sliders change, so gain,
        sensitivity, smoothing and dead zone take effect immediately rather
        than at restart.
        """
        self.manager.apply_air_mouse_config(self.config.air_mouse)

    def refresh_screen_bounds(self) -> ScreenBounds:
        """Re-detect the desktop and re-target the air mouse."""
        if self.screen_resolver is not None:
            self.manager.set_screen_bounds(self.screen_resolver())
        return self.manager.screen_bounds

    def save_config(self) -> None:
        try:
            self.config.save()
        finally:
            self.on_config_changed()
