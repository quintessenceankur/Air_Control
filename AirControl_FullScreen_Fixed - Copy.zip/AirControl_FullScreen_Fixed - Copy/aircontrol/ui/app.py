"""QApplication bootstrap and dependency wiring.

Everything is constructed here and passed explicitly: config, database,
engine, executor, controllers, safety, session tracking and the camera thread.
No module-level singletons.
"""

from __future__ import annotations

import logging

from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import QApplication

from aircontrol import APP_NAME, __version__
from aircontrol.automation.base import NullExecutor
from aircontrol.automation.screen import (
    ScreenBounds,
    describe_environment,
    resolve_screen_bounds,
)
from aircontrol.automation.system import build_executor
from aircontrol.config import AppConfig, load_config
from aircontrol.controllers.manager import ControllerManager
from aircontrol.core.actions import ControlMode
from aircontrol.core.gestures.engine import GestureEngine
from aircontrol.core.gestures.spec import EngineConfig
from aircontrol.data.analytics import Analytics
from aircontrol.data.repository import Repository, RepositoryError
from aircontrol.logging_setup import configure_logging
from aircontrol.services.calibration import CalibrationService
from aircontrol.services.practice import PracticeService
from aircontrol.services.safety import HotkeyConfig, SafetyManager
from aircontrol.services.session import SessionTracker
from aircontrol.ui.camera_thread import CameraWorker
from aircontrol.ui.context import AppContext
from aircontrol.ui.main_window import MainWindow
from aircontrol.ui.theme import stylesheet

log = logging.getLogger(__name__)


def build_engine(config: AppConfig) -> GestureEngine:
    """Create the recognition engine, optionally with the ML scorer."""
    engine_config = EngineConfig(
        ema_alpha=config.recognition.ema_alpha,
        min_presence=config.recognition.min_presence,
        pinch_enter_ratio=config.recognition.pinch_enter_ratio,
        pinch_exit_ratio=config.recognition.pinch_exit_ratio,
        ml_weight=config.recognition.ml_weight if config.recognition.ml_enabled else 0.0,
    )
    scorer = None
    if config.recognition.ml_enabled:
        from aircontrol.ml.inference import load_default
        classifier = load_default()
        if classifier is not None:
            scorer = classifier
            log.info("ML classifier loaded (%s)", classifier.metrics)
        else:
            log.warning("ML requested but no artifact found; geometric only")
    return GestureEngine(config=engine_config, ml_scorer=scorer)


def build_context(config: AppConfig, *, with_camera: bool = True) -> AppContext:
    """Wire the application graph. Returns the context the window needs."""
    executor = build_executor()
    if executor is None:
        log.warning("running without a desktop backend; actions are suppressed")
        executor = NullExecutor()

    repository: Repository | None = None
    analytics: Analytics | None = None
    calibration: CalibrationService | None = None
    practice: PracticeService | None = None
    session: SessionTracker | None = None
    try:
        repository = Repository.open(str(config.storage.resolved_database_path()))
        analytics = Analytics(repository.conn)
        calibration = CalibrationService(repository)
        practice = PracticeService(repository)
        session = SessionTracker(repository)
        calibration.apply_to(config)
    except RepositoryError as exc:
        log.error("database unavailable, running without persistence: %s", exc)

    # The camera does not depend on the automation backend: on a machine with
    # no desktop backend the UI still previews and recognises, it just cannot
    # act. Only a missing model makes the camera path impossible.
    camera_available = config.model_file().exists()
    engine = build_engine(config)

    # Cursor mapping must use the space the injector writes to, not Qt's
    # logical geometry: on a 125% display those differ by 1.25, and using the
    # logical size capped the cursor at 80% of the desktop. See
    # aircontrol/automation/screen.py for why Win32 metrics are authoritative.
    screen = QGuiApplication.primaryScreen()
    screen_bounds = resolve_screen_bounds(screen)
    for line in describe_environment(screen):
        log.info("display: %s", line)
    log.info("air mouse maps the full desktop: %s (x 0-%d, y 0-%d)",
             screen_bounds.describe(), screen_bounds.max_x, screen_bounds.max_y)

    def _resolve_bounds() -> ScreenBounds:
        """Re-query the display, e.g. after a resolution or scaling change."""
        return resolve_screen_bounds(QGuiApplication.primaryScreen())

    manager = ControllerManager(
        executor, mode=ControlMode.NONE,
        enabled=config.safety.start_enabled,
        air_mouse_config=config.air_mouse, screen_bounds=screen_bounds)
    if repository is not None:
        try:
            manager.media.bindings = repository.load_bindings(ControlMode.MEDIA)
            manager.presentation.bindings = repository.load_bindings(ControlMode.PRESENTATION)
            manager.air_mouse.roles = repository.load_air_mouse_roles()
            manager.air_mouse._inverse = {role: gesture for gesture, role
                                          in manager.air_mouse.roles.items()}
        except RepositoryError as exc:
            log.warning("could not load saved bindings: %s", exc)

    safety = SafetyManager(
        manager, HotkeyConfig(toggle=config.safety.toggle_hotkey,
                              emergency=config.safety.emergency_hotkey,
                              enabled=config.safety.hotkeys_enabled))

    def _on_action(gesture: str, label: str, confidence: float) -> None:
        log.info("action: %s -> %s (%.2f)", gesture, label, confidence)

    manager.on_action = _on_action

    def _restore_defaults() -> None:
        if repository is not None:
            repository.reset_all()
        for section in ("camera", "recognition", "air_mouse", "ui", "safety"):
            setattr(config, section, type(getattr(config, section))())
        config.save()
        manager.media.bindings = __import__(
            "aircontrol.core.actions", fromlist=["DEFAULT_MEDIA_BINDINGS"]
        ).DEFAULT_MEDIA_BINDINGS
        manager.set_mode(ControlMode.NONE)
        manager.set_enabled(False)

    context = AppContext(
        config=config, engine=engine, manager=manager, safety=safety,
        executor=executor, repository=repository, analytics=analytics,
        calibration=calibration, practice=practice, session=session,
        on_restore_defaults=_restore_defaults, camera_available=camera_available,
        screen_resolver=_resolve_bounds)
    return context


def run(argv: list[str] | None = None, config: AppConfig | None = None) -> int:
    """Start the desktop application. Returns the process exit code."""
    config = config or load_config()
    configure_logging(config.storage.log_level)
    log.info("AirControl %s starting", __version__)

    app = QApplication(argv if argv is not None else [])
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(__version__)
    app.setStyleSheet(stylesheet())

    context = build_context(config)
    worker = None
    if context.camera_available:
        worker = CameraWorker(config, context.engine, context.manager,
                              context.session)
    window = MainWindow(context, worker)
    window.show()

    if context.session is not None:
        context.session.start()
    context.safety.start_hotkeys()

    try:
        return app.exec()
    finally:
        context.safety.stop_hotkeys()
        if context.session is not None:
            context.session.end()
        if context.repository is not None:
            context.repository.close()
