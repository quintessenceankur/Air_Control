"""Main window: sidebar navigation, header and the camera thread wiring."""

from __future__ import annotations

import logging

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QCloseEvent
from PySide6.QtWidgets import (
    QButtonGroup,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from aircontrol.core.actions import ControlMode
from aircontrol.ui.camera_thread import CameraWorker
from aircontrol.ui.components import Pill, danger_button, primary_button
from aircontrol.ui.context import AppContext
from aircontrol.ui.pages.air_mouse import AirMousePage
from aircontrol.ui.pages.analytics import AnalyticsPage
from aircontrol.ui.pages.custom import CustomGesturePage
from aircontrol.ui.pages.dashboard import DashboardPage
from aircontrol.ui.pages.live_studio import LiveStudioPage
from aircontrol.ui.pages.media import MediaPage
from aircontrol.ui.pages.presentation import PresentationPage
from aircontrol.ui.pages.settings import SettingsPage
from aircontrol.ui.pages.training import TrainingPage

log = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    """The application shell. Owns the worker thread and nothing else."""

    def __init__(self, context: AppContext, worker: CameraWorker | None = None,
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.context = context
        self.worker = worker
        self.setWindowTitle("AirControl")
        self.setMinimumSize(1180, 760)
        self._closing = False
        self._build()
        self._connect_worker()

    # -- construction -------------------------------------------------------
    def _build(self) -> None:
        root = QWidget()
        root.setObjectName("root")
        layout = QHBoxLayout(root)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        layout.addWidget(self._build_sidebar())

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)
        right_layout.addWidget(self._build_header())

        self.stack = QStackedWidget()
        self.pages = {
            "dashboard": DashboardPage(self.context),
            "live": LiveStudioPage(self.context),
            "air_mouse": AirMousePage(self.context),
            "media": MediaPage(self.context),
            "presentation": PresentationPage(self.context),
            "training": TrainingPage(self.context),
            "custom": CustomGesturePage(self.context),
            "analytics": AnalyticsPage(self.context),
            "settings": SettingsPage(self.context),
        }
        for page in self.pages.values():
            self.stack.addWidget(page)
        right_layout.addWidget(self.stack, 1)
        layout.addWidget(right, 1)

        self.setCentralWidget(root)
        self.statusBar().showMessage("Ready")
        self._show_page("dashboard")

    def _build_sidebar(self) -> QWidget:
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(228)
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(16, 20, 16, 18)
        layout.setSpacing(6)

        brand = QLabel("AIRCONTROL")
        brand.setObjectName("brand")
        layout.addWidget(brand)
        tagline = QLabel("Gesture control")
        tagline.setObjectName("muted")
        layout.addWidget(tagline)
        layout.addSpacing(16)

        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        entries = (
            ("dashboard", "Dashboard"),
            ("live", "Live Gesture Studio"),
            ("air_mouse", "Air Mouse"),
            ("media", "Media Controls"),
            ("presentation", "Presentation"),
            ("training", "Training Arena"),
            ("custom", "Custom Gesture Studio"),
            ("analytics", "Analytics"),
            ("settings", "Settings"),
        )
        for key, label in entries:
            button = QPushButton(label)
            button.setObjectName("nav")
            button.setCheckable(True)
            button.setCursor(Qt.PointingHandCursor)
            button.clicked.connect(lambda _checked=False, k=key: self._show_page(k))
            self.nav_group.addButton(button)
            layout.addWidget(button)
        layout.addStretch(1)

        self.sidebar_status = QLabel("Control off")
        self.sidebar_status.setObjectName("muted")
        self.sidebar_status.setWordWrap(True)
        layout.addWidget(self.sidebar_status)

        self.sidebar_stop = danger_button("Emergency stop")
        self.sidebar_stop.clicked.connect(self._emergency_stop)
        layout.addWidget(self.sidebar_stop)
        return sidebar

    def _build_header(self) -> QWidget:
        header = QFrame()
        header.setFixedHeight(64)
        header.setStyleSheet("border-bottom: 1px solid #243044;")
        layout = QHBoxLayout(header)
        layout.setContentsMargins(28, 10, 24, 10)
        layout.setSpacing(10)

        self.page_title = QLabel("Dashboard")
        self.page_title.setObjectName("h2")
        layout.addWidget(self.page_title)
        layout.addStretch(1)

        self.camera_pill = Pill("Camera idle", "off")
        self.control_pill = Pill("Control off", "off")
        self.mode_pill = Pill("Idle", "off")
        for pill in (self.camera_pill, self.control_pill, self.mode_pill):
            layout.addWidget(pill)

        self.enable_button = primary_button("Enable control")
        self.enable_button.clicked.connect(self._toggle_control)
        layout.addWidget(self.enable_button)
        return header

    # -- navigation ---------------------------------------------------------
    def _show_page(self, key: str) -> None:
        page = self.pages.get(key)
        if page is None:
            return
        self.stack.setCurrentWidget(page)
        self.page_title.setText(page.title)
        page.refresh()
        for button in self.nav_group.buttons():
            if button.text() == page.title or (
                    key == "live" and button.text() == "Live Gesture Studio"):
                button.setChecked(True)
                break

    # -- worker wiring ------------------------------------------------------
    def _connect_worker(self) -> None:
        if self.worker is None:
            self.camera_pill.set_state("warn", "No camera thread")
            return
        self.worker.frame_ready.connect(self._on_frame)
        self.worker.state_ready.connect(self._on_state)
        self.worker.events_ready.connect(self._on_events)
        self.worker.failed.connect(self._on_failed)
        self.worker.status.connect(lambda text: self.statusBar().showMessage(text))
        self.worker.start()
        self._refresh_header()
        # Refresh persisted statistics periodically without blocking the UI.
        self._stats_timer = QTimer(self)
        self._stats_timer.timeout.connect(self._refresh_stats)
        self._stats_timer.start(15000)

    def _refresh_stats(self) -> None:
        current = self.stack.currentWidget()
        if current is not None:
            current.refresh()

    def _on_frame(self, image) -> None:
        self.pages["live"].show_frame(image)

    def _on_state(self, payload: dict) -> None:
        for page in self.pages.values():
            try:
                page.on_state(payload)
            except Exception:  # pragma: no cover - a page must not kill the stream
                log.exception("page failed to handle state")
        state = payload.get("state")
        if state is not None:
            self.camera_pill.set_state("on" if state.tracking else "off",
                                       "Camera active" if state.tracking else "Camera idle")
        self._refresh_header()

    def _on_events(self, events: list) -> None:
        for event in events:
            for page in self.pages.values():
                try:
                    page.on_event(event)
                except Exception:  # pragma: no cover
                    log.exception("page failed to handle an event")
            self.statusBar().showMessage(
                f"{event.name.replace('_', ' ').title()}  ({event.confidence:.2f})", 3000)

    def _on_failed(self, message: str) -> None:
        log.error("camera thread failed: %s", message)
        self.camera_pill.set_state("warn", "Camera problem")
        self.statusBar().showMessage(message)
        self.pages["live"].preview.setText(
            f"Camera unavailable\n\n{message}")

    # -- control ------------------------------------------------------------
    def _toggle_control(self) -> None:
        enabled = not self.context.manager.enabled
        if enabled and self.context.manager.mode is ControlMode.NONE:
            self.context.set_mode(ControlMode.AIR_MOUSE)
        self.context.set_enabled(enabled)
        self._refresh_header()

    def _emergency_stop(self) -> None:
        self.context.emergency_stop()
        self.statusBar().showMessage("Emergency stop engaged. Gesture control is off.", 5000)
        self._refresh_header()

    def _refresh_header(self) -> None:
        enabled = self.context.manager.enabled
        mode = self.context.manager.mode
        self.control_pill.set_state("on" if enabled else "off",
                                    "Control on" if enabled else "Control off")
        self.mode_pill.set_state("on" if enabled else "off", mode.label)
        self.enable_button.setText("Disable control" if enabled else "Enable control")
        self.sidebar_status.setText(self.context.manager.status_text())
        for page in self.pages.values():
            page.on_enabled_changed(enabled)
            page.on_mode_changed()

    # -- shutdown -----------------------------------------------------------
    def closeEvent(self, event: QCloseEvent) -> None:  # noqa: N802 - Qt naming
        if self._closing:
            event.accept()
            return
        self._closing = True
        log.info("shutting down")
        try:
            if hasattr(self, "_stats_timer"):
                self._stats_timer.stop()
            if self.worker is not None and self.worker.isRunning():
                self.worker.stop()
                if not self.worker.wait(3000):
                    log.warning("camera thread did not stop in time")
            self.context.safety.stop_hotkeys()
            self.context.manager.emergency_stop()
            if self.context.session is not None:
                self.context.session.end()
        finally:
            event.accept()
