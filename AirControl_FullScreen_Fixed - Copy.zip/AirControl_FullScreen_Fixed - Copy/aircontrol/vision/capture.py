"""Webcam capture with explicit lifecycle and failure reporting.

The capture layer produces frames and timestamps. It never decides anything
about gestures: it is the first of the four boundaries.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Callable

import cv2
import numpy as np

from aircontrol.config import CameraConfig

log = logging.getLogger(__name__)


class CameraError(RuntimeError):
    """The camera could not be opened or stopped delivering frames."""


@dataclass(frozen=True)
class Frame:
    """One captured frame plus the clock value the engine will be given."""

    image: np.ndarray
    timestamp: float
    index: int
    width: int
    height: int


def _default_factory(index: int) -> Any:
    """Open a camera, preferring the Windows DirectShow backend."""
    if hasattr(cv2, "CAP_DSHOW"):
        cap = cv2.VideoCapture(index, cv2.CAP_DSHOW)
        if cap.isOpened():
            return cap
        cap.release()
    return cv2.VideoCapture(index)


class CameraCapture:
    """Owns a ``cv2.VideoCapture`` and its lifecycle.

    ``factory`` is injectable so the failure paths (no device, read errors,
    disconnection mid-stream) can be tested without hardware.
    """

    def __init__(self, config: CameraConfig | None = None,
                 factory: Callable[[int], Any] | None = None,
                 max_consecutive_failures: int = 10) -> None:
        self.config = config or CameraConfig()
        self._factory = factory or _default_factory
        self._cap: Any | None = None
        self._frame_index = 0
        self._failures = 0
        self._max_failures = max_consecutive_failures
        self._start = time.monotonic()

    # -- lifecycle ----------------------------------------------------------
    def open(self) -> None:
        """Open the device; raises :class:`CameraError` when it is unavailable."""
        if self._cap is not None:
            return
        cap = self._factory(self.config.index)
        if not getattr(cap, "isOpened", lambda: False)():
            try:
                cap.release()
            finally:
                raise CameraError(
                    f"camera {self.config.index} could not be opened "
                    "(check it is connected and Windows camera privacy allows access)")
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.config.width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.config.height)
        cap.set(cv2.CAP_PROP_FPS, self.config.fps)
        try:
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # drop stale frames
        except Exception:  # pragma: no cover - backend dependent
            pass
        self._cap = cap
        self._failures = 0
        self._start = time.monotonic()
        log.info("camera %s opened (%sx%s @ %s fps)", self.config.index,
                 self.config.width, self.config.height, self.config.fps)

    def read(self) -> Frame | None:
        """Return the next frame, or ``None`` if the device stopped delivering.

        A run of failures raises :class:`CameraError`: the caller can then
        show "camera disconnected" rather than spinning on a dead device.
        """
        if self._cap is None:
            raise CameraError("camera is not open")
        ok, image = self._cap.read()
        if not ok or image is None:
            self._failures += 1
            if self._failures >= self._max_failures:
                raise CameraError("camera stopped delivering frames")
            return None
        self._failures = 0
        if self.config.mirror:
            image = cv2.flip(image, 1)
        height, width = image.shape[:2]
        frame = Frame(image=image, timestamp=time.monotonic() - self._start,
                      index=self._frame_index, width=width, height=height)
        self._frame_index += 1
        return frame

    def close(self) -> None:
        """Release the device. Safe to call twice."""
        if self._cap is not None:
            try:
                self._cap.release()
            finally:
                self._cap = None
                log.info("camera released")

    @property
    def is_open(self) -> bool:
        return self._cap is not None

    def __enter__(self) -> "CameraCapture":
        self.open()
        return self

    def __exit__(self, *_exc) -> None:
        self.close()


def list_cameras(max_devices: int = 5) -> list[int]:
    """Probe for available camera indices (best effort, opens each briefly)."""
    found: list[int] = []
    for index in range(max_devices):
        cap = _default_factory(index)
        try:
            if getattr(cap, "isOpened", lambda: False)():
                found.append(index)
        finally:
            cap.release()
    return found
