"""MediaPipe Tasks HandLandmarker wrapper.

Produces :class:`~aircontrol.core.landmarks.HandFrame` objects and nothing
else: no gesture logic, no smoothing, no thresholds. MediaPipe is imported
inside the constructor so the pure core and the test suite never pay for it.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Sequence

import numpy as np

from aircontrol.config import default_model_path
from aircontrol.core.landmarks import HandFrame, hand_from_array

log = logging.getLogger(__name__)


class DetectorError(RuntimeError):
    """The landmarker could not be created or used."""


class HandLandmarkerDetector:
    """Thin, synchronous wrapper over ``mediapipe.tasks`` HandLandmarker.

    ``detect`` must be called with a strictly increasing timestamp: MediaPipe
    video mode rejects or silently degrades otherwise, which was one of the
    faults in the original prototype.
    """

    def __init__(self, model_path: Path | str | None = None, *, num_hands: int = 2,
                 min_detection_confidence: float = 0.5,
                 min_presence_confidence: float = 0.5,
                 min_tracking_confidence: float = 0.5) -> None:
        self.model_path = Path(model_path) if model_path else default_model_path()
        if not self.model_path.exists():
            raise DetectorError(
                f"hand landmarker model not found at {self.model_path}. "
                "Download hand_landmarker.task into aircontrol/resources/.")
        try:
            import mediapipe as mp
            from mediapipe.tasks import python as mp_python
            from mediapipe.tasks.python import vision
        except Exception as exc:  # pragma: no cover - import-time failure
            raise DetectorError(f"mediapipe unavailable: {exc}") from exc

        self._mp = mp
        options = vision.HandLandmarkerOptions(
            base_options=mp_python.BaseOptions(model_asset_path=str(self.model_path)),
            running_mode=vision.RunningMode.VIDEO,
            num_hands=num_hands,
            min_hand_detection_confidence=min_detection_confidence,
            min_hand_presence_confidence=min_presence_confidence,
            min_tracking_confidence=min_tracking_confidence,
        )
        try:
            self._landmarker = vision.HandLandmarker.create_from_options(options)
        except Exception as exc:  # pragma: no cover - corrupt model
            raise DetectorError(f"could not create hand landmarker: {exc}") from exc
        self._last_timestamp_ms = -1
        self._num_hands = num_hands

    # -- detection ----------------------------------------------------------
    def detect(self, frame: np.ndarray, timestamp_ms: int) -> list[HandFrame]:
        """Run detection on one BGR frame and return the hands found."""
        if frame is None or frame.size == 0:
            raise DetectorError("empty frame")
        try:
            rgb = self._to_rgb(frame)
        except Exception as exc:  # pragma: no cover - defensive
            raise DetectorError(f"frame conversion failed: {exc}") from exc

        timestamp_ms = max(int(timestamp_ms), self._last_timestamp_ms + 1)
        self._last_timestamp_ms = timestamp_ms
        image = self._mp.Image(image_format=self._mp.ImageFormat.SRGB, data=rgb)
        try:
            result = self._landmarker.detect_for_video(image, timestamp_ms)
        except Exception as exc:  # pragma: no cover - MediaPipe internal error
            raise DetectorError(f"detection failed: {exc}") from exc
        return self._to_hands(result)

    def _to_rgb(self, frame: np.ndarray) -> np.ndarray:
        import cv2
        if frame.ndim == 2:
            return cv2.cvtColor(frame, cv2.COLOR_GRAY2RGB)
        return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    def _to_hands(self, result: Any) -> list[HandFrame]:
        """Map a MediaPipe result to :class:`HandFrame` objects.

        The Tasks API exposes no per-hand presence score, so the handedness
        classification score is used as the confidence proxy. That is
        documented rather than hidden: it is the only score available, and
        the engine's presence gate still applies to it.
        """
        hands: list[HandFrame] = []
        landmarks = getattr(result, "hand_landmarks", None) or []
        handedness = getattr(result, "handedness", None) or []
        for index, points in enumerate(landmarks):
            label, score = "Right", 1.0
            if index < len(handedness) and handedness[index]:
                category = handedness[index][0]
                label = getattr(category, "category_name", "Right") or "Right"
                score = float(getattr(category, "score", 1.0) or 0.0)
            array = [[float(p.x), float(p.y), float(p.z)] for p in points]
            hands.append(hand_from_array(array, handedness=label, presence=score))
        return hands

    # -- lifecycle ----------------------------------------------------------
    def close(self) -> None:
        landmarker = getattr(self, "_landmarker", None)
        if landmarker is not None:
            try:
                landmarker.close()
            finally:
                self._landmarker = None

    def __enter__(self) -> "HandLandmarkerDetector":
        return self

    def __exit__(self, *_exc) -> None:
        self.close()

    @property
    def num_hands(self) -> int:
        return self._num_hands


def warm_up(detector: HandLandmarkerDetector, size: tuple[int, int] = (480, 640)) -> None:
    """Run one blank frame so the first real frame is not the slow one."""
    blank = np.zeros((size[0], size[1], 3), dtype=np.uint8)
    try:
        detector.detect(blank, 0)
    except DetectorError:  # pragma: no cover - warm-up is best effort
        log.debug("detector warm-up failed", exc_info=True)
