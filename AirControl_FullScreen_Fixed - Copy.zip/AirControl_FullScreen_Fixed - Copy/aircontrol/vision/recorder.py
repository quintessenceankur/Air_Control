"""Record landmark sequences to JSONL fixtures.

    python -m aircontrol.vision.recorder --out tests/fixtures/pinch_real.jsonl --label PINCH

Each line is ``{"t": seconds, "presence": p, "handedness": "Right",
"landmarks": [[x, y, z] * 21]}``, which is exactly what the replay tests and
``scripts/evaluate_webcam.py`` consume. No video is written: only landmark
coordinates, and only while recording is explicitly requested.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from pathlib import Path

from aircontrol.core.landmarks import HandFrame

log = logging.getLogger(__name__)


class LandmarkRecorder:
    """Appends landmark frames to a JSONL file."""

    def __init__(self, path: Path | str, label: str = "UNLABELLED",
                 expect: list[str] | None = None) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.label = label
        self.expect = expect
        self.frames = 0

    def write(self, hands: list[HandFrame], timestamp: float) -> None:
        """Write one frame; a frame with no hands is recorded as empty."""
        row: dict = {"t": round(float(timestamp), 4), "landmarks": []}
        if hands:
            hand = max(hands, key=lambda h: h.presence)
            row["presence"] = round(float(hand.presence), 4)
            row["handedness"] = hand.handedness
            row["landmarks"] = [[round(p.x, 6), round(p.y, 6), round(p.z, 6)]
                                for p in hand.landmarks]
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row) + "\n")
        self.frames += 1

    def write_meta(self) -> Path:
        """Write the sibling ``.meta.json`` that declares the expectation."""
        meta_path = self.path.with_suffix(".jsonl.meta.json")
        meta_path.write_text(json.dumps({
            "label": self.label,
            "expect": self.expect if self.expect is not None else [self.label],
            "synthetic": False,
            "frames": self.frames,
            "source": self.path.name,
        }, indent=2) + "\n", encoding="utf-8")
        return meta_path


def main(argv: list[str] | None = None) -> int:
    """Interactive recorder. Requires a camera and the model file."""
    from aircontrol.config import load_config
    from aircontrol.vision.capture import CameraCapture, CameraError
    from aircontrol.vision.detector import DetectorError, HandLandmarkerDetector

    parser = argparse.ArgumentParser(description="Record hand landmarks to JSONL")
    parser.add_argument("--out", required=True, help="output .jsonl path")
    parser.add_argument("--label", default="UNLABELLED",
                        help="gesture name the clip should produce")
    parser.add_argument("--seconds", type=float, default=6.0, help="clip length")
    parser.add_argument("--camera", type=int, default=None)
    args = parser.parse_args(argv)

    logging.basicConfig(level=logging.INFO, format="%(message)s")
    config = load_config()
    if args.camera is not None:
        config.camera.index = args.camera

    expect = [] if args.label.upper() == "NEGATIVE" else [args.label]
    recorder = LandmarkRecorder(args.out, label=args.label, expect=expect)

    capture = CameraCapture(config.camera)
    try:
        capture.open()
    except CameraError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    try:
        detector = HandLandmarkerDetector(config.model_file())
    except DetectorError as exc:
        capture.close()
        print(f"error: {exc}", file=sys.stderr)
        return 3

    print(f"Recording {args.seconds:.0f}s of '{args.label}' to {args.out}.")
    print("Hold the pose steady. Press Ctrl+C to stop early.")
    start = time.monotonic()
    try:
        while time.monotonic() - start < args.seconds:
            frame = capture.read()
            if frame is None:
                continue
            hands = detector.detect(frame.image, int(frame.timestamp * 1000))
            recorder.write(hands, frame.timestamp)
    except KeyboardInterrupt:
        print("\nstopped early")
    finally:
        detector.close()
        capture.close()
        recorder.write_meta()
    print(f"wrote {recorder.frames} frames")
    return 0


if __name__ == "__main__":  # pragma: no cover - CLI entry point
    raise SystemExit(main())
