"""Presentation controller: gestures to slide navigation and start/exit."""

from __future__ import annotations

import logging

from aircontrol.automation.base import ActionExecutor
from aircontrol.core.actions import (
    DEFAULT_PRESENTATION_BINDINGS,
    KEY,
    NONE,
    Action,
)
from aircontrol.core.gestures.events import GestureEvent, RecognitionState

log = logging.getLogger(__name__)


class PresentationController:
    """Sends slide-navigation keys, optionally only to a focused window."""

    def __init__(self, executor: ActionExecutor,
                 bindings: dict[str, Action] | None = None,
                 focus_window: str = "",
                 min_interval_ms: int = 300) -> None:
        self.executor = executor
        self.bindings = dict(bindings or DEFAULT_PRESENTATION_BINDINGS)
        self.focus_window = focus_window
        self.min_interval_ms = min_interval_ms
        self._last: dict[str, float] = {}
        self.last_action = ""
        self.blocked = 0

    def handle_event(self, event: GestureEvent, now: float) -> bool:
        action = self.bindings.get(event.name)
        if action is None or action.kind == NONE:
            return False
        if action.kind != KEY:
            log.warning("presentation binding for %s has kind %s; ignored",
                        event.name, action.kind)
            return False
        if self.focus_window and not self.executor.focus_window(self.focus_window):
            self.blocked += 1
            return False
        last = self._last.get(action.target)
        if last is not None and (now - last) * 1000.0 < self.min_interval_ms:
            return False
        self.executor.send_key(action.target)
        self._last[action.target] = now
        self.last_action = action.description or action.target
        return True

    def tick(self, state: RecognitionState, now: float) -> None:  # noqa: D102
        return None

    def reset(self) -> None:
        self._last.clear()
        self.last_action = ""
