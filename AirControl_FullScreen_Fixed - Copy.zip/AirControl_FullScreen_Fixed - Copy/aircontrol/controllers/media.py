"""Media controller: gestures to play/pause, volume, track navigation."""

from __future__ import annotations

import logging

from aircontrol.automation.base import ActionExecutor
from aircontrol.core.actions import DEFAULT_MEDIA_BINDINGS, MEDIA, NONE, Action
from aircontrol.core.gestures.events import GestureEvent, RecognitionState

log = logging.getLogger(__name__)


class MediaController:
    """One-shot media actions with an extra per-action guard interval.

    The engine already debounces and cools down; this second guard exists
    because a media key is a visible, sometimes loud side effect and a
    duplicated volume-up is annoying in a way a duplicated click is not.
    """

    def __init__(self, executor: ActionExecutor,
                 bindings: dict[str, Action] | None = None,
                 min_interval_ms: int = 250) -> None:
        self.executor = executor
        self.bindings = dict(bindings or DEFAULT_MEDIA_BINDINGS)
        self.min_interval_ms = min_interval_ms
        self._last: dict[str, float] = {}
        self.last_action = ""

    def handle_event(self, event: GestureEvent, now: float) -> bool:
        action = self.bindings.get(event.name)
        if action is None or action.kind == NONE:
            return False
        if action.kind != MEDIA:
            log.warning("media binding for %s has kind %s; ignored",
                        event.name, action.kind)
            return False
        last = self._last.get(action.target)
        if last is not None and (now - last) * 1000.0 < self.min_interval_ms:
            return False
        self.executor.media_key(action.target)
        self._last[action.target] = now
        self.last_action = action.description or action.target
        return True

    def tick(self, state: RecognitionState, now: float) -> None:  # noqa: D102
        return None

    def reset(self) -> None:
        self._last.clear()
        self.last_action = ""
