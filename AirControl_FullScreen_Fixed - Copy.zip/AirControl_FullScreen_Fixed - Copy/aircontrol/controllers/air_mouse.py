"""Air Mouse: index fingertip to cursor, pinch to click and drag.

State model
-----------
``pointer`` gesture  move the cursor to the fingertip, smoothed and clamped.
``click`` gesture    press-and-hold becomes a drag after ``drag_delay_s``;
                     a shorter press becomes a left click on release.
``right_click``      one right click per activation.
``scroll``           vertical hand motion scrolls, rate limited.
``pause``            stop acting until the hand changes pose.

Every number used here is a proposed default from
:class:`aircontrol.config.AirMouseConfig`; none of them came from the owner's
specification.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass

from aircontrol.automation.base import ActionExecutor
from aircontrol.automation.screen import ScreenBounds
from aircontrol.config import AirMouseConfig
from aircontrol.core.actions import DEFAULT_AIR_MOUSE_ROLES
from aircontrol.core.gestures.events import GestureEvent, RecognitionState
from aircontrol.core.smoothing import PointerFilter

log = logging.getLogger(__name__)

#: How close to a boundary the filtered cursor must be before it is snapped
#: onto it exactly, in pixels. Two pixels: invisible to the user, and enough
#: for the One Euro filter's asymptotic approach to land on the corner.
EDGE_SNAP_PX = 2.0


@dataclass
class AirMouseStatus:
    """What the UI shows for the air mouse."""

    active: bool = False
    paused: bool = False
    dragging: bool = False
    cursor: tuple[float, float] = (0.0, 0.0)
    last_action: str = ""


class AirMouseController:
    """Gesture-driven pointer, click, drag and scroll."""

    def __init__(self, executor: ActionExecutor, *,
                 config: AirMouseConfig | None = None,
                 screen_size: tuple[int, int] | ScreenBounds = (1920, 1080),
                 screen_bounds: ScreenBounds | None = None,
                 roles: dict[str, str] | None = None) -> None:
        self.executor = executor
        self.config = config or AirMouseConfig()
        self._bounds = _coerce_bounds(screen_bounds or screen_size)
        self.roles = dict(roles or DEFAULT_AIR_MOUSE_ROLES)
        self._inverse = {role: gesture for gesture, role in self.roles.items()}

        self._cursor = self._centre()
        self._filter = self._build_filter()

        self._pinch_started: float | None = None
        self._dragging = False
        self._paused = False
        self._last_right_click: float | None = None
        self._last_scroll: float | None = None
        self._last_centroid: tuple[float, float] | None = None
        self._last_centroid_time: float | None = None
        self._status = AirMouseStatus(cursor=self._cursor)

    # -- public API ---------------------------------------------------------
    @property
    def status(self) -> AirMouseStatus:
        return AirMouseStatus(
            active=self._status.active,
            paused=self._paused,
            dragging=self._dragging,
            cursor=self._cursor,
            last_action=self._status.last_action,
        )

    def handle_event(self, event: GestureEvent, now: float) -> bool:
        """Discrete gestures: right click fires once per activation."""
        if self._paused:
            return False
        role = self.roles.get(event.name)
        if role == "right_click":
            if self._last_right_click is not None and (now - self._last_right_click) < 0.4:
                return False
            self.executor.click("right")
            self._last_right_click = now
            self._status.last_action = "right click"
            return True
        return False

    def tick(self, state: RecognitionState, now: float) -> None:
        """Per-frame update driven by the engine's current state."""
        if not state.tracking or state.features is None:
            self._end_drag()
            self._pinch_started = None
            self._last_centroid = None
            self._status.active = False
            return

        gesture = state.stable
        self._status.active = True

        if gesture == self._inverse.get("pause"):
            self._paused = True
            self._end_drag()
            self._pinch_started = None
            return
        if self._paused:
            # The pause latches: dropping the fist and re-forming the pointer
            # pose must not silently re-arm the mouse. A deliberately
            # different pose (open palm, three fingers, ...) resumes control.
            if gesture in (None, self._inverse.get("pause"),
                           self._inverse.get("pointer")):
                return
            self._paused = False

        if gesture == self._inverse.get("pointer"):
            self._move_cursor(state, now)
        elif gesture == self._inverse.get("click"):
            self._handle_pinch(now)
        elif gesture == self._inverse.get("scroll"):
            self._handle_scroll(state, now)

        if gesture != self._inverse.get("click"):
            self._release_pinch(now)

    def reset(self) -> None:
        """Release any held button and forget transient state."""
        self._end_drag()
        self._pinch_started = None
        self._paused = False
        self._last_centroid = None
        self._last_centroid_time = None
        self._filter.reset()
        self._cursor = self._centre()
        self._status.active = False

    # -- screen bounds ------------------------------------------------------
    @property
    def screen_bounds(self) -> ScreenBounds:
        """The pixel space the cursor is mapped into."""
        return self._bounds

    @property
    def screen_size(self) -> tuple[int, int]:
        """``(width, height)`` of the mapped space, for display and tests."""
        return self._bounds.as_tuple()

    def set_screen_bounds(self, bounds: ScreenBounds) -> None:
        """Point the mapper at a new space (resolution or scaling change).

        The cursor is clamped into the new space and the filter restarted, so
        a stale coordinate cannot be emitted after a change.
        """
        new_bounds = _coerce_bounds(bounds)
        if new_bounds == self._bounds:
            return
        log.info("air mouse screen bounds %s -> %s",
                 self._bounds.describe(), new_bounds.describe())
        self._bounds = new_bounds
        self._cursor = new_bounds.clamp(*self._cursor)
        self._filter.reset()

    def apply_config(self, config: AirMouseConfig) -> None:
        """Adopt a new configuration and rebuild everything derived from it.

        Assigning ``controller.config`` alone was not enough: the pointer
        filter is constructed from the cutoff values, so a smoothing change
        silently kept the old filter until restart.
        """
        self.config = config
        self._filter = self._build_filter()
        self._cursor = self._bounds.clamp(*self._cursor)
        log.info("air mouse settings applied: gain %.2f, sensitivity %.2f, "
                 "margin %.2f, smoothing %s (cutoff %.2f), dead zone %d px",
                 config.gain, config.sensitivity, config.active_region,
                 config.smoothing, config.min_cutoff, config.dead_zone_px)

    def _build_filter(self) -> PointerFilter:
        return PointerFilter(
            self.config.smoothing, min_cutoff=self.config.min_cutoff,
            beta=self.config.beta, d_cutoff=self.config.d_cutoff)

    def _centre(self) -> tuple[float, float]:
        return (self._bounds.origin_x + (self._bounds.width - 1) / 2.0,
                self._bounds.origin_y + (self._bounds.height - 1) / 2.0)

    # -- pointer ------------------------------------------------------------
    def map_to_screen(self, x: float, y: float) -> tuple[float, float]:
        """Map a normalised fingertip position to a pixel in the cursor space.

        ``x`` and ``y`` are MediaPipe-normalised frame coordinates (0..1).

        1. ``active_region`` crops the frame edge: the hand only has to reach
           ``margin`` or ``1 - margin`` to reach the screen edge. The default
           0.18 is a convenience, never a restriction on the screen side.
        2. ``gain * sensitivity`` shapes the *response* with a signed power
           curve. It changes how far a mid-range hand movement travels; it
           cannot make an edge unreachable, because 0 and 1 map to 0 and 1 for
           every setting. (The old code multiplied the range about the centre,
           so any gain below 1.0 made the outer desktop unreachable.)
        3. The result is scaled to the last addressable pixel of the resolved
           bounds, so the corner is exactly ``(width - 1, height - 1)``.
        """
        bounds = self._bounds
        margin = min(0.45, max(0.0, float(self.config.active_region)))
        span = max(1e-6, 1.0 - 2 * margin)
        nx = _clamp01((float(x) - margin) / span)
        ny = _clamp01((float(y) - margin) / span)

        scale = self._response_scale()
        nx = _snap_unit(_response_curve(nx, scale))
        ny = _snap_unit(_response_curve(ny, scale))

        return (bounds.origin_x + nx * (bounds.width - 1),
                bounds.origin_y + ny * (bounds.height - 1))

    def _response_scale(self) -> float:
        """Combined gain and sensitivity, bounded to a usable curve."""
        return min(4.0, max(0.2, float(self.config.gain) * float(self.config.sensitivity)))

    def _move_cursor(self, state: RecognitionState, now: float) -> None:
        features = state.features
        if features is None:
            return
        bounds = self._bounds
        target = self.map_to_screen(*features.pointer)

        # Which axes are being asked for a boundary pixel, if any.
        edge_x = (target[0] if target[0] in (bounds.origin_x, bounds.max_x) else None)
        edge_y = (target[1] if target[1] in (bounds.origin_y, bounds.max_y) else None)

        filtered = self._filter(target, now)
        x = min(bounds.max_x, max(bounds.origin_x, filtered[0]))
        y = min(bounds.max_y, max(bounds.origin_y, filtered[1]))

        # Close the last couple of pixels: a filtered approach to a boundary is
        # asymptotic, and the dead zone would stop the cursor just short of the
        # corner. Snapping only inside EDGE_SNAP_PX keeps the approach smooth.
        if edge_x is not None and abs(x - edge_x) <= EDGE_SNAP_PX:
            x = edge_x
        if edge_y is not None and abs(y - edge_y) <= EDGE_SNAP_PX:
            y = edge_y

        # Bypass the dead zone only while a requested boundary is still
        # unreached; along an edge the dead zone keeps working as jitter
        # suppression, exactly as it does mid-screen.
        unreached = ((edge_x is not None and abs(self._cursor[0] - edge_x) > 0.5)
                     or (edge_y is not None and abs(self._cursor[1] - edge_y) > 0.5))
        if not unreached and math.hypot(x - self._cursor[0], y - self._cursor[1]) \
                < self.config.dead_zone_px:
            return

        pixel = bounds.clamp(x, y)
        if pixel == bounds.clamp(*self._cursor):
            return
        self._cursor = (x, y)
        self.executor.move_mouse_to(*pixel)
        self._status.last_action = "move"

    # -- click and drag ------------------------------------------------------
    def _handle_pinch(self, now: float) -> None:
        if self._pinch_started is None:
            self._pinch_started = now
            return
        held = now - self._pinch_started
        if not self._dragging and held >= self.config.drag_delay_s:
            self.executor.mouse_down("left")
            self._dragging = True
            self._status.last_action = "drag start"

    def _release_pinch(self, now: float) -> None:
        if self._pinch_started is None:
            return
        if self._dragging:
            self.executor.mouse_up("left")
            self._status.last_action = "drop"
        else:
            self.executor.click("left")
            self._status.last_action = "left click"
        self._pinch_started = None

    def _end_drag(self) -> None:
        if self._dragging:
            self.executor.mouse_up("left")
            self._status.last_action = "drop"
        self._dragging = False

    # -- scroll -------------------------------------------------------------
    def _handle_scroll(self, state: RecognitionState, now: float) -> None:
        features = state.features
        if features is None:
            return
        centroid = features.centroid
        if self._last_centroid is None or self._last_centroid_time is None:
            self._last_centroid = centroid
            self._last_centroid_time = now
            return
        dt = now - self._last_centroid_time
        if dt <= 1e-4:
            return
        velocity = (centroid[1] - self._last_centroid[1]) / dt  # +down
        self._last_centroid = centroid
        self._last_centroid_time = now
        if abs(velocity) < self.config.scroll_min_velocity:
            return
        if (self._last_scroll is not None and
                (now - self._last_scroll) * 1000.0 < self.config.scroll_interval_ms):
            return
        amount = int(max(-10, min(10, -velocity * self.config.scroll_gain)))
        if amount == 0:
            return
        self.executor.scroll(amount)
        self._last_scroll = now
        self._status.last_action = "scroll up" if amount > 0 else "scroll down"


# --------------------------------------------------------------------------- #
# Mapping helpers (pure, module-level so tests can exercise them directly)
# --------------------------------------------------------------------------- #
def _snap_unit(value: float) -> float:
    """Pin floating-point near-misses to exactly 0.0 or 1.0.

    ``(1.0 - 0.3 - 0.3) / 0.4`` is 0.9999999999999999, which would map the
    last pixel to 1534.999... and read as a shortfall in logs and tests. A
    hand at the margin boundary is asking for the edge, so give it the edge.
    """
    if value <= 1e-9:
        return 0.0
    if value >= 1.0 - 1e-9:
        return 1.0
    return value


def _clamp01(value: float) -> float:
    return 0.0 if value < 0.0 else (1.0 if value > 1.0 else float(value))


def _response_curve(t: float, scale: float) -> float:
    """Signed power curve that always maps 0 -> 0, 0.5 -> 0.5 and 1 -> 1.

    ``scale > 1`` makes the cursor travel further for a mid-range hand
    movement (faster); ``scale < 1`` makes it travel less (finer control).
    Because the endpoints are fixed points, no setting can make a screen edge
    unreachable -- which the previous centre-scaling implementation could, and
    did for every gain below 1.0.
    """
    if abs(scale - 1.0) < 1e-9:
        return t
    exponent = 1.0 / max(0.05, scale)
    signed = 2.0 * t - 1.0
    magnitude = abs(signed) ** exponent
    return _clamp01(0.5 + math.copysign(0.5 * magnitude, signed))


def _coerce_bounds(value: "ScreenBounds | tuple[int, int] | list[int]") -> ScreenBounds:
    """Accept a ScreenBounds or a legacy ``(width, height)`` tuple."""
    if isinstance(value, ScreenBounds):
        return value
    try:
        width, height = int(value[0]), int(value[1])
    except (TypeError, IndexError, ValueError) as exc:
        raise TypeError(f"cannot interpret {value!r} as screen bounds") from exc
    return ScreenBounds(width, height, source="tuple")
