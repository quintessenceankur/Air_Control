"""Controller base types.

A controller turns gesture state into executor calls. It is deliberately
small and injectable: an executor (real or recording), a screen size and a
clock are passed in, so every controller is testable without a desktop.
"""

from __future__ import annotations

from typing import Protocol

from aircontrol.core.gestures.events import GestureEvent, RecognitionState


class Controller(Protocol):
    """What the manager requires of a mode controller."""

    def handle_event(self, event: GestureEvent, now: float) -> bool:
        """Act on one gesture activation. Returns True if something was done."""

    def tick(self, state: RecognitionState, now: float) -> None:
        """Per-frame update for continuous behaviours (pointer, scroll)."""

    def reset(self) -> None:
        """Drop all state and release anything held (drag, pause)."""
