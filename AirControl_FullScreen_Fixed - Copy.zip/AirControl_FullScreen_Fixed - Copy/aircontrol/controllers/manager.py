"""Controller manager: mode selection, global enable, emergency stop.

The manager is the single place that decides whether an OS action may happen.
Every safety rule lives here, so there is one answer to "could AirControl do
something the user did not want?".
"""

from __future__ import annotations

import logging
from typing import Callable

from aircontrol.automation.base import ActionExecutor
from aircontrol.automation.screen import ScreenBounds, resolve_screen_bounds
from aircontrol.config import AirMouseConfig
from aircontrol.controllers.air_mouse import AirMouseController
from aircontrol.controllers.media import MediaController
from aircontrol.controllers.presentation import PresentationController
from aircontrol.core.actions import ControlMode
from aircontrol.core.gestures.events import GestureEvent, RecognitionState

log = logging.getLogger(__name__)

#: Called with (gesture, action_label, confidence) whenever an action fires.
ActionListener = Callable[[str, str, float], None]


class ControllerManager:
    """Routes gesture events and per-frame state to the active controller."""

    def __init__(self, executor: ActionExecutor, *,
                 mode: ControlMode = ControlMode.NONE,
                 enabled: bool = False,
                 air_mouse_config: AirMouseConfig | None = None,
                 screen_size: tuple[int, int] | ScreenBounds | None = None,
                 screen_bounds: ScreenBounds | None = None,
                 on_action: ActionListener | None = None) -> None:
        self.executor = executor
        self._mode = mode
        self._enabled = bool(enabled)
        self.on_action = on_action
        bounds = screen_bounds or (screen_size if screen_size is not None
                                   else resolve_screen_bounds())
        self.air_mouse = AirMouseController(
            executor, config=air_mouse_config, screen_bounds=bounds)
        self.media = MediaController(executor)
        self.presentation = PresentationController(executor)
        self.last_action = ""
        self.actions_fired = 0

    # -- state --------------------------------------------------------------
    @property
    def mode(self) -> ControlMode:
        return self._mode

    @property
    def enabled(self) -> bool:
        return self._enabled

    # -- screen and air-mouse settings --------------------------------------
    @property
    def screen_bounds(self) -> ScreenBounds:
        return self.air_mouse.screen_bounds

    def set_screen_bounds(self, bounds: ScreenBounds) -> None:
        """Re-target the air mouse, e.g. after a resolution or scaling change."""
        self.air_mouse.set_screen_bounds(bounds)

    def apply_air_mouse_config(self, config: AirMouseConfig) -> None:
        """Push new air-mouse settings into the running controller.

        The controller rebuilds its pointer filter from the new values, so a
        smoothing change takes effect immediately instead of at restart.
        """
        self.air_mouse.apply_config(config)

    def set_mode(self, mode: ControlMode) -> None:
        if mode is self._mode:
            return
        log.info("control mode -> %s", mode.value)
        self._reset_controllers()
        self._mode = mode

    def set_enabled(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if enabled == self._enabled:
            return
        log.info("gesture control %s", "enabled" if enabled else "disabled")
        self._enabled = enabled
        if not enabled:
            self._reset_controllers()

    def toggle(self) -> bool:
        self.set_enabled(not self._enabled)
        return self._enabled

    def emergency_stop(self) -> None:
        """Disable control, release anything held, and stay disabled."""
        log.warning("emergency stop engaged")
        self._enabled = False
        self._reset_controllers()
        self.last_action = "emergency stop"

    def _reset_controllers(self) -> None:
        for controller in (self.air_mouse, self.media, self.presentation):
            controller.reset()

    # -- routing ------------------------------------------------------------
    def handle(self, events: list[GestureEvent], state: RecognitionState,
               now: float) -> list[GestureEvent]:
        """Apply a frame's events and state. Returns the events acted upon."""
        if not self._enabled or self._mode is ControlMode.NONE:
            return []

        acted: list[GestureEvent] = []
        if self._mode is ControlMode.AIR_MOUSE:
            self.air_mouse.tick(state, now)
            for event in events:
                if self.air_mouse.handle_event(event, now):
                    acted.append(event)
                    self._record(event, "air mouse")
        elif self._mode is ControlMode.MEDIA:
            for event in events:
                if self.media.handle_event(event, now):
                    acted.append(event)
                    self._record(event, self.media.last_action)
        elif self._mode is ControlMode.PRESENTATION:
            for event in events:
                if self.presentation.handle_event(event, now):
                    acted.append(event)
                    self._record(event, self.presentation.last_action)
        return acted

    def _record(self, event: GestureEvent, label: str) -> None:
        self.actions_fired += 1
        self.last_action = f"{event.name} -> {label}"
        if self.on_action is not None:
            try:
                self.on_action(event.name, label, event.confidence)
            except Exception:  # pragma: no cover - listener must not break control
                log.exception("action listener failed")

    def status_text(self) -> str:
        if not self._enabled:
            return "Gesture control off"
        if self._mode is ControlMode.NONE:
            return "Gesture control on - no controller selected"
        return f"{self._mode.label} active"
