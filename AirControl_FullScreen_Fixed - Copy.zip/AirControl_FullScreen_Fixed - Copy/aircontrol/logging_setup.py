"""Logging setup: rotating file handler plus console, configured once."""

from __future__ import annotations

import logging
import logging.handlers
import sys
from pathlib import Path

from aircontrol.config import user_data_dir

_FORMAT = "%(asctime)s %(levelname)-8s %(name)-28s %(message)s"
_configured = False


def configure_logging(level: str = "INFO", log_dir: Path | None = None,
                      console: bool = True) -> Path:
    """Configure root logging and return the log file path.

    Idempotent: calling twice does not duplicate handlers, which matters
    because the UI and the CLI both call it.
    """
    global _configured
    directory = log_dir or (user_data_dir() / "logs")
    directory.mkdir(parents=True, exist_ok=True)
    log_path = directory / "aircontrol.log"

    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))
    if _configured:
        return log_path

    file_handler = logging.handlers.RotatingFileHandler(
        log_path, maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    file_handler.setFormatter(logging.Formatter(_FORMAT))
    root.addHandler(file_handler)

    if console and sys.stderr is not None:
        stream = logging.StreamHandler()
        stream.setFormatter(logging.Formatter(_FORMAT))
        root.addHandler(stream)

    logging.getLogger("aircontrol").info("logging configured at %s (%s)",
                                         log_path, level.upper())
    _configured = True
    return log_path
