"""SQLite connection factory, schema and migrations.

All SQL lives in the ``data`` package: ``db`` owns the schema, ``repository``
owns the queries, ``analytics`` owns the aggregates. Nothing else in the
project writes SQL.

Privacy: the database stores settings, bindings, calibration values, session
counters and gesture names. It never stores webcam frames, images, or raw
landmark streams -- those exist only in memory, or in a fixture file the user
explicitly records.
"""

from __future__ import annotations

import logging
import sqlite3
from pathlib import Path

log = logging.getLogger(__name__)

SCHEMA_VERSION = 1

_MIGRATION_1 = """
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL,
    updated_at  REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS calibration_profiles (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    is_active   INTEGER NOT NULL DEFAULT 0,
    payload     TEXT NOT NULL,
    created_at  REAL NOT NULL,
    updated_at  REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS bindings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    mode        TEXT NOT NULL,
    gesture     TEXT NOT NULL,
    kind        TEXT NOT NULL,
    target      TEXT NOT NULL,
    UNIQUE (mode, gesture)
);

CREATE TABLE IF NOT EXISTS sessions (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at     REAL NOT NULL,
    ended_at       REAL,
    gestures_fired INTEGER NOT NULL DEFAULT 0,
    actions_fired  INTEGER NOT NULL DEFAULT 0,
    notes          TEXT
);

CREATE TABLE IF NOT EXISTS gesture_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    gesture     TEXT NOT NULL,
    confidence  REAL NOT NULL DEFAULT 0,
    executed    INTEGER NOT NULL DEFAULT 0,
    mode        TEXT,
    occurred_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS practice_attempts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    target_gesture  TEXT NOT NULL,
    recognized      TEXT,
    correct         INTEGER NOT NULL,
    confidence      REAL NOT NULL DEFAULT 0,
    created_at      REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_events_gesture ON gesture_events (gesture);
CREATE INDEX IF NOT EXISTS idx_events_time ON gesture_events (occurred_at);
CREATE INDEX IF NOT EXISTS idx_practice_target ON practice_attempts (target_gesture);
"""

#: ``(version, sql)`` pairs applied in order.
MIGRATIONS: list[tuple[int, str]] = [(1, _MIGRATION_1)]


class DatabaseError(RuntimeError):
    """The database could not be opened, migrated or written."""


def connect(path: Path | str) -> sqlite3.Connection:
    """Open a connection with the pragmas this application relies on."""
    target = Path(path)
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(target), timeout=5.0)
    except (OSError, sqlite3.Error) as exc:
        raise DatabaseError(f"cannot open database at {target}: {exc}") from exc
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")
    return conn


def schema_version(conn: sqlite3.Connection) -> int:
    """Return the applied schema version (0 for a fresh database)."""
    try:
        row = conn.execute("SELECT version FROM schema_version LIMIT 1").fetchone()
    except sqlite3.OperationalError:
        return 0
    return int(row["version"]) if row else 0


def initialize(conn: sqlite3.Connection) -> int:
    """Apply pending migrations and return the resulting version.

    Migrations are additive and idempotent, so a partially created database
    (for example after a crash during first run) is repaired rather than
    rejected.
    """
    current = schema_version(conn)
    for version, sql in MIGRATIONS:
        if version <= current:
            continue
        try:
            conn.executescript(sql)
            conn.execute("DELETE FROM schema_version")
            conn.execute("INSERT INTO schema_version (version) VALUES (?)", (version,))
            conn.commit()
        except sqlite3.Error as exc:
            conn.rollback()
            raise DatabaseError(f"migration {version} failed: {exc}") from exc
        log.info("applied database migration %s", version)
        current = version
    return current


def open_database(path: Path | str) -> sqlite3.Connection:
    """Open and migrate in one step -- the normal entry point."""
    conn = connect(path)
    initialize(conn)
    return conn


def backup(conn: sqlite3.Connection, destination: Path | str) -> Path:
    """Write a consistent copy of the database (SQLite backup API)."""
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        with sqlite3.connect(str(target)) as copy:
            conn.backup(copy)
    except sqlite3.Error as exc:
        raise DatabaseError(f"backup failed: {exc}") from exc
    return target
