"""Row dataclasses for the persistence layer."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CalibrationProfile:
    """Per-user tuning values, stored as a JSON payload."""

    name: str
    is_active: bool = False
    #: Multiplier on the recognition enter/exit thresholds (1.0 = spec value).
    gesture_sensitivity: float = 1.0
    #: Multiplier on the pinch enter/exit ratios (1.0 = spec value).
    pinch_sensitivity: float = 1.0
    #: Multiplier on air-mouse cursor gain.
    cursor_speed: float = 1.0
    #: Fraction of the frame ignored at each edge for cursor mapping.
    active_region: float = 0.18
    #: One Euro / EMA smoothing strength, 0 (none) .. 1 (heavy).
    smoothing: float = 0.5

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "is_active": self.is_active,
            "gesture_sensitivity": self.gesture_sensitivity,
            "pinch_sensitivity": self.pinch_sensitivity,
            "cursor_speed": self.cursor_speed,
            "active_region": self.active_region,
            "smoothing": self.smoothing,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "CalibrationProfile":
        return cls(
            name=str(data.get("name", "default")),
            is_active=bool(data.get("is_active", False)),
            gesture_sensitivity=float(data.get("gesture_sensitivity", 1.0)),
            pinch_sensitivity=float(data.get("pinch_sensitivity", 1.0)),
            cursor_speed=float(data.get("cursor_speed", 1.0)),
            active_region=float(data.get("active_region", 0.18)),
            smoothing=float(data.get("smoothing", 0.5)),
        )


@dataclass(frozen=True)
class BindingRow:
    mode: str
    gesture: str
    kind: str
    target: str


@dataclass(frozen=True)
class SessionRow:
    id: int
    started_at: float
    ended_at: float | None
    gestures_fired: int
    actions_fired: int
    notes: str = ""

    @property
    def duration_s(self) -> float:
        if self.ended_at is None:
            return 0.0
        return max(0.0, self.ended_at - self.started_at)


@dataclass(frozen=True)
class GestureEventRow:
    gesture: str
    confidence: float
    executed: bool
    mode: str
    occurred_at: float
    session_id: int | None = None


@dataclass(frozen=True)
class PracticeAttempt:
    target_gesture: str
    recognized: str | None
    correct: bool
    confidence: float
    created_at: float
