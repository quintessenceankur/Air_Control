"""Typed CRUD over the AirControl schema.

The repository is the only object the rest of the application uses to touch
the database. It validates on the way in (so a corrupt or hand-edited row
cannot reach a controller) and it never raises ``sqlite3`` errors: callers get
:class:`RepositoryError` with a message they can log or show.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from typing import Any, Mapping

from aircontrol.core.actions import (
    Action,
    ControlMode,
    validate_air_mouse_roles,
    validate_bindings,
)
from aircontrol.core.gestures.spec import GESTURE_SPECS
from aircontrol.data.db import DatabaseError, open_database
from aircontrol.data.models import (
    BindingRow,
    CalibrationProfile,
    GestureEventRow,
    PracticeAttempt,
    SessionRow,
)

log = logging.getLogger(__name__)


class RepositoryError(RuntimeError):
    """A validated read or write failed."""


class Repository:
    """All persistence for one database connection."""

    def __init__(self, connection: sqlite3.Connection) -> None:
        self.conn = connection

    @classmethod
    def open(cls, path: str) -> "Repository":
        try:
            return cls(open_database(path))
        except DatabaseError as exc:
            raise RepositoryError(str(exc)) from exc

    def close(self) -> None:
        try:
            self.conn.close()
        except sqlite3.Error:  # pragma: no cover - already closed
            pass

    # -- settings -----------------------------------------------------------
    def set_setting(self, key: str, value: Any) -> None:
        if not key:
            raise RepositoryError("setting key must not be empty")
        payload = json.dumps(value)
        try:
            self.conn.execute(
                "INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value, "
                "updated_at = excluded.updated_at",
                (key, payload, time.time()))
            self.conn.commit()
        except sqlite3.Error as exc:
            raise RepositoryError(f"cannot store setting {key!r}: {exc}") from exc

    def get_setting(self, key: str, default: Any = None) -> Any:
        try:
            row = self.conn.execute(
                "SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        except sqlite3.Error as exc:
            raise RepositoryError(f"cannot read setting {key!r}: {exc}") from exc
        if row is None:
            return default
        try:
            return json.loads(row["value"])
        except json.JSONDecodeError:
            log.warning("setting %s is not valid JSON; using default", key)
            return default

    def all_settings(self) -> dict[str, Any]:
        rows = self.conn.execute("SELECT key, value FROM settings").fetchall()
        result: dict[str, Any] = {}
        for row in rows:
            try:
                result[row["key"]] = json.loads(row["value"])
            except json.JSONDecodeError:
                continue
        return result

    # -- calibration profiles ----------------------------------------------
    def save_profile(self, profile: CalibrationProfile) -> int:
        self._validate_profile(profile)
        now = time.time()
        payload = json.dumps(profile.to_dict())
        try:
            with self.conn:
                if profile.is_active:
                    self.conn.execute("UPDATE calibration_profiles SET is_active = 0")
                self.conn.execute(
                    "INSERT INTO calibration_profiles (name, is_active, payload, "
                    "created_at, updated_at) VALUES (?, ?, ?, ?, ?) "
                    "ON CONFLICT(name) DO UPDATE SET is_active = excluded.is_active, "
                    "payload = excluded.payload, updated_at = excluded.updated_at",
                    (profile.name, int(profile.is_active), payload, now, now))
            row = self.conn.execute(
                "SELECT id FROM calibration_profiles WHERE name = ?",
                (profile.name,)).fetchone()
            return int(row["id"]) if row else 0
        except sqlite3.Error as exc:
            raise RepositoryError(f"cannot save profile {profile.name!r}: {exc}") from exc

    def active_profile(self) -> CalibrationProfile | None:
        row = self.conn.execute(
            "SELECT payload FROM calibration_profiles WHERE is_active = 1 LIMIT 1").fetchone()
        if row is None:
            return None
        return self._profile_from_payload(row["payload"])

    def profiles(self) -> list[CalibrationProfile]:
        rows = self.conn.execute(
            "SELECT payload FROM calibration_profiles ORDER BY name").fetchall()
        return [self._profile_from_payload(r["payload"]) for r in rows]

    def activate_profile(self, name: str) -> bool:
        with self.conn:
            updated = self.conn.execute(
                "UPDATE calibration_profiles SET is_active = (name = ?)", (name,))
        return updated.rowcount > 0

    def delete_profile(self, name: str) -> bool:
        with self.conn:
            deleted = self.conn.execute(
                "DELETE FROM calibration_profiles WHERE name = ?", (name,))
        return deleted.rowcount > 0

    # -- bindings -----------------------------------------------------------
    def save_bindings(self, mode: ControlMode, bindings: Mapping[str, Action]) -> None:
        try:
            validate_bindings(mode, bindings)
        except ValueError as exc:
            raise RepositoryError(f"invalid {mode.value} bindings: {exc}") from exc
        try:
            with self.conn:
                self.conn.execute("DELETE FROM bindings WHERE mode = ?", (mode.value,))
                self.conn.executemany(
                    "INSERT INTO bindings (mode, gesture, kind, target) "
                    "VALUES (?, ?, ?, ?)",
                    [(mode.value, gesture, action.kind, action.target)
                     for gesture, action in bindings.items()])
        except (sqlite3.Error, ValueError) as exc:
            raise RepositoryError(f"cannot save {mode.value} bindings: {exc}") from exc

    def load_bindings(self, mode: ControlMode) -> dict[str, Action]:
        """Load saved bindings, falling back to the spec table on bad rows."""
        from aircontrol.core.actions import bindings_for
        defaults = bindings_for(mode)
        rows = self.conn.execute(
            "SELECT gesture, kind, target FROM bindings WHERE mode = ?",
            (mode.value,)).fetchall()
        if not rows:
            return defaults
        loaded: dict[str, Action] = {}
        for row in rows:
            gesture = row["gesture"]
            if gesture not in GESTURE_SPECS:
                log.warning("ignoring binding for unknown gesture %s", gesture)
                continue
            description = defaults.get(gesture, Action("none")).description
            loaded[gesture] = Action(row["kind"], row["target"], description)
        try:
            validate_bindings(mode, loaded)
        except ValueError as exc:
            log.warning("stored %s bindings invalid (%s); using defaults",
                        mode.value, exc)
            return defaults
        return loaded

    def save_air_mouse_roles(self, roles: Mapping[str, str]) -> None:
        try:
            validate_air_mouse_roles(roles)
        except ValueError as exc:
            raise RepositoryError(f"invalid air mouse roles: {exc}") from exc
        self.set_setting("air_mouse.roles", dict(roles))

    def load_air_mouse_roles(self) -> dict[str, str]:
        from aircontrol.core.actions import DEFAULT_AIR_MOUSE_ROLES
        stored = self.get_setting("air_mouse.roles")
        if not isinstance(stored, dict) or not stored:
            return dict(DEFAULT_AIR_MOUSE_ROLES)
        try:
            validate_air_mouse_roles(stored)
        except ValueError:
            return dict(DEFAULT_AIR_MOUSE_ROLES)
        return {str(k): str(v) for k, v in stored.items()}

    # -- sessions -----------------------------------------------------------
    def start_session(self, started_at: float | None = None) -> int:
        with self.conn:
            cursor = self.conn.execute(
                "INSERT INTO sessions (started_at) VALUES (?)",
                (started_at if started_at is not None else time.time(),))
        return int(cursor.lastrowid or 0)

    def end_session(self, session_id: int, *, ended_at: float | None = None,
                    gestures_fired: int = 0, actions_fired: int = 0) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE sessions SET ended_at = ?, gestures_fired = ?, "
                "actions_fired = ? WHERE id = ?",
                (ended_at if ended_at is not None else time.time(),
                 int(gestures_fired), int(actions_fired), int(session_id)))

    def sessions(self, limit: int = 20) -> list[SessionRow]:
        rows = self.conn.execute(
            "SELECT id, started_at, ended_at, gestures_fired, actions_fired, "
            "COALESCE(notes, '') AS notes FROM sessions "
            "ORDER BY started_at DESC LIMIT ?", (int(limit),)).fetchall()
        return [SessionRow(id=r["id"], started_at=r["started_at"],
                           ended_at=r["ended_at"],
                           gestures_fired=r["gestures_fired"],
                           actions_fired=r["actions_fired"],
                           notes=r["notes"]) for r in rows]

    # -- gesture events -----------------------------------------------------
    def log_event(self, event: GestureEventRow) -> None:
        if event.gesture not in GESTURE_SPECS:
            raise RepositoryError(f"unknown gesture {event.gesture!r}")
        try:
            with self.conn:
                self.conn.execute(
                    "INSERT INTO gesture_events (session_id, gesture, confidence, "
                    "executed, mode, occurred_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (event.session_id, event.gesture, float(event.confidence),
                     int(bool(event.executed)), event.mode, float(event.occurred_at)))
        except sqlite3.Error as exc:
            raise RepositoryError(f"cannot log gesture event: {exc}") from exc

    def recent_events(self, limit: int = 20) -> list[GestureEventRow]:
        rows = self.conn.execute(
            "SELECT gesture, confidence, executed, mode, occurred_at, session_id "
            "FROM gesture_events ORDER BY occurred_at DESC LIMIT ?",
            (int(limit),)).fetchall()
        return [GestureEventRow(gesture=r["gesture"], confidence=r["confidence"],
                                executed=bool(r["executed"]), mode=r["mode"] or "",
                                occurred_at=r["occurred_at"],
                                session_id=r["session_id"]) for r in rows]

    # -- practice -----------------------------------------------------------
    def log_practice(self, attempt: PracticeAttempt) -> None:
        if attempt.target_gesture not in GESTURE_SPECS:
            raise RepositoryError(f"unknown gesture {attempt.target_gesture!r}")
        with self.conn:
            self.conn.execute(
                "INSERT INTO practice_attempts (target_gesture, recognized, correct, "
                "confidence, created_at) VALUES (?, ?, ?, ?, ?)",
                (attempt.target_gesture, attempt.recognized, int(attempt.correct),
                 float(attempt.confidence), float(attempt.created_at)))

    def practice_history(self, limit: int = 50) -> list[PracticeAttempt]:
        rows = self.conn.execute(
            "SELECT target_gesture, recognized, correct, confidence, created_at "
            "FROM practice_attempts ORDER BY created_at DESC LIMIT ?",
            (int(limit),)).fetchall()
        return [PracticeAttempt(target_gesture=r["target_gesture"],
                                recognized=r["recognized"], correct=bool(r["correct"]),
                                confidence=r["confidence"],
                                created_at=r["created_at"]) for r in rows]

    def clear_practice_history(self) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM practice_attempts")

    # -- maintenance --------------------------------------------------------
    def binding_rows(self) -> list[BindingRow]:
        rows = self.conn.execute(
            "SELECT mode, gesture, kind, target FROM bindings ORDER BY mode, gesture"
        ).fetchall()
        return [BindingRow(mode=r["mode"], gesture=r["gesture"], kind=r["kind"],
                           target=r["target"]) for r in rows]

    def reset_all(self) -> None:
        """Delete user data but keep the schema (Settings > Restore defaults)."""
        with self.conn:
            for table in ("gesture_events", "sessions", "practice_attempts",
                          "bindings", "calibration_profiles", "settings"):
                self.conn.execute(f"DELETE FROM {table}")  # noqa: S608 - fixed names

    # -- internals ----------------------------------------------------------
    @staticmethod
    def _profile_from_payload(payload: str) -> CalibrationProfile:
        try:
            return CalibrationProfile.from_dict(json.loads(payload))
        except (json.JSONDecodeError, TypeError, ValueError):
            return CalibrationProfile(name="default")

    @staticmethod
    def _validate_profile(profile: CalibrationProfile) -> None:
        if not profile.name.strip():
            raise RepositoryError("profile name must not be empty")
        for field_name in ("gesture_sensitivity", "pinch_sensitivity", "cursor_speed"):
            value = getattr(profile, field_name)
            if not 0.2 <= value <= 3.0:
                raise RepositoryError(f"{field_name} must be between 0.2 and 3.0")
        if not 0.0 <= profile.active_region < 0.45:
            raise RepositoryError("active_region must be in [0, 0.45)")
        if not 0.0 <= profile.smoothing <= 1.0:
            raise RepositoryError("smoothing must be in [0, 1]")
