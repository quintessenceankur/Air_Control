"""Aggregate queries for the Analytics page and the dashboard.

Read-only. Every number here is computed from rows the application actually
wrote; nothing is estimated or extrapolated.
"""

from __future__ import annotations

import sqlite3
import time
from dataclasses import dataclass, field

from aircontrol.core.gestures.spec import VOCABULARY


@dataclass
class AnalyticsSnapshot:
    """Everything the analytics UI needs, in one consistent read."""

    total_sessions: int = 0
    total_gestures: int = 0
    total_actions: int = 0
    total_practice: int = 0
    practice_correct: int = 0
    practice_accuracy: float = 0.0
    mean_confidence: float = 0.0
    average_session_s: float = 0.0
    gesture_counts: list[tuple[str, int]] = field(default_factory=list)
    top_gestures: list[tuple[str, int]] = field(default_factory=list)
    daily: list[tuple[str, int]] = field(default_factory=list)
    per_gesture_practice: list[tuple[str, int, int, float]] = field(default_factory=list)
    hours_active: float = 0.0


class Analytics:
    """Aggregates over sessions, gesture events and practice attempts."""

    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    # -- individual aggregates ---------------------------------------------
    def totals(self) -> dict[str, float]:
        # Gesture and action counts come from the event table, which is the
        # authoritative record; the session row only summarises it.
        session_row = self.conn.execute(
            "SELECT COUNT(*) AS sessions, "
            "COALESCE(SUM(CASE WHEN ended_at IS NOT NULL "
            "THEN MAX(0, ended_at - started_at) ELSE 0 END), 0) AS seconds "
            "FROM sessions").fetchone()
        event_row = self.conn.execute(
            "SELECT COUNT(*) AS gestures, "
            "COALESCE(SUM(CASE WHEN executed THEN 1 ELSE 0 END), 0) AS actions "
            "FROM gesture_events").fetchone()
        return {"sessions": float(session_row["sessions"]),
                "gestures": float(event_row["gestures"]),
                "actions": float(event_row["actions"]),
                "seconds": float(session_row["seconds"])}

    def gesture_counts(self) -> list[tuple[str, int]]:
        rows = self.conn.execute(
            "SELECT gesture, COUNT(*) AS n FROM gesture_events "
            "GROUP BY gesture ORDER BY n DESC").fetchall()
        return [(row["gesture"], int(row["n"])) for row in rows]

    def top_gestures(self, limit: int = 5) -> list[tuple[str, int]]:
        return self.gesture_counts()[:max(1, limit)]

    def mean_confidence(self) -> float:
        row = self.conn.execute(
            "SELECT AVG(confidence) AS c FROM gesture_events").fetchone()
        return float(row["c"] or 0.0)

    def daily_counts(self, days: int = 14) -> list[tuple[str, int]]:
        """Events per calendar day, oldest first, including empty days."""
        now = time.time()
        start = now - days * 86400
        rows = self.conn.execute(
            "SELECT date(occurred_at, 'unixepoch', 'localtime') AS day, "
            "COUNT(*) AS n FROM gesture_events WHERE occurred_at >= ? "
            "GROUP BY day ORDER BY day", (start,)).fetchall()
        counts = {row["day"]: int(row["n"]) for row in rows}
        days_list: list[tuple[str, int]] = []
        for offset in range(days - 1, -1, -1):
            stamp = time.strftime("%Y-%m-%d", time.localtime(now - offset * 86400))
            days_list.append((stamp, counts.get(stamp, 0)))
        return days_list

    def practice_summary(self) -> tuple[int, int]:
        row = self.conn.execute(
            "SELECT COUNT(*) AS total, COALESCE(SUM(correct), 0) AS correct "
            "FROM practice_attempts").fetchone()
        return int(row["total"]), int(row["correct"])

    def practice_by_gesture(self) -> list[tuple[str, int, int, float]]:
        rows = self.conn.execute(
            "SELECT target_gesture AS g, COUNT(*) AS n, "
            "COALESCE(SUM(correct), 0) AS c FROM practice_attempts "
            "GROUP BY g ORDER BY g").fetchall()
        result = []
        for row in rows:
            total = int(row["n"])
            correct = int(row["c"])
            result.append((row["g"], total, correct, correct / total if total else 0.0))
        return result

    def untried_gestures(self) -> list[str]:
        tried = {row[0] for row in self.practice_by_gesture()}
        return [g for g in VOCABULARY if g not in tried]

    # -- composite ----------------------------------------------------------
    def snapshot(self, days: int = 14) -> AnalyticsSnapshot:
        totals = self.totals()
        total_practice, correct = self.practice_summary()
        sessions = int(totals["sessions"])
        return AnalyticsSnapshot(
            total_sessions=sessions,
            total_gestures=int(totals["gestures"]),
            total_actions=int(totals["actions"]),
            total_practice=total_practice,
            practice_correct=correct,
            practice_accuracy=(correct / total_practice) if total_practice else 0.0,
            mean_confidence=self.mean_confidence(),
            average_session_s=(totals["seconds"] / sessions) if sessions else 0.0,
            gesture_counts=self.gesture_counts(),
            top_gestures=self.top_gestures(),
            daily=self.daily_counts(days),
            per_gesture_practice=self.practice_by_gesture(),
            hours_active=totals["seconds"] / 3600.0,
        )
