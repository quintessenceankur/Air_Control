"""Pure gesture core: landmarks in, gesture state out. No camera, no Qt, no OS."""
