"""Landmark geometry primitives.

This module is *pure*: it imports numpy only. No camera, no Qt, no OS calls,
no file I/O. Everything here is replayable from a recorded landmark fixture.

Coordinate convention
---------------------
Raw landmarks arrive from MediaPipe as normalised image coordinates:
``x`` grows to the right, ``y`` grows downward, ``z`` is roughly the depth
relative to the wrist in the same scale as ``x``.

Frames handed to the detector are mirrored (selfie view) by
:mod:`aircontrol.vision.capture`, so raw ``x`` grows in the direction the
user moves their hand on screen -- cursor mapping can use it directly.

Canonical coordinates
---------------------
:func:`to_canonical` produces a scale- and translation-invariant 21x3 array:
origin at the wrist, divided by palm width, and mirrored for left hands so
that the thumb always sits on the same side. Every feature in
:mod:`aircontrol.core.features` is computed from that array, which is what
makes recognition independent of how far the user sits from the camera.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, replace
from typing import Iterable, Sequence

import numpy as np

NUM_LANDMARKS = 21

# --- landmark indices (MediaPipe hand topology) -------------------------------
WRIST = 0
THUMB_CMC, THUMB_MCP, THUMB_IP, THUMB_TIP = 1, 2, 3, 4
INDEX_MCP, INDEX_PIP, INDEX_DIP, INDEX_TIP = 5, 6, 7, 8
MIDDLE_MCP, MIDDLE_PIP, MIDDLE_DIP, MIDDLE_TIP = 9, 10, 11, 12
RING_MCP, RING_PIP, RING_DIP, RING_TIP = 13, 14, 15, 16
PINKY_MCP, PINKY_PIP, PINKY_DIP, PINKY_TIP = 17, 18, 19, 20

#: Bones used by the preview overlay.
HAND_CONNECTIONS: tuple[tuple[int, int], ...] = (
    (0, 1), (1, 2), (2, 3), (3, 4),
    (0, 5), (5, 6), (6, 7), (7, 8),
    (5, 9), (9, 10), (10, 11), (11, 12),
    (9, 13), (13, 14), (14, 15), (15, 16),
    (13, 17), (17, 18), (18, 19), (19, 20),
    (0, 17),
)

#: Palm width below this (in normalised image units) is treated as noise.
MIN_PALM_WIDTH = 1e-3


@dataclass(frozen=True)
class Point:
    """A single landmark in normalised image coordinates."""

    x: float
    y: float
    z: float = 0.0

    def as_tuple(self) -> tuple[float, float, float]:
        return (self.x, self.y, self.z)


@dataclass(frozen=True)
class HandFrame:
    """One detected hand for one frame.

    ``presence`` is MediaPipe's presence/score for the hand and is used as a
    gate: frames below the floor never reach a classifier.
    """

    landmarks: tuple[Point, ...]
    handedness: str = "Right"
    presence: float = 1.0
    timestamp: float = 0.0

    @property
    def is_complete(self) -> bool:
        return len(self.landmarks) == NUM_LANDMARKS

    def points(self) -> np.ndarray:
        """Return an ``(21, 3)`` float array of raw coordinates."""
        return np.array([p.as_tuple() for p in self.landmarks], dtype=float)

    def point(self, index: int) -> Point:
        return self.landmarks[index]


def hand_from_array(
    landmarks: Sequence[Sequence[float]],
    handedness: str = "Right",
    presence: float = 1.0,
    timestamp: float = 0.0,
) -> HandFrame:
    """Build a :class:`HandFrame` from a raw ``[[x, y, z], ...]`` sequence.

    Used by the fixture replayer and by tests; also the boundary the detector
    uses to hand data to the pure core.
    """
    pts = tuple(Point(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0)
                for p in landmarks)
    return HandFrame(landmarks=pts, handedness=handedness,
                     presence=float(presence), timestamp=float(timestamp))


def distance(a: Point | np.ndarray, b: Point | np.ndarray) -> float:
    """Euclidean distance between two points or 3-vectors."""
    ax, ay, az = _xyz(a)
    bx, by, bz = _xyz(b)
    return math.sqrt((ax - bx) ** 2 + (ay - by) ** 2 + (az - bz) ** 2)


def angle_deg(a: Point | np.ndarray, b: Point | np.ndarray,
              c: Point | np.ndarray) -> float:
    """Angle ``ABC`` in degrees, with ``b`` as the vertex.

    Returns ``0.0`` for a degenerate (zero-length) arm rather than raising:
    a collapsed landmark triple is noise, not a crash.
    """
    ax, ay, az = _xyz(a)
    bx, by, bz = _xyz(b)
    cx, cy, cz = _xyz(c)
    bax, bay, baz = ax - bx, ay - by, az - bz
    bcx, bcy, bcz = cx - bx, cy - by, cz - bz
    denom = math.sqrt(bax * bax + bay * bay + baz * baz) * math.sqrt(
        bcx * bcx + bcy * bcy + bcz * bcz)
    if denom < 1e-9:
        return 0.0
    cosine = (bax * bcx + bay * bcy + baz * bcz) / denom
    return math.degrees(math.acos(max(-1.0, min(1.0, cosine))))


def _xyz(p: Point | np.ndarray | Sequence[float]) -> tuple[float, float, float]:
    if isinstance(p, Point):
        return p.x, p.y, p.z
    seq = np.asarray(p, dtype=float).reshape(-1)
    if seq.size == 2:
        return float(seq[0]), float(seq[1]), 0.0
    return float(seq[0]), float(seq[1]), float(seq[2])


def palm_width(hand: HandFrame | np.ndarray) -> float:
    """Distance between the index and pinky MCP joints -- the scale unit."""
    pts = hand.points() if isinstance(hand, HandFrame) else np.asarray(hand, float)
    if len(pts) < NUM_LANDMARKS:
        return 0.0
    return float(np.linalg.norm(pts[INDEX_MCP] - pts[PINKY_MCP]))


def palm_length(hand: HandFrame | np.ndarray) -> float:
    pts = hand.points() if isinstance(hand, HandFrame) else np.asarray(hand, float)
    if len(pts) < NUM_LANDMARKS:
        return 0.0
    return float(np.linalg.norm(pts[MIDDLE_MCP] - pts[WRIST]))


def is_plausible(hand: HandFrame, min_palm_width: float = MIN_PALM_WIDTH) -> bool:
    """Reject degenerate detections before they reach the classifiers.

    A face or a poster can occasionally produce 21 points with a near-zero
    palm width; those must not be classified.
    """
    if not hand.is_complete:
        return False
    if not math.isfinite(hand.presence) or hand.presence <= 0.0:
        return False
    pts = hand.points()
    if not np.all(np.isfinite(pts)):
        return False
    return palm_width(hand) >= min_palm_width


def to_canonical(hand: HandFrame) -> np.ndarray:
    """Return a ``(21, 3)`` canonical array: wrist origin, palm-width units.

    Left hands are mirrored about the wrist so a left hand and a right hand
    in the same pose produce (nearly) the same array. This is what lets one
    classifier serve both hands without duplicating every rule.
    """
    pts = hand.points()
    if len(pts) != NUM_LANDMARKS:
        raise ValueError(f"expected {NUM_LANDMARKS} landmarks, got {len(pts)}")
    pts = pts - pts[WRIST]
    scale = palm_width(hand)
    if scale < MIN_PALM_WIDTH:
        raise ValueError("degenerate hand: palm width below minimum")
    pts = pts / scale
    if hand.handedness.lower().startswith("l"):
        pts[:, 0] = -pts[:, 0]
    return pts


def mirror(hand: HandFrame) -> HandFrame:
    """Mirror a hand horizontally (image space), keeping handedness inverted."""
    mirrored = tuple(Point(1.0 - p.x, p.y, p.z) for p in hand.landmarks)
    other = "Left" if hand.handedness.lower().startswith("r") else "Right"
    return replace(hand, landmarks=mirrored, handedness=other)


def smooth_landmarks(
    previous: Sequence[Point] | None,
    current: Sequence[Point],
    alpha: float,
) -> tuple[Point, ...]:
    """Exponential moving average over landmark positions.

    ``alpha`` is the weight of the *new* frame. ``alpha = 1.0`` disables
    smoothing. Jitter in the raw stream is the main cause of cursor wobble
    and of gestures flickering in and out of the enter band, so smoothing
    happens before features are extracted, not after.
    """
    if alpha >= 1.0 or previous is None or len(previous) != len(current):
        return tuple(current)
    alpha = max(0.0, alpha)
    return tuple(
        Point(alpha * c.x + (1 - alpha) * p.x,
              alpha * c.y + (1 - alpha) * p.y,
              alpha * c.z + (1 - alpha) * p.z)
        for p, c in zip(previous, current)
    )


def bounding_box(hand: HandFrame) -> tuple[float, float, float, float]:
    """``(min_x, min_y, max_x, max_y)`` in normalised image coordinates."""
    pts = hand.points()
    return (float(pts[:, 0].min()), float(pts[:, 1].min()),
            float(pts[:, 0].max()), float(pts[:, 1].max()))


def centroid(hand: HandFrame) -> Point:
    """Mean of the 21 landmarks, in raw image coordinates."""
    pts = hand.points()
    mean = pts.mean(axis=0)
    return Point(float(mean[0]), float(mean[1]), float(mean[2]))


def iter_points(hand: HandFrame) -> Iterable[Point]:
    return iter(hand.landmarks)
