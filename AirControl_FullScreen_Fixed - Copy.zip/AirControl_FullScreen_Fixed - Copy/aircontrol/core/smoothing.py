"""Cursor smoothing filters.

Pure maths, no Qt or OS. Two filters are offered because they fail
differently: an exponential moving average is simple but always lags, while a
One Euro filter adapts its cutoff to speed, so it lags little during fast
movement and smooths hard when the hand is nearly still.

Defaults come from the One Euro Filter paper (Casiez, Roussel & Vogel, CHI
2012) as used for pointer control, then tuned to the palm-width velocity
range of this app. They are proposed defaults.
"""

from __future__ import annotations

import math


class EMASmoother:
    """Exponential moving average for a scalar or a 2-tuple."""

    def __init__(self, alpha: float = 0.35) -> None:
        if not 0.0 < alpha <= 1.0:
            raise ValueError("alpha must be in (0, 1]")
        self.alpha = alpha
        self._value: tuple[float, ...] | None = None

    def __call__(self, value: tuple[float, ...]) -> tuple[float, ...]:
        if self._value is None or len(self._value) != len(value):
            self._value = tuple(float(v) for v in value)
        else:
            a = self.alpha
            self._value = tuple(a * float(v) + (1 - a) * p
                                for v, p in zip(value, self._value))
        return self._value

    def reset(self) -> None:
        self._value = None


class OneEuroFilter:
    """Speed-adaptive low-pass filter for one dimension."""

    def __init__(self, min_cutoff: float = 1.2, beta: float = 0.03,
                 d_cutoff: float = 1.0) -> None:
        if min_cutoff <= 0 or d_cutoff <= 0:
            raise ValueError("cutoff frequencies must be positive")
        self.min_cutoff = min_cutoff
        self.beta = beta
        self.d_cutoff = d_cutoff
        self._x: float | None = None
        self._dx = 0.0
        self._last_time: float | None = None

    @staticmethod
    def _alpha(cutoff: float, dt: float) -> float:
        tau = 1.0 / (2.0 * math.pi * cutoff)
        return 1.0 / (1.0 + tau / max(dt, 1e-6))

    def __call__(self, value: float, timestamp: float | None = None) -> float:
        """Filter one sample. ``timestamp`` in seconds; ``None`` uses a
        nominal 30 fps step so the filter still behaves without a clock."""
        if timestamp is None:
            dt = 1.0 / 30.0
        elif self._last_time is None:
            dt = 1.0 / 30.0
        else:
            dt = max(timestamp - self._last_time, 1e-4)
        self._last_time = timestamp

        if self._x is None:
            self._x = float(value)
            self._dx = 0.0
            return self._x

        raw_derivative = (float(value) - self._x) / dt
        a_d = self._alpha(self.d_cutoff, dt)
        self._dx = a_d * raw_derivative + (1 - a_d) * self._dx

        cutoff = self.min_cutoff + self.beta * abs(self._dx)
        a = self._alpha(cutoff, dt)
        self._x = a * float(value) + (1 - a) * self._x
        return self._x

    def reset(self) -> None:
        self._x = None
        self._dx = 0.0
        self._last_time = None


class PointerFilter:
    """Two-dimensional pointer filter with a selectable strategy."""

    STRATEGIES = ("one_euro", "ema", "none")

    def __init__(self, strategy: str = "one_euro", *, min_cutoff: float = 1.2,
                 beta: float = 0.03, d_cutoff: float = 1.0,
                 alpha: float = 0.35) -> None:
        if strategy not in self.STRATEGIES:
            raise ValueError(f"strategy must be one of {self.STRATEGIES}")
        self.strategy = strategy
        self._x = OneEuroFilter(min_cutoff, beta, d_cutoff)
        self._y = OneEuroFilter(min_cutoff, beta, d_cutoff)
        self._ema = EMASmoother(alpha)

    def __call__(self, point: tuple[float, float],
                 timestamp: float | None = None) -> tuple[float, float]:
        if self.strategy == "none":
            return (float(point[0]), float(point[1]))
        if self.strategy == "ema":
            return self._ema(point)
        return (self._x(point[0], timestamp), self._y(point[1], timestamp))

    def reset(self) -> None:
        self._x.reset()
        self._y.reset()
        self._ema.reset()
