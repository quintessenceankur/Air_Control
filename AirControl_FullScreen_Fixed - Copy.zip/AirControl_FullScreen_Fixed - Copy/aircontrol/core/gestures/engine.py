"""The gesture engine: smoothing, hysteresis, dwell, cooldown, tracking loss.

The engine is the only place that holds gesture state. It is pure Python: it
takes hands and a timestamp, returns events. Time is *injected* (``now``), so
every timed behaviour can be tested with a synthetic clock and replayed from a
recorded landmark file with no camera and no Qt.

Design rules that this class enforces (see the project's recognition notes):

* No hand, no action -- a frame without a plausible hand resets the engine to
  idle and discards any partial dwell.
* Never fire on every frame -- one event per activation, then a cooldown.
* Hysteresis -- activation needs ``enter``; deactivation needs the score to
  stay below ``exit`` for several frames, so a score hovering at the boundary
  cannot chatter.
* Dwell counts *frames*, not wall time, so a dropped frame cannot shorten the
  hold by accident.
"""

from __future__ import annotations

from dataclasses import replace
from typing import Callable, Iterable, Mapping

from aircontrol.core.features import HandFeatures, extract_features
from aircontrol.core.gestures.classifiers import score_all
from aircontrol.core.gestures.events import GestureEvent, RecognitionState
from aircontrol.core.gestures.spec import (
    DEFAULT_ENGINE_CONFIG,
    GESTURE_SPECS,
    UNKNOWN,
    EngineConfig,
    GestureSpec,
)
from aircontrol.core.landmarks import (
    HandFrame,
    is_plausible,
    palm_width,
    smooth_landmarks,
)

#: A callable that maps features to per-gesture probabilities (the optional
#: ML classifier). Kept as a protocol-by-callable so ``core`` never imports
#: the ML package unless the UI wires it in.
ScoreFn = Callable[[HandFeatures], Mapping[str, float]]


class GestureEngine:
    """Turn a stream of hands into a stream of gesture activations."""

    def __init__(
        self,
        config: EngineConfig | None = None,
        specs: Mapping[str, GestureSpec] | None = None,
        ml_scorer: ScoreFn | None = None,
    ) -> None:
        self.config = config or DEFAULT_ENGINE_CONFIG
        self.specs: dict[str, GestureSpec] = dict(specs or GESTURE_SPECS)
        self._ml_scorer = ml_scorer

        self._prev_landmarks: tuple | None = None
        self._prev_handedness: str | None = None
        self._active: str | None = None
        self._release_count = 0
        self._hold: dict[str, int] = {name: 0 for name in self.specs}
        self._last_fire: dict[str, float] = {}
        self._state = RecognitionState()
        self._last_features: HandFeatures | None = None

    # -- public API -----------------------------------------------------------

    @property
    def state(self) -> RecognitionState:
        return self._state

    @property
    def active_gesture(self) -> str | None:
        return self._active

    @property
    def last_features(self) -> HandFeatures | None:
        """Features of the most recent classified frame (for continuous control)."""
        return self._last_features

    def update(self, hands: Iterable[HandFrame], now: float) -> list[GestureEvent]:
        """Classify one frame. Returns the events fired *this* frame."""
        hands = list(hands)
        usable = [h for h in hands
                  if h.is_complete and h.presence >= self.config.min_presence
                  and is_plausible(h)]
        if not usable:
            self._lose_tracking(len(hands))
            return []

        hand = self._select_hand(usable)
        features = self._features_for(hand)
        scores = self._score(features)
        events = self._advance(scores, now, hand.handedness)

        top_name, top_score = self._top(scores)
        self._state = RecognitionState(
            stable=self._active,
            candidate=top_name if top_score > 0.0 else None,
            confidence=float(scores[self._active]) if self._active else float(top_score),
            scores=dict(scores),
            features=features,
            tracking=True,
            handedness=hand.handedness,
            hands_detected=len(usable),
        )
        self._last_features = features
        return events

    def reset(self) -> None:
        """Return to idle, discarding dwell, hold and cooldown state."""
        self._prev_landmarks = None
        self._prev_handedness = None
        self._active = None
        self._release_count = 0
        self._hold = {name: 0 for name in self.specs}
        self._last_fire.clear()
        self._last_features = None
        self._state = RecognitionState()

    def scores_for(self, features: HandFeatures) -> dict[str, float]:
        """Score one feature set without touching engine state (used by tests)."""
        return self._score(features)

    # -- internals ------------------------------------------------------------

    def _select_hand(self, hands: list[HandFrame]) -> HandFrame:
        """Pick the hand to classify: the nearest, most confident one.

        Palm width in image space is a proxy for distance; multiplying by
        presence prefers a close, well-tracked hand over a distant ghost.
        """
        return max(hands, key=lambda h: palm_width(h) * max(h.presence, 1e-3))

    def _features_for(self, hand: HandFrame) -> HandFeatures:
        if hand.handedness != self._prev_handedness:
            self._prev_landmarks = None
            self._prev_handedness = hand.handedness
        smoothed = smooth_landmarks(self._prev_landmarks, hand.landmarks,
                                    self.config.ema_alpha)
        self._prev_landmarks = smoothed
        return extract_features(replace(hand, landmarks=smoothed))

    def _score(self, features: HandFeatures) -> dict[str, float]:
        scores = score_all(features)
        weight = float(self.config.ml_weight)
        if self._ml_scorer is not None and weight > 0.0:
            ml = self._ml_scorer(features)
            for name in scores:
                blended = (1.0 - weight) * scores[name] + weight * float(ml.get(name, 0.0))
                scores[name] = float(max(0.0, min(1.0, blended)))
        return scores

    @staticmethod
    def _top(scores: Mapping[str, float]) -> tuple[str, float]:
        # ``max`` keeps the first maximum in vocabulary order, so ties are
        # deterministic across runs and platforms.
        best_name = UNKNOWN
        best_score = 0.0
        for name, score in scores.items():
            if score > best_score:
                best_name, best_score = name, float(score)
        return best_name, best_score

    def _advance(self, scores: Mapping[str, float], now: float,
                 handedness: str) -> list[GestureEvent]:
        top_name, top_score = self._top(scores)
        events: list[GestureEvent] = []

        if self._active is None:
            if self._dwell_met(top_name, top_score) and self._cooldown_ok(top_name, now):
                events.append(self._activate(top_name, top_score, now, handedness))
            return events

        active_spec = self.specs[self._active]
        if scores[self._active] >= active_spec.exit:
            self._release_count = 0
            # A different gesture may take over, but only after its own dwell.
            if top_name != self._active and top_name != UNKNOWN:
                if self._dwell_met(top_name, top_score) and self._cooldown_ok(top_name, now):
                    self._active = None
                    self._release_count = 0
                    events.append(self._activate(top_name, top_score, now, handedness))
            return events

        self._release_count += 1
        if self._release_count >= active_spec.release_frames:
            self._active = None
            self._release_count = 0
            self._hold = {name: 0 for name in self.specs}
        return events

    def _dwell_met(self, name: str, score: float) -> bool:
        """Count one frame toward ``name``'s dwell and report whether it is met."""
        if name == UNKNOWN or name not in self.specs:
            return False
        spec = self.specs[name]
        if score >= spec.enter:
            self._hold[name] = self._hold.get(name, 0) + 1
        else:
            self._hold[name] = 0
        # Reset the other counters only when they are not the challenger, so
        # two alternating candidates cannot both accumulate dwell.
        for other in self._hold:
            if other != name and self._hold[other]:
                self._hold[other] = 0
        needed = spec.dwell_frames if self._active is None else max(
            1, self.config.switch_dwell_frames)
        return self._hold[name] >= needed

    def _cooldown_ok(self, name: str, now: float) -> bool:
        last = self._last_fire.get(name)
        if last is None:
            return True
        return (now - last) * 1000.0 >= self.specs[name].cooldown_ms

    def _activate(self, name: str, score: float, now: float,
                  handedness: str) -> GestureEvent:
        self._active = name
        self._release_count = 0
        self._last_fire[name] = now
        self._hold = {n: 0 for n in self.specs}
        return GestureEvent(name=name, confidence=float(score),
                            timestamp=now, handedness=handedness)

    def _lose_tracking(self, detected: int) -> None:
        """No usable hand: go idle and discard any partial hold.

        The cooldown history is kept deliberately -- a hand that flickers out
        for one frame must not be able to re-fire the same action instantly.
        """
        self._active = None
        self._release_count = 0
        self._hold = {name: 0 for name in self.specs}
        self._prev_landmarks = None
        self._prev_handedness = None
        self._last_features = None
        self._state = RecognitionState(tracking=False, hands_detected=detected)


def replay(rows: Iterable[Mapping], engine: GestureEngine) -> list[GestureEvent]:
    """Feed fixture rows through an engine using the fixture's own clock.

    Shared by the replay tests, the evaluation script and the offline
    calibration tool, so all three measure the same thing.
    """
    events: list[GestureEvent] = []
    for row in rows:
        hand = hand_from_row(row)
        events.extend(engine.update([hand] if hand else [], float(row.get("t", 0.0))))
    return events


def hand_from_row(row: Mapping) -> HandFrame | None:
    """Convert one fixture row (or detector output) into a :class:`HandFrame`."""
    landmarks = row.get("landmarks")
    if not landmarks:
        return None
    from aircontrol.core.landmarks import hand_from_array
    return hand_from_array(
        landmarks,
        handedness=str(row.get("handedness", "Right")),
        presence=float(row.get("presence", 1.0)),
        timestamp=float(row.get("t", 0.0)),
    )
