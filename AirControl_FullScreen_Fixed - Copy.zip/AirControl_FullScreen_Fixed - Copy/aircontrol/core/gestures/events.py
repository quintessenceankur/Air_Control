"""Event and state objects produced by the gesture engine."""

from __future__ import annotations

from dataclasses import dataclass, field

from aircontrol.core.features import HandFeatures


@dataclass(frozen=True)
class GestureEvent:
    """A single *activation* of a gesture.

    Emitted once when a gesture enters its active state -- never once per
    frame. ``timestamp`` is the ``now`` the engine was given, so replay with a
    synthetic clock produces deterministic timestamps.
    """

    name: str
    confidence: float
    timestamp: float
    handedness: str = "Right"


@dataclass(frozen=True)
class RecognitionState:
    """What the engine currently believes, for the UI and the controllers.

    ``stable`` is the active gesture (or ``None``), ``candidate`` is the best
    scoring gesture this frame, and ``scores`` carries every raw score so the
    Live Gesture Studio can show why a gesture was rejected.
    """

    stable: str | None = None
    candidate: str | None = None
    confidence: float = 0.0
    scores: dict[str, float] = field(default_factory=dict)
    features: HandFeatures | None = None
    tracking: bool = False
    handedness: str | None = None
    hands_detected: int = 0

    @property
    def gesture_label(self) -> str:
        """Human-readable label for display."""
        return self.stable or "NO_GESTURE"


@dataclass(frozen=True)
class FrameResult:
    """One engine step: the events it fired plus the state it reached."""

    events: tuple[GestureEvent, ...]
    state: RecognitionState
