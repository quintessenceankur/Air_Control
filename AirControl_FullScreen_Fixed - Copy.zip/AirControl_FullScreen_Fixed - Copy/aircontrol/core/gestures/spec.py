"""The AirControl gesture vocabulary and its thresholds -- the single source.

Nothing in this project may hard-code a gesture name, an enter/exit score, a
dwell count or a key binding. Reviewers change behaviour here.

Provenance
----------
Every value carries a :data:`PROVENANCE` marker:

``approved``
    Taken from the owner's specification or from the owner's existing
    reference implementation (``gesture_recognizer.py``,
    ``landmark_processor.py``, ``finger_test.py`` in the original project).
``proposed``
    An engineering default chosen while rebuilding, because the
    specification did not state a value. It is listed in
    :data:`PENDING_APPROVAL` and must be confirmed or overruled by the owner.

Hand shapes (the vocabulary itself)
-----------------------------------
The seven gesture names come from the owner's specification section 3.3.
The *hand shape* for each was not written out, so the shapes below follow the
owner's reference implementation, with the additions noted per gesture.
"""

from __future__ import annotations

from dataclasses import dataclass

APPROVED = "approved"
PROPOSED = "proposed"


@dataclass(frozen=True)
class GestureSpec:
    """Recognition behaviour for one gesture.

    ``enter`` / ``exit`` form a hysteresis band: the gesture activates at or
    above ``enter`` for ``dwell_frames`` consecutive frames, and only
    deactivates after the score has stayed below ``exit`` for
    ``release_frames`` frames. ``cooldown_ms`` prevents a second activation
    of the same gesture immediately after one fires.
    """

    name: str
    description: str
    enter: float
    exit: float
    dwell_frames: int
    release_frames: int
    cooldown_ms: int
    requires_hands: int = 1
    provenance: str = PROPOSED

    def __post_init__(self) -> None:
        if not 0.0 < self.exit < self.enter <= 1.0:
            raise ValueError(f"{self.name}: need 0 < exit < enter <= 1")
        if self.dwell_frames < 1 or self.release_frames < 1:
            raise ValueError(f"{self.name}: frame counts must be >= 1")
        if self.cooldown_ms < 0:
            raise ValueError(f"{self.name}: cooldown must be >= 0")


#: Hysteresis band and dwell shared by the geometric classifiers. The 0.80 /
#: 0.60 band and 5-frame dwell are the values the AirControl build method
#: prescribes; 600 ms cooldown likewise.
_ENTER = 0.80
_EXIT = 0.60
_DWELL = 5
_RELEASE = 3
_COOLDOWN = 600

GESTURE_SPECS: dict[str, GestureSpec] = {
    "OPEN_PALM": GestureSpec(
        name="OPEN_PALM",
        description="All five fingers extended, palm toward the camera.",
        enter=_ENTER, exit=_EXIT, dwell_frames=_DWELL,
        release_frames=_RELEASE, cooldown_ms=_COOLDOWN,
    ),
    "CLOSED_FIST": GestureSpec(
        name="CLOSED_FIST",
        description="All five fingers curled into the palm.",
        enter=_ENTER, exit=_EXIT, dwell_frames=_DWELL,
        release_frames=_RELEASE, cooldown_ms=_COOLDOWN,
    ),
    "PINCH": GestureSpec(
        name="PINCH",
        description=(
            "Thumb tip and index tip brought together: their distance is at "
            "most 0.36 palm widths to enter and must exceed 0.48 to release "
            "(hysteresis inherited from the owner's reference implementation)."
        ),
        enter=_ENTER, exit=_EXIT, dwell_frames=_DWELL,
        release_frames=_RELEASE, cooldown_ms=_COOLDOWN,
    ),
    "TWO_FINGERS": GestureSpec(
        name="TWO_FINGERS",
        description=(
            "Index and middle extended, ring and pinky curled (peace sign). "
            "Thumb state is not constrained, because a natural peace sign "
            "holds the thumb either way."
        ),
        enter=_ENTER, exit=_EXIT, dwell_frames=_DWELL,
        release_frames=_RELEASE, cooldown_ms=_COOLDOWN,
    ),
    "THREE_FINGERS": GestureSpec(
        name="THREE_FINGERS",
        description="Index, middle and ring extended, pinky curled.",
        enter=_ENTER, exit=_EXIT, dwell_frames=_DWELL,
        release_frames=_RELEASE, cooldown_ms=_COOLDOWN,
    ),
    "THUMBS_UP": GestureSpec(
        name="THUMBS_UP",
        description=(
            "Thumb extended and pointing up on screen, other four fingers "
            "curled. 'Up' is measured in image space, so a tilted hand still "
            "counts while the thumb points up."
        ),
        enter=_ENTER, exit=_EXIT, dwell_frames=_DWELL,
        release_frames=_RELEASE, cooldown_ms=_COOLDOWN,
    ),
    "THUMBS_DOWN": GestureSpec(
        name="THUMBS_DOWN",
        description="Thumb extended and pointing down on screen, other four curled.",
        enter=_ENTER, exit=_EXIT, dwell_frames=_DWELL,
        release_frames=_RELEASE, cooldown_ms=_COOLDOWN,
    ),
}

#: The owner's seven-gesture vocabulary, in spec order.
VOCABULARY: tuple[str, ...] = tuple(GESTURE_SPECS)

#: Reported by the engine when nothing is recognised.
UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class EngineConfig:
    """Tunables for :class:`aircontrol.core.gestures.engine.GestureEngine`."""

    #: EMA weight of the newest frame applied to landmarks before features.
    ema_alpha: float = 0.5
    #: Hands below this presence score are dropped before classification.
    min_presence: float = 0.50
    #: Pinch ratios (thumb tip to index tip, in palm widths).
    pinch_enter_ratio: float = 0.36
    pinch_exit_ratio: float = 0.48
    #: Weight of the optional ML classifier in the blended score. 0 disables
    #: it, which is the default: the geometric rules are the shipped path.
    ml_weight: float = 0.0
    #: Frames a candidate must persist before it can replace an active
    #: gesture.
    switch_dwell_frames: int = 3


DEFAULT_ENGINE_CONFIG = EngineConfig()

#: Every value below was chosen by the rebuild, not stated by the owner.
#: Each entry names the value, what it gates, and where it lives.
PENDING_APPROVAL: tuple[str, ...] = (
    "Gesture shapes: OPEN_PALM / CLOSED_FIST / PINCH / TWO_FINGERS / "
    "THREE_FINGERS / THUMBS_UP / THUMBS_DOWN follow the owner's reference "
    "implementation; the exact finger-shape wording is the rebuild's.",
    "Hysteresis band 0.80 enter / 0.60 exit, 5-frame dwell, 3-frame release, "
    "600 ms cooldown (GestureSpec defaults in this file).",
    "pinch_enter_ratio 0.36 / pinch_exit_ratio 0.48 -- inherited from the "
    "owner's LandmarkProcessor hysteresis, re-used as-is.",
    "ema_alpha 0.50 landmark smoothing (EngineConfig).",
    "min_presence 0.50 detection gate (EngineConfig).",
    "Finger extension bands: PIP_ANGLE_BAND 130-168 deg, "
    "FINGER_LENGTH_RATIO_BAND 0.95-1.25, THUMB_OPENNESS_BAND 0.50-0.85, "
    "EXTENDED_SCORE 0.50 (core/features.py).",
    "Pinch score guard against OPEN_PALM (core/gestures/classifiers.py).",
    "Two/three-finger poses do not constrain the thumb (spec above).",
    "Thumb up/down direction margin 0.30-0.75 palm widths measured from the "
    "thumb CMC joint, and the thumb-extended gate 0.35-0.65 "
    "(core/gestures/classifiers.py).",
    "Default gesture-to-action bindings and their key combos "
    "(core/actions.py) -- none of these were specified by the owner.",
    "Air mouse gains, dead zone, One Euro filter parameters "
    "(controllers/air_mouse.py).",
    "Global hotkeys: Ctrl+Alt+A toggle control, Ctrl+Alt+X emergency stop "
    "(services/safety.py).",
)


def spec_for(name: str) -> GestureSpec:
    """Look up a gesture spec, raising ``KeyError`` for unknown names."""
    try:
        return GESTURE_SPECS[name]
    except KeyError as exc:  # pragma: no cover - defensive
        raise KeyError(
            f"unknown gesture {name!r}; vocabulary is {sorted(GESTURE_SPECS)}"
        ) from exc


def validate_specs() -> None:
    """Fail fast if the vocabulary table is internally inconsistent."""
    for name, spec in GESTURE_SPECS.items():
        if name != spec.name:
            raise ValueError(f"key {name!r} does not match spec name {spec.name!r}")
        if spec.requires_hands not in (1, 2):
            raise ValueError(f"{name}: requires_hands must be 1 or 2")
