"""Gesture score functions -- one pure function per gesture.

Each function takes :class:`aircontrol.core.features.HandFeatures` and returns
a score in ``[0, 1]``. No state, no clock, no camera: a score depends only on
the frame in front of it, which is what makes the whole recognition path
replayable from recorded landmarks.

Hysteresis, dwell and cooldown live in
:mod:`aircontrol.core.gestures.engine`, not here, so a score can be logged
and compared against the band without side effects.
"""

from __future__ import annotations

from typing import Callable

import numpy as np

from aircontrol.core.features import HandFeatures
from aircontrol.core.landmarks import THUMB_CMC, THUMB_TIP
from aircontrol.core.gestures.spec import DEFAULT_ENGINE_CONFIG

#: Direction margin band for thumbs up/down, in palm widths (PROPOSED DEFAULT).
#: Measured from the thumb CMC joint (landmark 1) to the tip: a full palm
#: width of baseline, so both jitter and the thumb's natural bow matter less
#: than they do over the shorter MCP-to-tip span.
THUMB_DIRECTION_BAND = (0.30, 0.75)
#: Is the thumb out, or folded? One gate, used by both sides: the thumbs-up
#: and thumbs-down classifiers multiply by it, and the fist classifier
#: multiplies by its complement. This is what separates a fist from a
#: thumbs-up -- both have four curled fingers and only the thumb differs.
#: A gated decision, not a magnitude, so it does not depend on how far the
#: user spreads the thumb.
THUMB_EXTENDED_GATE = (0.35, 0.65)
#: How strongly an open palm suppresses the pinch score (PROPOSED DEFAULT).
PINCH_OPEN_PALM_GUARD = 0.60
#: Pinch ratio band mapped to a score: 1.0 at or below lo, 0.0 at or above hi.
#: Derived from the hysteresis ratios in EngineConfig so the two cannot drift.
PINCH_SCORE_BAND = (DEFAULT_ENGINE_CONFIG.pinch_enter_ratio - 0.06,
                    DEFAULT_ENGINE_CONFIG.pinch_exit_ratio + 0.02)


def _and(*scores: float) -> float:
    """Conjunction of several conditions, degrading gracefully.

    The geometric mean asks "are all of these true?" but, unlike ``min``, a
    single partly-satisfied condition (a slightly curved finger) only dents
    the result instead of collapsing it. That is what makes an open palm
    survive a finger the user did not straighten completely, while a peace
    sign (two fingers fully curled) still scores far below it.
    """
    epsilon = 1e-3
    total = 1.0
    for score in scores:
        total *= max(epsilon, min(1.0, float(score)))
    return float(total ** (1.0 / max(1, len(scores))))


def _ramp(value: float, lo: float, hi: float) -> float:
    if hi <= lo:
        raise ValueError("band must be increasing")
    return float(min(1.0, max(0.0, (value - lo) / (hi - lo))))


def score_open_palm(f: HandFeatures) -> float:
    """All five fingers extended.

    Mean alone lets four straight fingers outvote one curled finger, so the
    score is half mean and half minimum: a single clearly curled finger pulls
    the result down.
    """
    return _and(*(f.extension[name] for name in
                  ("thumb", "index", "middle", "ring", "pinky")))


def score_closed_fist(f: HandFeatures) -> float:
    """All five fingers curled, thumb included.

    The thumb gate is what separates a fist from a thumbs-up: both have four
    curled fingers, and only the thumb tells them apart.
    """
    gate = 1.0 - _ramp(f.extension["thumb"], *THUMB_EXTENDED_GATE)
    return _and(*(1.0 - f.extension[name]
                  for name in ("thumb", "index", "middle", "ring", "pinky"))) * gate


def score_pinch(f: HandFeatures) -> float:
    """Thumb tip touching index tip, normalised by palm width.

    An open palm is suppressed: when every finger is straight the thumb can
    pass close to the index tip at an oblique angle, and that must not read
    as a click.
    """
    raw = 1.0 - _ramp(f.pinch_ratio, *PINCH_SCORE_BAND)
    guard = 1.0 - PINCH_OPEN_PALM_GUARD * score_open_palm(f)
    return float(max(0.0, min(1.0, raw * guard)))


def score_two_fingers(f: HandFeatures) -> float:
    """Index and middle extended; ring and pinky curled."""
    e = f.extension
    return _and(e["index"], e["middle"], 1.0 - e["ring"], 1.0 - e["pinky"])


def score_three_fingers(f: HandFeatures) -> float:
    """Index, middle and ring extended; pinky curled."""
    e = f.extension
    return _and(e["index"], e["middle"], e["ring"], 1.0 - e["pinky"])


def _thumb_direction(f: HandFeatures, upward: bool) -> float:
    """How clearly the thumb points up (or down) on screen.

    Measured on raw image coordinates, because this is a screen-relative
    gesture: ``y`` grows downward, so "up" means a smaller ``y`` at the tip
    than at the thumb CMC joint. The margin is scaled by palm width so it does
    not depend on camera distance.
    """
    tip_y = float(f.raw[THUMB_TIP][1])
    base_y = float(f.raw[THUMB_CMC][1])
    delta = (base_y - tip_y) if upward else (tip_y - base_y)
    margin = delta / max(f.scale, 1e-6)
    return _ramp(margin, *THUMB_DIRECTION_BAND)


def _thumb_only(f: HandFeatures) -> float:
    """Thumb clearly extended *and* the four fingers curled.

    The thumb is a direct multiplier rather than one term of a geometric
    mean: a thumbs-up with a half-tucked thumb is not a thumbs-up at all, and
    the geometric mean alone would let four curled fingers carry it.
    """
    e = f.extension
    curled = float(np.mean([1.0 - e[name]
                            for name in ("index", "middle", "ring", "pinky")]))
    return float(_ramp(e["thumb"], *THUMB_EXTENDED_GATE) * curled)


def score_thumbs_up(f: HandFeatures) -> float:
    """Thumb extended and pointing up; the four fingers curled."""
    return float(_thumb_only(f) * _thumb_direction(f, upward=True))


def score_thumbs_down(f: HandFeatures) -> float:
    """Thumb extended and pointing down; the four fingers curled."""
    return float(_thumb_only(f) * _thumb_direction(f, upward=False))


GESTURE_CLASSIFIERS: dict[str, Callable[[HandFeatures], float]] = {
    "OPEN_PALM": score_open_palm,
    "CLOSED_FIST": score_closed_fist,
    "PINCH": score_pinch,
    "TWO_FINGERS": score_two_fingers,
    "THREE_FINGERS": score_three_fingers,
    "THUMBS_UP": score_thumbs_up,
    "THUMBS_DOWN": score_thumbs_down,
}


def score_all(f: HandFeatures) -> dict[str, float]:
    """Score every gesture in the vocabulary for one hand."""
    return {name: fn(f) for name, fn in GESTURE_CLASSIFIERS.items()}
