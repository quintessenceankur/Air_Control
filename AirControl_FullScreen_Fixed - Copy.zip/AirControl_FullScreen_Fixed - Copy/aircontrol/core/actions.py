"""The declarative binding table: which gesture does what, in which mode.

A binding is data. The controllers read these tables; no controller contains
an ``if gesture == "PINCH": send_key(...)`` branch.

**None of the bindings below came from the owner's specification.** The
specification names the action surfaces (media, presentation, mouse) but not
which gesture drives which action, so these are proposed defaults, marked
:data:`~aircontrol.core.gestures.spec.PROPOSED`, editable at runtime and
persisted in SQLite. They are also listed in
``spec.PENDING_APPROVAL``.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Mapping

from aircontrol.core.gestures.spec import GESTURE_SPECS, PROPOSED


class ControlMode(str, Enum):
    """Which controller currently owns the gesture stream."""

    NONE = "none"
    AIR_MOUSE = "air_mouse"
    MEDIA = "media"
    PRESENTATION = "presentation"

    @property
    def label(self) -> str:
        return {
            ControlMode.NONE: "Idle",
            ControlMode.AIR_MOUSE: "Air Mouse",
            ControlMode.MEDIA: "Media",
            ControlMode.PRESENTATION: "Presentation",
        }[self]


#: Action kinds understood by :class:`aircontrol.automation.base.ActionExecutor`.
KEY = "key"
MEDIA = "media"
NONE = "none"


@dataclass(frozen=True)
class Action:
    """A single OS-level effect.

    ``kind`` selects the executor method: ``key`` -> ``send_key``, ``media``
    -> ``media_key``, ``none`` -> nothing (a deliberate no-op binding).
    """

    kind: str
    target: str = ""
    description: str = ""
    provenance: str = PROPOSED


#: Media targets the executor must implement (Windows virtual media keys).
MEDIA_TARGETS: tuple[str, ...] = (
    "play_pause", "next", "previous", "volume_up", "volume_down", "mute",
)

#: Presentation targets: standard slide-navigation keys, mapped in
#: :mod:`aircontrol.automation.keyboard`.
PRESENTATION_TARGETS: tuple[str, ...] = (
    "next_slide", "previous_slide", "start_presentation", "exit_presentation",
)

#: Air-mouse roles -- continuous behaviours, not one-shot actions.
AIR_MOUSE_ROLES: tuple[str, ...] = ("pointer", "click", "right_click", "scroll", "pause")


DEFAULT_MEDIA_BINDINGS: dict[str, Action] = {
    "THUMBS_UP": Action(MEDIA, "volume_up", "Volume up"),
    "THUMBS_DOWN": Action(MEDIA, "volume_down", "Volume down"),
    "OPEN_PALM": Action(MEDIA, "play_pause", "Play / pause"),
    "CLOSED_FIST": Action(MEDIA, "mute", "Mute / unmute"),
    "TWO_FINGERS": Action(MEDIA, "next", "Next track"),
    "THREE_FINGERS": Action(MEDIA, "previous", "Previous track"),
    "PINCH": Action(NONE, "", "Unbound (reserved)"),
}

DEFAULT_PRESENTATION_BINDINGS: dict[str, Action] = {
    "TWO_FINGERS": Action(KEY, "next_slide", "Next slide"),
    "THREE_FINGERS": Action(KEY, "previous_slide", "Previous slide"),
    "OPEN_PALM": Action(KEY, "start_presentation", "Start presentation (F5)"),
    "CLOSED_FIST": Action(KEY, "exit_presentation", "Exit presentation (Esc)"),
    "PINCH": Action(NONE, "", "Unbound (reserved)"),
    "THUMBS_UP": Action(NONE, "", "Unbound (reserved)"),
    "THUMBS_DOWN": Action(NONE, "", "Unbound (reserved)"),
}

DEFAULT_AIR_MOUSE_ROLES: dict[str, str] = {
    "TWO_FINGERS": "pointer",
    "PINCH": "click",
    "THREE_FINGERS": "right_click",
    "OPEN_PALM": "scroll",
    "CLOSED_FIST": "pause",
}


def bindings_for(mode: ControlMode) -> dict[str, Action]:
    """Return the default binding table for a mode (empty for idle/air mouse)."""
    if mode is ControlMode.MEDIA:
        return dict(DEFAULT_MEDIA_BINDINGS)
    if mode is ControlMode.PRESENTATION:
        return dict(DEFAULT_PRESENTATION_BINDINGS)
    return {}


def validate_bindings(mode: ControlMode, bindings: Mapping[str, Action]) -> None:
    """Reject a binding table that names an unknown gesture or target.

    Called on load from the database and by the tests, so a hand-edited row
    cannot put an unexpected key combination into the executor.
    """
    if mode is ControlMode.MEDIA:
        allowed = MEDIA_TARGETS
    elif mode is ControlMode.PRESENTATION:
        allowed = PRESENTATION_TARGETS
    else:
        allowed = ()
    for gesture, action in bindings.items():
        if gesture not in GESTURE_SPECS:
            raise ValueError(f"{mode.value}: unknown gesture {gesture!r}")
        if action.kind == NONE:
            continue
        if action.kind not in (KEY, MEDIA):
            raise ValueError(f"{mode.value}/{gesture}: unknown action kind {action.kind!r}")
        if not allowed:
            raise ValueError(f"{mode.value}: mode has no action targets")
        if action.target not in allowed:
            raise ValueError(f"{mode.value}/{gesture}: target {action.target!r} not allowed")


def validate_air_mouse_roles(roles: Mapping[str, str]) -> None:
    for gesture, role in roles.items():
        if gesture not in GESTURE_SPECS:
            raise ValueError(f"air mouse: unknown gesture {gesture!r}")
        if role not in AIR_MOUSE_ROLES:
            raise ValueError(f"air mouse/{gesture}: unknown role {role!r}")
    assigned = list(roles.values())
    if len(assigned) != len(set(assigned)):
        raise ValueError("air mouse: each role may be bound to one gesture only")


validate_bindings(ControlMode.MEDIA, DEFAULT_MEDIA_BINDINGS)
validate_bindings(ControlMode.PRESENTATION, DEFAULT_PRESENTATION_BINDINGS)
validate_air_mouse_roles(DEFAULT_AIR_MOUSE_ROLES)
