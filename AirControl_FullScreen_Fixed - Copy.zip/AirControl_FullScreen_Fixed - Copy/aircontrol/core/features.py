"""Feature extraction from canonical hand landmarks.

Pure module: numpy only. Every feature is scale-invariant because it is
computed from :func:`aircontrol.core.landmarks.to_canonical` output, where
one unit is the user's palm width.

The mapping bands in this file are *proposed defaults*. They are declared
here, in one place, and each is exercised by a test in
``tests/unit/test_features.py``. They are listed in
``aircontrol/core/gestures/spec.py::PENDING_APPROVAL`` so the owner can
overrule them without hunting through the codebase.
"""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field
from typing import Iterable, Sequence

import numpy as np

from aircontrol.core.landmarks import (
    INDEX_MCP,
    INDEX_TIP,
    MIDDLE_MCP,
    PINKY_MCP,
    THUMB_TIP,
    WRIST,
    HandFrame,
    Point,
    angle_deg,
    centroid,
    distance,
    to_canonical,
)

FINGER_NAMES: tuple[str, ...] = ("thumb", "index", "middle", "ring", "pinky")

#: (mcp, pip, dip, tip) chains for the four non-thumb fingers.
FINGER_CHAINS: dict[str, tuple[int, int, int, int]] = {
    "index": (5, 6, 7, 8),
    "middle": (9, 10, 11, 12),
    "ring": (13, 14, 15, 16),
    "pinky": (17, 18, 19, 20),
}

# --- mapping bands (PROPOSED DEFAULTS -- see spec.PENDING_APPROVAL) ----------
#: Joint angle (degrees) mapped to straightness 0..1 for the four fingers.
PIP_ANGLE_BAND = (130.0, 168.0)
#: tip-to-wrist / pip-to-wrist length ratio mapped to 0..1.
FINGER_LENGTH_RATIO_BAND = (0.95, 1.25)
#: Angle band used for the thumb (its joints bend less than the fingers').
THUMB_ANGLE_BAND = (130.0, 170.0)
#: thumb-tip to index-MCP distance (palm widths) mapped to 0..1.
THUMB_OPENNESS_BAND = (0.35, 0.65)
#: Weighting of angle vs length evidence in the finger extension score.
ANGLE_WEIGHT = 0.55
#: A finger counts as extended at or above this score.
EXTENDED_SCORE = 0.50


def _band(value: float, lo: float, hi: float) -> float:
    """Linear map of ``value`` from ``[lo, hi]`` into ``[0, 1]``, clamped."""
    if hi <= lo:
        raise ValueError("band must be increasing")
    return float(min(1.0, max(0.0, (value - lo) / (hi - lo))))


def _finger_extension(c: np.ndarray, chain: tuple[int, int, int, int]) -> float:
    """Extension score 0..1 for one of the four fingers.

    Two independent pieces of evidence are combined, because either alone
    flickers: the joint angle collapses when a finger points at the camera,
    and the length ratio is noisy when the hand is foreshortened.
    """
    mcp, pip, dip, tip = chain
    ang_pip = angle_deg(c[mcp], c[pip], c[dip])
    ang_dip = angle_deg(c[pip], c[dip], c[tip])
    straight = _band((ang_pip + ang_dip) / 2.0, *PIP_ANGLE_BAND)

    wrist = c[WRIST]
    tip_len = float(np.linalg.norm(c[tip] - wrist))
    pip_len = float(np.linalg.norm(c[pip] - wrist))
    ratio = tip_len / max(pip_len, 1e-6)
    length = _band(ratio, *FINGER_LENGTH_RATIO_BAND)

    return ANGLE_WEIGHT * straight + (1.0 - ANGLE_WEIGHT) * length


def _thumb_extension(c: np.ndarray) -> float:
    """Extension score 0..1 for the thumb.

    The thumb is scored separately: it has one fewer phalanx in the useful
    chain and its abduction matters as much as its curl.
    """
    ang_mcp = angle_deg(c[1], c[2], c[3])
    ang_ip = angle_deg(c[2], c[3], c[4])
    straight = _band((ang_mcp + ang_ip) / 2.0, *THUMB_ANGLE_BAND)
    openness = _band(float(np.linalg.norm(c[THUMB_TIP] - c[INDEX_MCP])),
                     *THUMB_OPENNESS_BAND)
    return 0.6 * straight + 0.4 * openness


@dataclass(frozen=True)
class HandFeatures:
    """Everything the classifiers need for one hand in one frame."""

    extension: dict[str, float]
    pinch_ratio: float
    spread: float
    palm_roll_deg: float
    palm_facing: str
    pointer: tuple[float, float]
    centroid: tuple[float, float]
    handedness: str
    scale: float
    raw: np.ndarray = field(repr=False, compare=False)

    @property
    def extended(self) -> dict[str, bool]:
        return {name: score >= EXTENDED_SCORE for name, score in self.extension.items()}

    @property
    def extended_count(self) -> int:
        return sum(1 for v in self.extended.values() if v)

    def is_extended(self, finger: str) -> bool:
        return self.extension.get(finger, 0.0) >= EXTENDED_SCORE


def pinch_ratio(c: np.ndarray) -> float:
    """``||thumb_tip - index_tip|| / palm_width``.

    Canonical units make the palm width 1.0, but the division is kept so the
    value means the same thing if the canonical scale ever changes.
    """
    width = float(np.linalg.norm(c[INDEX_MCP] - c[PINKY_MCP]))
    return float(np.linalg.norm(c[THUMB_TIP] - c[INDEX_TIP]) / max(width, 1e-6))


def finger_spread(c: np.ndarray) -> float:
    """Mean pairwise distance between the four fingertips (palm widths)."""
    tips = [c[8], c[12], c[16], c[20]]
    pairs = [(tips[i], tips[j]) for i in range(4) for j in range(i + 1, 4)]
    return float(np.mean([np.linalg.norm(a - b) for a, b in pairs]))


def palm_roll(c: np.ndarray) -> float:
    """Angle of the wrist->middle-MCP axis from image-vertical, in degrees.

    Used as an orientation-tolerance input: thumbs-up/down are only accepted
    when the hand is not rolled far from vertical.
    """
    vec = c[MIDDLE_MCP] - c[WRIST]
    return float(math.degrees(math.atan2(vec[0], -vec[1])))


def palm_facing(c: np.ndarray) -> str:
    """Classify palm orientation as ``camera``, ``away`` or ``edge``.

    Diagnostic only -- no classifier in the current vocabulary depends on it,
    and its polarity has not been verified against hardware. It is surfaced
    in the Live Gesture Studio so it can be checked with a real camera.
    """
    normal = np.cross(c[INDEX_MCP] - c[WRIST], c[PINKY_MCP] - c[WRIST])
    norm = float(np.linalg.norm(normal))
    if norm < 1e-9:
        return "edge"
    nz = abs(float(normal[2] / norm))
    if nz < 0.55:
        return "edge"
    return "camera" if normal[2] < 0 else "away"


def extract_features(hand: HandFrame) -> HandFeatures:
    """Compute :class:`HandFeatures` for one hand.

    Raises ``ValueError`` for a degenerate hand (palm width ~0); callers gate
    with :func:`aircontrol.core.landmarks.is_plausible` first.
    """
    c = to_canonical(hand)
    extension = {name: _finger_extension(c, chain) for name, chain in FINGER_CHAINS.items()}
    extension["thumb"] = _thumb_extension(c)

    pointer = hand.point(INDEX_TIP)
    mid = centroid(hand)
    return HandFeatures(
        extension=extension,
        pinch_ratio=pinch_ratio(c),
        spread=finger_spread(c),
        palm_roll_deg=palm_roll(c),
        palm_facing=palm_facing(c),
        pointer=(pointer.x, pointer.y),
        centroid=(mid.x, mid.y),
        handedness=hand.handedness,
        scale=float(np.linalg.norm(hand.points()[INDEX_MCP] - hand.points()[PINKY_MCP])),
        raw=hand.points(),
    )


#: Feature vector layout for the optional ML classifier. Appending is safe;
#: reordering is not (a trained artifact depends on this order).
FEATURE_VECTOR_ORDER: tuple[str, ...] = (
    "thumb", "index", "middle", "ring", "pinky",
    "pinch_ratio", "spread", "palm_roll_norm",
)


def feature_vector(f: HandFeatures) -> np.ndarray:
    """Return the fixed-length vector consumed by the ML classifier."""
    return np.array([
        f.extension["thumb"], f.extension["index"], f.extension["middle"],
        f.extension["ring"], f.extension["pinky"],
        f.pinch_ratio, f.spread, f.palm_roll_deg / 90.0,
    ], dtype=float)


class MotionTracker:
    """Short-window hand motion estimate.

    Velocity is computed from a ring buffer rather than a single frame delta:
    one-frame differences are dominated by landmark jitter, which is exactly
    the signal a scroll action must not react to.
    """

    def __init__(self, window: int = 8) -> None:
        if window < 2:
            raise ValueError("window must be >= 2")
        self._samples: deque[tuple[float, Point, float]] = deque(maxlen=window)

    def update(self, hand_centroid: Point, scale: float, now: float) -> tuple[float, float]:
        """Return ``(vx, vy)`` in palm-widths per second."""
        self._samples.append((now, hand_centroid, max(scale, 1e-6)))
        if len(self._samples) < 2:
            return (0.0, 0.0)
        t0, p0, s0 = self._samples[0]
        t1, p1, s1 = self._samples[-1]
        dt = t1 - t0
        if dt <= 1e-6:
            return (0.0, 0.0)
        scale = (s0 + s1) / 2.0
        return ((p1.x - p0.x) / scale / dt, (p1.y - p0.y) / scale / dt)

    def reset(self) -> None:
        self._samples.clear()


def mean_extension(f: HandFeatures, fingers: Iterable[str] = FINGER_NAMES) -> float:
    names = list(fingers)
    if not names:
        return 0.0
    return float(np.mean([f.extension[n] for n in names]))
