"""Application configuration: dataclasses, JSON persistence, env overrides.

No module-level globals: :func:`load_config` returns an :class:`AppConfig`
that is passed explicitly to whatever needs it. That keeps tests hermetic --
a test builds the config it wants instead of monkey-patching module state.
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any

APP_DIR_NAME = "AirControl"
CONFIG_FILE_NAME = "config.json"
DB_FILE_NAME = "aircontrol.db"
MODEL_FILE_NAME = "hand_landmarker.task"


# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #
def is_frozen() -> bool:
    """True when running from a PyInstaller build."""
    return bool(getattr(sys, "frozen", False))


def app_root() -> Path:
    """Directory that contains the ``aircontrol`` package at runtime.

    In a PyInstaller one-dir build the bundled data lives beside the
    executable (inside ``_internal`` for PyInstaller 6, in the root for
    older versions), so both are checked. ``sys._MEIPASS`` is deliberately
    not used: in one-dir mode it points at the same place but its lifetime
    and layout are not guaranteed.
    """
    if is_frozen():
        exe_dir = Path(sys.executable).resolve().parent
        for candidate in (exe_dir / "_internal", exe_dir):
            if (candidate / "aircontrol").is_dir():
                return candidate
        return exe_dir
    return Path(__file__).resolve().parent.parent


def resource_path(relative: str) -> Path:
    """Resolve a file shipped under ``aircontrol/resources``."""
    candidates = [
        app_root() / "aircontrol" / "resources" / relative,
        Path(__file__).resolve().parent / "resources" / relative,
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return candidates[0]


def user_data_dir() -> Path:
    """Per-user writable directory for config, database and logs."""
    override = os.environ.get("AIRCONTROL_DATA_DIR")
    if override:
        return Path(override).expanduser()
    if os.name == "nt":
        base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        return Path(base) / APP_DIR_NAME
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "aircontrol"


def default_model_path() -> Path:
    """Path of the MediaPipe hand landmarker bundle."""
    override = os.environ.get("AIRCONTROL_MODEL")
    if override:
        return Path(override).expanduser()
    return resource_path(MODEL_FILE_NAME)


# --------------------------------------------------------------------------- #
# Sections
# --------------------------------------------------------------------------- #
@dataclass
class CameraConfig:
    """Webcam selection and capture format."""

    index: int = 0
    width: int = 1280
    height: int = 720
    fps: int = 30
    mirror: bool = True
    """Mirror frames before detection: the preview reads like a selfie and
    moving the hand right moves the cursor right."""


@dataclass
class RecognitionConfig:
    """Recognition tuning. Mirrors :class:`EngineConfig` plus the ML switch."""

    ema_alpha: float = 0.5
    min_presence: float = 0.5
    pinch_enter_ratio: float = 0.36
    pinch_exit_ratio: float = 0.48
    ml_enabled: bool = False
    ml_weight: float = 0.25
    """Weight of the ML classifier when ``ml_enabled``. Off by default: the
    shipped recognition path is the geometric rule set."""


@dataclass
class AirMouseConfig:
    """Cursor behaviour. Every value here is a proposed default."""

    gain: float = 1.0
    sensitivity: float = 1.0
    dead_zone_px: int = 3
    smoothing: str = "one_euro"  # one_euro | ema | none
    min_cutoff: float = 1.2
    beta: float = 0.03
    d_cutoff: float = 1.0
    active_region: float = 0.18
    """Fraction of the frame at each edge that is ignored, so the user does
    not have to reach the very corner of the camera's view."""
    drag_delay_s: float = 0.25
    scroll_gain: float = 6.0
    scroll_min_velocity: float = 0.6
    scroll_interval_ms: int = 80

    def describe_for_log(self) -> str:
        """One-line summary for the log and the mapping check script."""
        return (f"gain {self.gain:.2f}, sensitivity {self.sensitivity:.2f}, "
                f"margin {self.active_region:.2f}, smoothing {self.smoothing} "
                f"(cutoff {self.min_cutoff:.2f}), dead zone {self.dead_zone_px} px, "
                f"drag delay {self.drag_delay_s:.2f} s")


@dataclass
class UIConfig:
    theme: str = "dark"
    show_landmarks: bool = True
    preview_fps: int = 30
    start_minimised: bool = False


@dataclass
class SafetyConfig:
    """Safety switches. Hotkey strings are proposed defaults."""

    start_enabled: bool = False
    """Gesture control starts disabled: the user turns it on deliberately."""
    toggle_hotkey: str = "<ctrl>+<alt>+a"
    emergency_hotkey: str = "<ctrl>+<alt>+x"
    hotkeys_enabled: bool = True
    require_confirmation: bool = True
    log_rejected_candidates: bool = True


@dataclass
class StorageConfig:
    database_path: str = ""
    log_level: str = "INFO"

    def resolved_database_path(self) -> Path:
        if self.database_path:
            return Path(self.database_path).expanduser()
        return user_data_dir() / DB_FILE_NAME


@dataclass
class AppConfig:
    """The whole configuration tree."""

    camera: CameraConfig = field(default_factory=CameraConfig)
    recognition: RecognitionConfig = field(default_factory=RecognitionConfig)
    air_mouse: AirMouseConfig = field(default_factory=AirMouseConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    safety: SafetyConfig = field(default_factory=SafetyConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)
    model_path: str = ""
    version: int = 1

    # -- serialisation -------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AppConfig":
        """Build a config from a dict, ignoring unknown keys.

        Unknown keys are dropped rather than raising: a config file written
        by a newer build must not stop an older one from starting.
        """
        config = cls()
        for section in fields(cls):
            if section.name in ("model_path", "version"):
                if section.name in data:
                    setattr(config, section.name, data[section.name])
                continue
            raw = data.get(section.name)
            if not isinstance(raw, dict):
                continue
            target = getattr(config, section.name)
            for key, value in raw.items():
                if hasattr(target, key):
                    setattr(target, key, value)
        config.validate()
        return config

    # -- validation ----------------------------------------------------------
    def validate(self) -> None:
        """Clamp or reject values that would break the runtime."""
        if self.camera.width < 320 or self.camera.height < 240:
            raise ValueError("camera resolution must be at least 320x240")
        if not 1 <= self.camera.fps <= 120:
            raise ValueError("camera fps must be between 1 and 120")
        if not 0.0 < self.recognition.ema_alpha <= 1.0:
            raise ValueError("ema_alpha must be in (0, 1]")
        if not 0.0 < self.recognition.min_presence < 1.0:
            raise ValueError("min_presence must be in (0, 1)")
        if not 0.0 <= self.recognition.ml_weight <= 1.0:
            raise ValueError("ml_weight must be in [0, 1]")
        if self.air_mouse.smoothing not in ("one_euro", "ema", "none"):
            raise ValueError("air_mouse.smoothing must be one_euro, ema or none")
        if not 0.0 <= self.air_mouse.active_region < 0.45:
            raise ValueError("air_mouse.active_region must be in [0, 0.45)")
        if self.air_mouse.dead_zone_px < 0:
            raise ValueError("dead_zone_px must be >= 0")
        if self.air_mouse.drag_delay_s < 0.05:
            raise ValueError("drag_delay_s must be >= 0.05 s")
        if self.air_mouse.scroll_interval_ms < 16:
            raise ValueError("scroll_interval_ms must be >= 16")
        if self.storage.log_level.upper() not in ("DEBUG", "INFO", "WARNING", "ERROR"):
            raise ValueError("log_level must be DEBUG, INFO, WARNING or ERROR")

    # -- persistence ---------------------------------------------------------
    def save(self, path: Path | str | None = None) -> Path:
        target = Path(path) if path else user_data_dir() / CONFIG_FILE_NAME
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_suffix(".tmp")
        temp.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        os.replace(temp, target)  # atomic: a crash mid-write cannot corrupt it
        return target

    @classmethod
    def load(cls, path: Path | str | None = None) -> "AppConfig":
        """Load from disk, falling back to defaults when absent or unreadable."""
        target = Path(path) if path else user_data_dir() / CONFIG_FILE_NAME
        if not target.exists():
            return cls()
        try:
            data = json.loads(target.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return cls()
        if not isinstance(data, dict):
            return cls()
        return cls.from_dict(data)

    def apply_env(self) -> "AppConfig":
        """Apply the documented environment overrides (all optional)."""
        if index := os.environ.get("AIRCONTROL_CAMERA"):
            try:
                self.camera.index = int(index)
            except ValueError:
                pass
        if db := os.environ.get("AIRCONTROL_DB"):
            self.storage.database_path = db
        if level := os.environ.get("AIRCONTROL_LOG_LEVEL"):
            self.storage.log_level = level.upper()
        if model := os.environ.get("AIRCONTROL_MODEL"):
            self.model_path = model
        return self

    def model_file(self) -> Path:
        return Path(self.model_path).expanduser() if self.model_path else default_model_path()


def load_config(path: Path | str | None = None) -> AppConfig:
    """Load the config and apply environment overrides."""
    return AppConfig.load(path).apply_env()
