"""Session tracking and buffered gesture logging.

The camera thread must never block on SQLite, so events are buffered and
flushed in batches: on a timer, on a threshold, and once at shutdown.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass

from aircontrol.data.models import GestureEventRow
from aircontrol.data.repository import Repository, RepositoryError

log = logging.getLogger(__name__)


@dataclass
class SessionStats:
    session_id: int = 0
    started_at: float = 0.0
    gestures: int = 0
    actions: int = 0

    @property
    def duration_s(self) -> float:
        return max(0.0, time.time() - self.started_at) if self.started_at else 0.0


class SessionTracker:
    """Opens a session row, buffers events, and closes cleanly."""

    def __init__(self, repository: Repository | None, *,
                 flush_interval_s: float = 5.0, buffer_limit: int = 50) -> None:
        self.repository = repository
        self.flush_interval_s = flush_interval_s
        self.buffer_limit = buffer_limit
        self.stats = SessionStats()
        self._buffer: list[GestureEventRow] = []
        self._last_flush = 0.0

    # -- lifecycle ----------------------------------------------------------
    def start(self) -> None:
        self.stats = SessionStats(started_at=time.time())
        if self.repository is None:
            return
        try:
            self.stats.session_id = self.repository.start_session(self.stats.started_at)
        except RepositoryError as exc:
            log.warning("could not open a session row: %s", exc)

    def end(self) -> None:
        self.flush()
        if self.repository is None or not self.stats.session_id:
            return
        try:
            self.repository.end_session(
                self.stats.session_id, gestures_fired=self.stats.gestures,
                actions_fired=self.stats.actions)
        except RepositoryError as exc:
            log.warning("could not close the session row: %s", exc)

    # -- recording ----------------------------------------------------------
    def record(self, gesture: str, confidence: float, executed: bool, mode: str,
               now: float) -> None:
        self.stats.gestures += 1
        if executed:
            self.stats.actions += 1
        if self.repository is None:
            return
        self._buffer.append(GestureEventRow(
            gesture=gesture, confidence=confidence, executed=executed, mode=mode,
            occurred_at=now, session_id=self.stats.session_id or None))
        if len(self._buffer) >= self.buffer_limit or \
                (now - self._last_flush) >= self.flush_interval_s:
            self.flush()

    def flush(self) -> None:
        if self.repository is None or not self._buffer:
            self._last_flush = time.time()
            return
        pending, self._buffer = self._buffer, []
        for row in pending:
            try:
                self.repository.log_event(row)
            except RepositoryError as exc:
                log.debug("dropping a gesture log row: %s", exc)
        self._last_flush = time.time()
