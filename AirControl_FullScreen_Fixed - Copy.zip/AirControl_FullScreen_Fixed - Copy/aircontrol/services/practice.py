"""Gesture practice (the Training Arena).

Honest scope: this records what the recogniser saw and whether it matched the
target the user was asked to hold. It is *not* machine learning -- no model is
trained here, and the UI says so. The optional ML classifier that does exist
is trained offline by ``aircontrol.ml.train`` on synthetic data, and is off by
default.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from aircontrol.core.gestures.spec import GESTURE_SPECS, VOCABULARY
from aircontrol.data.models import PracticeAttempt
from aircontrol.data.repository import Repository


@dataclass
class Attempt:
    target: str
    recognized: str | None
    correct: bool
    confidence: float


@dataclass
class PracticeSession:
    """One practice run: a target gesture and the attempts made at it."""

    target: str
    attempts: list[Attempt] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.target not in GESTURE_SPECS:
            raise ValueError(f"unknown practice target {self.target!r}")

    def record(self, recognized: str | None, confidence: float) -> Attempt:
        attempt = Attempt(target=self.target, recognized=recognized,
                          correct=recognized == self.target,
                          confidence=float(confidence))
        self.attempts.append(attempt)
        return attempt

    @property
    def correct(self) -> int:
        return sum(1 for a in self.attempts if a.correct)

    @property
    def incorrect(self) -> int:
        return len(self.attempts) - self.correct

    @property
    def accuracy(self) -> float:
        return self.correct / len(self.attempts) if self.attempts else 0.0

    def reset(self) -> None:
        self.attempts.clear()


class PracticeService:
    """Practice sessions persisted to the database."""

    def __init__(self, repository: Repository) -> None:
        self.repository = repository
        self.session: PracticeSession | None = None

    def start(self, target: str) -> PracticeSession:
        self.session = PracticeSession(target=target)
        return self.session

    def record(self, recognized: str | None, confidence: float,
               persist: bool = True) -> Attempt | None:
        if self.session is None:
            return None
        attempt = self.session.record(recognized, confidence)
        if persist:
            try:
                self.repository.log_practice(PracticeAttempt(
                    target_gesture=attempt.target, recognized=attempt.recognized,
                    correct=attempt.correct, confidence=attempt.confidence,
                    created_at=time.time()))
            except Exception:  # pragma: no cover - persistence must not break practice
                pass
        return attempt

    def stop(self) -> PracticeSession | None:
        finished = self.session
        self.session = None
        return finished

    @staticmethod
    def suggested_target() -> str:
        """The first gesture in spec order -- a stable starting point."""
        return VOCABULARY[0]
