"""Calibration: per-user tuning of sensitivity and cursor range.

Calibration does not retrain anything. It adjusts the thresholds the
recognition engine already uses and the gain the air mouse already applies,
then stores the result as a named profile so a user can keep more than one
(for example "laptop" and "desk monitor").
"""

from __future__ import annotations

import logging

from aircontrol.config import AppConfig
from aircontrol.data.models import CalibrationProfile
from aircontrol.data.repository import Repository, RepositoryError

log = logging.getLogger(__name__)

DEFAULT_PROFILE_NAME = "default"


class CalibrationService:
    """Read, adjust, apply and reset the active calibration profile."""

    def __init__(self, repository: Repository) -> None:
        self.repository = repository

    def current(self) -> CalibrationProfile:
        profile = self.repository.active_profile()
        if profile is None:
            profile = CalibrationProfile(name=DEFAULT_PROFILE_NAME, is_active=True)
            try:
                self.repository.save_profile(profile)
            except RepositoryError:
                log.warning("could not persist the default calibration profile")
        return profile

    def save(self, profile: CalibrationProfile) -> CalibrationProfile:
        self.repository.save_profile(profile)
        return profile

    def adjust(self, *, gesture_sensitivity: float | None = None,
               pinch_sensitivity: float | None = None,
               cursor_speed: float | None = None,
               active_region: float | None = None,
               smoothing: float | None = None,
               name: str | None = None) -> CalibrationProfile:
        """Return a modified copy of the active profile and store it."""
        base = self.current()
        updated = CalibrationProfile(
            name=name or base.name,
            is_active=True,
            gesture_sensitivity=(base.gesture_sensitivity
                                 if gesture_sensitivity is None else gesture_sensitivity),
            pinch_sensitivity=(base.pinch_sensitivity
                               if pinch_sensitivity is None else pinch_sensitivity),
            cursor_speed=(base.cursor_speed
                          if cursor_speed is None else cursor_speed),
            active_region=(base.active_region if active_region is None else active_region),
            smoothing=(base.smoothing if smoothing is None else smoothing),
        )
        return self.save(updated)

    def reset(self) -> CalibrationProfile:
        """Restore the shipped defaults for the active profile."""
        return self.save(CalibrationProfile(name=self.current().name, is_active=True))

    def apply_to(self, config: AppConfig) -> AppConfig:
        """Fold the active profile into an :class:`AppConfig` in place.

        Sensitivity scales the recognition thresholds, so a user who finds
        gestures hard to trigger can raise it above 1.0 and lower it if
        AirControl fires too eagerly.
        """
        profile = self.current()
        config.air_mouse.gain = max(0.2, min(3.0, config.air_mouse.gain *
                                        profile.cursor_speed))
        config.air_mouse.active_region = profile.active_region
        if config.air_mouse.smoothing != "none":
            # Higher smoothing -> lower cutoff -> heavier filtering.
            config.air_mouse.min_cutoff = max(0.3, 2.4 * (1.0 - 0.6 * profile.smoothing))
        config.recognition.pinch_enter_ratio = max(
            0.10, min(0.60, config.recognition.pinch_enter_ratio * profile.pinch_sensitivity))
        config.recognition.pinch_exit_ratio = max(
            config.recognition.pinch_enter_ratio + 0.02,
            min(0.75, config.recognition.pinch_exit_ratio * profile.pinch_sensitivity))
        return config

    def sensitivity_scale(self) -> float:
        """Threshold multiplier the engine should apply for this profile."""
        return max(0.2, min(3.0, self.current().gesture_sensitivity))
