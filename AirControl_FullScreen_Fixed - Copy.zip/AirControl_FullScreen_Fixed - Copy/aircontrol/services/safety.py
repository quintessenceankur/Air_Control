"""Safety: global enable/disable, emergency stop, hotkey registration.

The user must be able to stop gesture control instantly, even when the
AirControl window is not focused. Two global hotkeys provide that:

* toggle gesture control on/off
* emergency stop: disable, release any held button, and stay disabled

The hotkey strings are proposed defaults; the owner's specification requires
an emergency stop but does not name a key combination. They are editable in
Settings and persisted in the database.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Callable

from aircontrol.controllers.manager import ControllerManager

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class HotkeyConfig:
    """Global hotkeys in ``pynput`` notation."""

    toggle: str = "<ctrl>+<alt>+a"
    emergency: str = "<ctrl>+<alt>+x"
    enabled: bool = True

    def validate(self) -> None:
        for name in ("toggle", "emergency"):
            value = getattr(self, name)
            if not value or "<" not in value:
                raise ValueError(f"{name} hotkey must use pynput notation")


class SafetyManager:
    """Owns the enabled flag and the global hotkeys."""

    def __init__(self, manager: ControllerManager, hotkeys: HotkeyConfig | None = None,
                 hotkey_factory: Callable[[dict], object] | None = None) -> None:
        self.manager = manager
        self.hotkeys = hotkeys or HotkeyConfig()
        self._hotkey_factory = hotkey_factory
        self._listener: object | None = None
        self.hotkeys_available = False
        self.emergency_stops = 0

    # -- state --------------------------------------------------------------
    @property
    def enabled(self) -> bool:
        return self.manager.enabled

    def arm(self, *, confirm: bool = False) -> bool:
        """Enable gesture control.

        ``confirm`` is the UI's acknowledgement that the user pressed the
        enable control; it exists so nothing can arm control implicitly.
        """
        if not confirm:
            log.warning("refusing to arm gesture control without confirmation")
            return False
        self.manager.set_enabled(True)
        return True

    def disarm(self) -> None:
        self.manager.set_enabled(False)

    def toggle(self) -> bool:
        return self.manager.toggle()

    def emergency_stop(self) -> None:
        self.emergency_stops += 1
        self.manager.emergency_stop()

    # -- global hotkeys -----------------------------------------------------
    def start_hotkeys(self) -> bool:
        """Register the global hotkeys. Returns False when unavailable."""
        if not self.hotkeys.enabled or self._listener is not None:
            return self.hotkeys_available
        try:
            self.hotkeys.validate()
            factory = self._hotkey_factory or self._default_factory()
            if factory is None:
                return False
            listener = factory({
                self.hotkeys.toggle: self._on_toggle,
                self.hotkeys.emergency: self._on_emergency,
            })
            listener.start()  # type: ignore[attr-defined]
            self._listener = listener
            self.hotkeys_available = True
            log.info("global hotkeys registered (toggle %s, stop %s)",
                     self.hotkeys.toggle, self.hotkeys.emergency)
        except Exception as exc:  # pragma: no cover - platform dependent
            log.warning("global hotkeys unavailable: %s", exc)
            self.hotkeys_available = False
        return self.hotkeys_available

    def stop_hotkeys(self) -> None:
        listener = self._listener
        if listener is not None:
            try:
                listener.stop()  # type: ignore[attr-defined]
            except Exception:  # pragma: no cover - already stopped
                pass
        self._listener = None
        self.hotkeys_available = False

    def _on_toggle(self) -> None:
        enabled = self.toggle()
        log.info("hotkey: gesture control %s", "enabled" if enabled else "disabled")

    def _on_emergency(self) -> None:
        log.warning("hotkey: emergency stop")
        self.emergency_stop()

    @staticmethod
    def _default_factory() -> Callable[[dict], object] | None:
        try:
            from pynput import keyboard  # noqa: WPS433 (lazy, Windows only)
        except Exception:
            return None
        return lambda mapping: keyboard.GlobalHotKeys(mapping)
