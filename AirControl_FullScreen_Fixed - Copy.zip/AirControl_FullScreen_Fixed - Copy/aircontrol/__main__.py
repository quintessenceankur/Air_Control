"""AirControl entry point.

    python -m aircontrol                 # launch the desktop application
    python -m aircontrol --selftest      # verify install, print a report, exit
    python -m aircontrol --version

``--selftest`` deliberately opens no window and touches no camera: it is the
smoke test CI runs against the packaged binary.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from aircontrol import APP_NAME, __version__


def selftest(config=None) -> int:
    """Check the pieces the application needs, without a camera or a window."""
    from aircontrol.config import load_config
    from aircontrol.core.gestures.engine import GestureEngine
    from aircontrol.core.gestures.spec import VOCABULARY
    from aircontrol.ml.synth import GESTURE_POSES, synth_hand

    config = config or load_config()
    problems: list[str] = []
    print(f"{APP_NAME} {__version__} self-test")
    print(f"  python            {sys.version.split()[0]}")
    print(f"  frozen            {getattr(sys, 'frozen', False)}")

    model = config.model_file()
    print(f"  model             {model} ({'found' if model.exists() else 'MISSING'})")
    if not model.exists():
        problems.append("hand landmarker model missing")

    try:
        import numpy
        print(f"  numpy             {numpy.__version__}")
    except Exception as exc:  # pragma: no cover
        problems.append(f"numpy: {exc}")

    try:
        import cv2
        print(f"  opencv            {cv2.__version__}")
    except Exception as exc:  # pragma: no cover
        problems.append(f"opencv: {exc}")

    try:
        import mediapipe
        print(f"  mediapipe         {mediapipe.__version__}")
    except Exception as exc:  # pragma: no cover
        problems.append(f"mediapipe: {exc}")

    try:
        import PySide6
        print(f"  PySide6           {PySide6.__version__}")
    except Exception as exc:  # pragma: no cover
        problems.append(f"PySide6: {exc}")

    engine = GestureEngine()
    fired = []
    for index in range(12):
        fired.extend(event.name for event in engine.update(
            [synth_hand(GESTURE_POSES["OPEN_PALM"])], now=index / 30.0))
    print(f"  engine            {len(VOCABULARY)} gestures, fired {fired}")
    if fired != ["OPEN_PALM"]:
        problems.append(f"engine smoke test produced {fired}")

    try:
        from aircontrol.data.db import open_database
        conn = open_database(config.storage.resolved_database_path())
        conn.close()
        print(f"  database          {config.storage.resolved_database_path()}")
    except Exception as exc:  # pragma: no cover - filesystem dependent
        problems.append(f"database: {exc}")

    try:
        from aircontrol.automation.system import build_executor
        executor = build_executor()
        print(f"  automation        {'available' if executor else 'unavailable on this platform'}")
    except Exception as exc:  # pragma: no cover
        problems.append(f"automation: {exc}")

    if problems:
        print("\nFAILED")
        for problem in problems:
            print(f"  - {problem}")
        return 1
    print("\nOK")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="aircontrol",
                                     description="Gesture control for the desktop")
    parser.add_argument("--version", action="version",
                        version=f"{APP_NAME} {__version__}")
    parser.add_argument("--selftest", action="store_true",
                        help="verify the installation and exit")
    parser.add_argument("--config", type=Path, default=None,
                        help="path to a config.json file")
    parser.add_argument("--camera", type=int, default=None,
                        help="override the camera device index")
    parser.add_argument("--no-hotkeys", action="store_true",
                        help="do not register the global hotkeys")
    parser.add_argument("--debug", action="store_true", help="verbose logging")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    from aircontrol.config import load_config

    config = load_config(args.config)
    if args.camera is not None:
        config.camera.index = args.camera
    if args.debug:
        config.storage.log_level = "DEBUG"
    if args.no_hotkeys:
        config.safety.hotkeys_enabled = False

    if args.selftest:
        return selftest(config)

    from aircontrol.ui.app import run
    return run([sys.argv[0]] if argv is None else [sys.argv[0], *argv], config)


if __name__ == "__main__":  # pragma: no cover - process entry point
    raise SystemExit(main())
