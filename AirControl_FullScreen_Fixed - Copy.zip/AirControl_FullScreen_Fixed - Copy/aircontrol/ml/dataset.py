"""Build a labelled feature dataset from the parametric hand model.

The dataset is **synthetic**. It exists to (a) exercise the training
pipeline end to end and (b) show which classes a classifier can separate at
all. Numbers measured on it are *not* real-world accuracy, and the project
never presents them as such. Real evaluation needs recorded clips -- see
``scripts/evaluate_webcam.py`` and ``docs/TESTING_REPORT.md``.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from aircontrol.core.features import extract_features, feature_vector
from aircontrol.core.gestures.spec import VOCABULARY
from aircontrol.ml.synth import sample_negative, sample_pose, synth_hand

#: Label used for "a hand is present but no gesture is intended".
NEGATIVE_LABEL = "NONE"


@dataclass
class Dataset:
    features: np.ndarray
    labels: list[str]
    classes: list[str]

    def __len__(self) -> int:
        return len(self.labels)

    def split(self, *, validation: float = 0.2, seed: int = 7) -> tuple["Dataset", "Dataset"]:
        """Split into train and validation sets, stratified by class."""
        rng = np.random.default_rng(seed)
        train_idx: list[int] = []
        val_idx: list[int] = []
        labels = np.array(self.labels)
        for label in self.classes:
            indices = np.where(labels == label)[0]
            rng.shuffle(indices)
            cut = int(round(len(indices) * validation))
            val_idx.extend(indices[:cut].tolist())
            train_idx.extend(indices[cut:].tolist())
        return (Dataset(self.features[train_idx], labels[train_idx].tolist(), self.classes),
                Dataset(self.features[val_idx], labels[val_idx].tolist(), self.classes))


def build_dataset(samples_per_class: int = 300, *, seed: int = 0,
                  noise: float = 0.006) -> Dataset:
    """Generate features for every gesture plus a negative class."""
    rng = np.random.default_rng(seed)
    rows: list[np.ndarray] = []
    labels: list[str] = []
    classes = list(VOCABULARY) + [NEGATIVE_LABEL]
    for gesture in VOCABULARY:
        for _ in range(samples_per_class):
            pose = sample_pose(gesture, rng, noise=noise)
            rows.append(feature_vector(extract_features(synth_hand(pose, rng=rng))))
            labels.append(gesture)
    for _ in range(samples_per_class):
        pose = sample_negative(rng, noise=noise)
        rows.append(feature_vector(extract_features(synth_hand(pose, rng=rng))))
        labels.append(NEGATIVE_LABEL)
    return Dataset(np.vstack(rows), labels, classes)
