"""Parametric synthetic hand landmarks.

This is a fixture *source*, not a recognition component: it renders a
plausible 21-point MediaPipe hand from a small pose description (per-finger
curl, thumb abduction, pinch gap, roll, scale, translation) so that the
gesture engine, the test suite and the ML dataset can all be exercised
without a webcam.

Honest limitation: a synthetic hand is a *model* of a hand. Tests built on it
verify that the geometry and the state machine behave as designed; they do
**not** establish real-world accuracy. Only the webcam evaluation workflow in
``scripts/evaluate_webcam.py`` and ``docs/TESTING_REPORT.md`` can speak to
real-world performance, and that requires the owner's camera.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from typing import Iterable, Sequence

import numpy as np

from aircontrol.core.landmarks import HandFrame, hand_from_array

# Local hand frame: x toward the pinky, y toward the fingertips, z toward the
# camera. All distances are in palm widths (index MCP to pinky MCP = 1.0).

PALM_WIDTH_UNIT = 1.0
WRIST_LOCAL = (0.0, 0.0, 0.0)
INDEX_MCP_LOCAL = (-0.50, 0.55, 0.0)
MIDDLE_MCP_LOCAL = (-0.05, 0.58, 0.0)
RING_MCP_LOCAL = (0.20, 0.55, 0.0)
PINKY_MCP_LOCAL = (0.50, 0.48, 0.0)

#: (proximal, middle, distal) phalanx lengths per finger.
FINGER_LENGTHS: dict[str, tuple[float, float, float]] = {
    "index": (0.42, 0.25, 0.20),
    "middle": (0.46, 0.28, 0.21),
    "ring": (0.42, 0.26, 0.20),
    "pinky": (0.33, 0.20, 0.17),
}

#: Maximum bend in degrees at the MCP, PIP and DIP joints.
FINGER_MAX_BEND_DEG = (38.0, 95.0, 72.0)

THUMB_CMC_LOCAL = (-0.45, 0.12, 0.0)
THUMB_LENGTH = 1.02  # CMC to tip, palm widths
THUMB_EXTENDED_DIR = (-0.75, 0.66)  # up and away from the palm
THUMB_TUCKED_TIP = (-0.28, 0.42)    # folded over the palm


def _rotate2(v: Sequence[float], deg: float) -> tuple[float, float]:
    """Rotate a 2-D vector counter-clockwise by ``deg`` degrees."""
    r = math.radians(deg)
    c, s = math.cos(r), math.sin(r)
    return (v[0] * c - v[1] * s, v[0] * s + v[1] * c)


def _unit(v: Sequence[float]) -> tuple[float, float]:
    n = math.hypot(v[0], v[1])
    if n < 1e-9:
        return (0.0, 1.0)
    return (v[0] / n, v[1] / n)


@dataclass(frozen=True)
class HandPose:
    """A parametric hand pose in local hand space.

    ``curl`` is 0 (straight) to 1 (fully folded) per finger. ``thumb_abduction``
    is 0 (tucked over the palm) to 1 (spread away from the index). When
    ``pinch_gap`` is set, the thumb tip is placed exactly that many palm widths
    from the index tip instead of using the abduction model.
    """

    curl: dict[str, float] = field(
        default_factory=lambda: {f: 0.0 for f in ("index", "middle", "ring", "pinky")})
    thumb_abduction: float = 1.0
    pinch_gap: float | None = None
    roll_deg: float = 0.0
    scale: float = 0.28
    center: tuple[float, float] = (0.5, 0.55)
    noise: float = 0.0
    depth: float = 0.0
    handedness: str = "Right"

    def with_curl(self, **kwargs: float) -> "HandPose":
        return replace(self, curl={**self.curl, **kwargs})


def _finger_chain(mcp: Sequence[float], curl: float,
                  lengths: Sequence[float]) -> list[tuple[float, float, float]]:
    """Forward kinematics for one finger, curling toward the palm."""
    points = [(mcp[0], mcp[1], 0.0)]
    direction = (0.0, 1.0)
    cumulative = 0.0
    for length, max_bend in zip(lengths, FINGER_MAX_BEND_DEG):
        cumulative += curl * max_bend
        # Clockwise bend folds the finger down toward the palm (-y).
        direction = _rotate2(direction, -cumulative)
        x, y, _ = points[-1]
        points.append((x + direction[0] * length, y + direction[1] * length,
                       -0.12 * curl))
    return points


def _thumb_chain(index_tip: tuple[float, float, float],
                 abduction: float,
                 pinch_gap: float | None) -> list[tuple[float, float, float]]:
    """Thumb chain (CMC, MCP, IP, TIP), optionally reaching the index tip."""
    cmc = THUMB_CMC_LOCAL
    if pinch_gap is not None:
        # Reach toward the index tip, stopping ``pinch_gap`` palm widths short.
        toward = _unit((index_tip[0] - cmc[0], index_tip[1] - cmc[1]))
        tip = (index_tip[0] - toward[0] * pinch_gap,
               index_tip[1] - toward[1] * pinch_gap)
    else:
        spread_tip = (cmc[0] + THUMB_EXTENDED_DIR[0] * THUMB_LENGTH,
                      cmc[1] + THUMB_EXTENDED_DIR[1] * THUMB_LENGTH)
        t = max(0.0, min(1.0, abduction))
        tip = (THUMB_TUCKED_TIP[0] * (1 - t) + spread_tip[0] * t,
               THUMB_TUCKED_TIP[1] * (1 - t) + spread_tip[1] * t)

    # Two intermediate joints along a bowed path. A tucked thumb (low
    # abduction) is bent hard at the MCP, which is what makes a closed fist
    # distinguishable from an extended thumb; a spread thumb is nearly
    # straight.
    vec = (tip[0] - cmc[0], tip[1] - cmc[1])
    perp = _unit((-vec[1], vec[0]))
    tuck = 1.0 if pinch_gap is not None else max(0.0, min(1.0, abduction))
    bow = (0.10 + 0.45 * (1.0 - tuck)) * math.hypot(*vec)
    mcp = (cmc[0] + vec[0] * 0.34 + perp[0] * bow,
           cmc[1] + vec[1] * 0.34 + perp[1] * bow)
    ip = (cmc[0] + vec[0] * 0.68 + perp[0] * bow * 0.7,
          cmc[1] + vec[1] * 0.68 + perp[1] * bow * 0.7)
    return [(cmc[0], cmc[1], 0.0), (mcp[0], mcp[1], -0.03),
            (ip[0], ip[1], -0.05), (tip[0], tip[1], -0.06)]


def pose_to_local(pose: HandPose) -> np.ndarray:
    """Build the 21x3 array in local hand space (y up)."""
    pts: list[tuple[float, float, float] | None] = [None] * 21
    pts[0] = WRIST_LOCAL
    pts[5] = INDEX_MCP_LOCAL
    pts[9] = MIDDLE_MCP_LOCAL
    pts[13] = RING_MCP_LOCAL
    pts[17] = PINKY_MCP_LOCAL

    chains = {
        "index": (5, INDEX_MCP_LOCAL),
        "middle": (9, MIDDLE_MCP_LOCAL),
        "ring": (13, RING_MCP_LOCAL),
        "pinky": (17, PINKY_MCP_LOCAL),
    }
    for finger, (base_index, mcp) in chains.items():
        chain = _finger_chain(mcp, pose.curl.get(finger, 0.0), FINGER_LENGTHS[finger])
        for offset, point in enumerate(chain):
            pts[base_index + offset] = point

    index_tip = pts[8]
    thumb = _thumb_chain(index_tip, pose.thumb_abduction, pose.pinch_gap)
    for offset, point in enumerate(thumb):
        pts[1 + offset] = point

    array = np.array([p if p is not None else (0.0, 0.0, 0.0) for p in pts], dtype=float)
    return array


def pose_to_image(pose: HandPose, rng: np.random.Generator | None = None) -> np.ndarray:
    """Project a local pose into normalised image coordinates (y down)."""
    local = pose_to_local(pose)
    xy = np.array([_rotate2((p[0], p[1]), pose.roll_deg) for p in local])
    if pose.handedness.lower().startswith("l"):
        # A left hand is the mirror image of a right hand, which is what the
        # detector reports for a mirrored camera frame.
        xy[:, 0] = -xy[:, 0]
    xy = xy * pose.scale
    out = np.zeros((21, 3), dtype=float)
    out[:, 0] = pose.center[0] + xy[:, 0]
    out[:, 1] = pose.center[1] - xy[:, 1]
    # z shares the x/y scale in MediaPipe's convention, so scale it too.
    out[:, 2] = local[:, 2] * pose.scale + pose.depth
    if pose.noise > 0.0:
        gen = rng or np.random.default_rng(0)
        out[:, :2] += gen.normal(0.0, pose.noise, size=(21, 2))
        out[:, 2] += gen.normal(0.0, pose.noise * 0.5, size=21)
    return out


def synth_landmarks(pose: HandPose, rng: np.random.Generator | None = None) -> list[list[float]]:
    return [[float(x), float(y), float(z)] for x, y, z in pose_to_image(pose, rng)]


def synth_hand(pose: HandPose | None = None, *, presence: float = 1.0,
               timestamp: float = 0.0, rng: np.random.Generator | None = None) -> HandFrame:
    """Build a :class:`HandFrame` from a pose (defaults to an open palm)."""
    pose = pose or HandPose()
    return hand_from_array(synth_landmarks(pose, rng), handedness=pose.handedness,
                           presence=presence, timestamp=timestamp)


# --- nominal poses for the vocabulary ---------------------------------------
#: The canonical pose for each gesture, used to build fixtures and to check
#: that every classifier reaches its enter threshold on its own gesture.
GESTURE_POSES: dict[str, HandPose] = {
    "OPEN_PALM": HandPose(
        curl={"index": 0.0, "middle": 0.0, "ring": 0.0, "pinky": 0.0},
        thumb_abduction=1.0),
    "CLOSED_FIST": HandPose(
        curl={"index": 1.0, "middle": 1.0, "ring": 1.0, "pinky": 1.0},
        thumb_abduction=0.15),
    "PINCH": HandPose(
        curl={"index": 0.62, "middle": 0.35, "ring": 0.30, "pinky": 0.30},
        thumb_abduction=0.55, pinch_gap=0.16),
    "TWO_FINGERS": HandPose(
        curl={"index": 0.0, "middle": 0.0, "ring": 1.0, "pinky": 1.0},
        thumb_abduction=0.25),
    "THREE_FINGERS": HandPose(
        curl={"index": 0.0, "middle": 0.0, "ring": 0.0, "pinky": 1.0},
        thumb_abduction=0.35),
    "THUMBS_UP": HandPose(
        curl={"index": 1.0, "middle": 1.0, "ring": 1.0, "pinky": 1.0},
        thumb_abduction=1.0, roll_deg=-49.0),
    "THUMBS_DOWN": HandPose(
        curl={"index": 1.0, "middle": 1.0, "ring": 1.0, "pinky": 1.0},
        thumb_abduction=1.0, roll_deg=131.0),
}

#: Negative poses: a hand that is present but must not trigger anything.
#: These are the false positives the product actually suffers from.
NEGATIVE_POSES: dict[str, HandPose] = {
    # Relaxed hand hanging at the side of the body: fingers partly curled,
    # thumb resting against the index. Not any gesture in the vocabulary.
    "relaxed_at_side": HandPose(
        curl={"index": 0.18, "middle": 0.20, "ring": 0.22, "pinky": 0.25},
        thumb_abduction=0.45, roll_deg=12.0),
    # Palm resting flat on a desk, seen edge-on and foreshortened.
    "palm_on_desk": HandPose(
        curl={"index": 0.14, "middle": 0.16, "ring": 0.18, "pinky": 0.20},
        thumb_abduction=0.70, roll_deg=-8.0, scale=0.20),
    # Hand holding a mug: thumb up-ish but fingers wrapped, not a thumbs-up.
    "holding_mug": HandPose(
        curl={"index": 0.22, "middle": 0.24, "ring": 0.26, "pinky": 0.28},
        thumb_abduction=0.35, roll_deg=-20.0),
    # Half-open hand mid-transition between poses.
    "mid_transition": HandPose(
        curl={"index": 0.22, "middle": 0.20, "ring": 0.24, "pinky": 0.26},
        thumb_abduction=0.60),
    # Typing: fingers extended but splayed and rotated, palm away from camera.
    "typing": HandPose(
        curl={"index": 0.06, "middle": 0.10, "ring": 0.14, "pinky": 0.18},
        thumb_abduction=0.55, roll_deg=25.0, scale=0.24),
}


def sample_pose(gesture: str, rng: np.random.Generator,
                *, noise: float = 0.004) -> HandPose:
    """Randomised variant of a nominal pose, for dataset and stress fixtures.

    The jitter ranges are deliberately wide (roll, scale, position, curl) so
    that a classifier which only works on the exact nominal pose fails here.
    """
    base = GESTURE_POSES[gesture]
    curl = {name: float(np.clip(value + rng.normal(0.0, 0.10), 0.0, 1.0))
            for name, value in base.curl.items()}
    gap = base.pinch_gap
    if gap is not None:
        gap = float(np.clip(gap + rng.normal(0.0, 0.035), 0.02, 0.34))
    return replace(
        base,
        curl=curl,
        thumb_abduction=float(np.clip(base.thumb_abduction + rng.normal(0.0, 0.10), 0.0, 1.0)),
        pinch_gap=gap,
        roll_deg=base.roll_deg + float(rng.normal(0.0, 12.0)),
        scale=float(np.clip(0.28 * rng.uniform(0.75, 1.3), 0.12, 0.45)),
        center=(float(np.clip(0.5 + rng.normal(0.0, 0.08), 0.25, 0.75)),
                float(np.clip(0.55 + rng.normal(0.0, 0.08), 0.25, 0.80))),
        noise=noise,
    )


def sample_negative(rng: np.random.Generator, *, noise: float = 0.004) -> HandPose:
    name = str(rng.choice(list(NEGATIVE_POSES)))
    base = NEGATIVE_POSES[name]
    return replace(
        base,
        curl={k: float(np.clip(v + rng.normal(0.0, 0.08), 0.0, 1.0))
              for k, v in base.curl.items()},
        roll_deg=base.roll_deg + float(rng.normal(0.0, 10.0)),
        scale=float(np.clip(base.scale * rng.uniform(0.8, 1.25), 0.12, 0.45)),
        center=(float(np.clip(0.5 + rng.normal(0.0, 0.1), 0.2, 0.8)),
                float(np.clip(0.55 + rng.normal(0.0, 0.1), 0.2, 0.8))),
        noise=noise,
    )
