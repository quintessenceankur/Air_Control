"""Load and apply the trained gesture classifier.

The artifact is a small JSON file, so the shipped model can be inspected,
diffed and regenerated without any binary tooling. The classifier is optional:
the engine uses it only when ``RecognitionConfig.ml_enabled`` is true, and it
is off by default because the geometric rules are the tested path.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import numpy as np

from aircontrol.config import app_root, resource_path
from aircontrol.core.features import HandFeatures, feature_vector
from aircontrol.core.gestures.spec import VOCABULARY
from aircontrol.ml.dataset import NEGATIVE_LABEL

log = logging.getLogger(__name__)


def default_artifact_path() -> Path:
    """Where the trained artifact ships."""
    candidate = resource_path("gesture_classifier.json")
    if candidate.exists():
        return candidate
    return app_root() / "aircontrol" / "models" / "gesture_classifier.json"


class MLClassifier:
    """Softmax regression inference over :func:`feature_vector`."""

    def __init__(self, payload: dict) -> None:
        version = payload.get("artifact_version")
        if version != 1:
            raise ValueError(f"unsupported artifact version {version!r}")
        self.classes: list[str] = list(payload["classes"])
        self.mean = np.asarray(payload["mean"], dtype=float)
        self.std = np.asarray(payload["std"], dtype=float)
        self.weights = np.asarray(payload["weights"], dtype=float)
        self.bias = np.asarray(payload["bias"], dtype=float)
        self.metrics: dict = dict(payload.get("metrics", {}))
        if self.weights.shape != (len(self.mean), len(self.classes)):
            raise ValueError("artifact shape mismatch")

    @classmethod
    def load(cls, path: Path | str | None = None) -> "MLClassifier | None":
        """Load an artifact, returning ``None`` when it is missing or invalid."""
        target = Path(path) if path else default_artifact_path()
        if not target.exists():
            log.info("no ML artifact at %s; geometric recognition only", target)
            return None
        try:
            payload = json.loads(target.read_text(encoding="utf-8"))
            return cls(payload)
        except (OSError, json.JSONDecodeError, KeyError, ValueError) as exc:
            log.warning("could not load ML artifact %s: %s", target, exc)
            return None

    def predict_proba(self, vector: np.ndarray) -> dict[str, float]:
        """Class probabilities for one raw feature vector."""
        x = (np.asarray(vector, dtype=float) - self.mean) / self.std
        logits = x @ self.weights + self.bias
        logits = logits - logits.max()
        exp = np.exp(logits)
        probabilities = exp / exp.sum()
        return {label: float(p) for label, p in zip(self.classes, probabilities)}

    def gesture_probabilities(self, features: HandFeatures) -> dict[str, float]:
        """Per-gesture probabilities, with the negative class folded out.

        The engine blends these with the geometric scores, so the negative
        class is used to scale everything down rather than being reported as
        a gesture.
        """
        probabilities = self.predict_proba(feature_vector(features))
        negative = probabilities.pop(NEGATIVE_LABEL, 0.0)
        scale = max(0.0, 1.0 - negative)
        return {gesture: probabilities.get(gesture, 0.0) * scale for gesture in VOCABULARY}

    def __call__(self, features: HandFeatures) -> dict[str, float]:
        """Adapter matching the engine's ``ml_scorer`` hook."""
        return self.gesture_probabilities(features)


def load_default() -> MLClassifier | None:
    return MLClassifier.load()
