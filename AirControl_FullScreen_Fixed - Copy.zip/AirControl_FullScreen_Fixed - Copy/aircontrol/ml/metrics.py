"""Classification metrics, computed from a confusion matrix.

Written out rather than pulled from scikit-learn so the evaluation numbers in
the documentation can be reproduced with nothing but numpy.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class ClassReport:
    label: str
    support: int
    precision: float
    recall: float
    f1: float


@dataclass
class EvaluationReport:
    """Everything measured on one labelled set."""

    labels: list[str]
    matrix: np.ndarray            # rows = truth, columns = prediction
    accuracy: float
    macro_f1: float
    weighted_f1: float
    per_class: list[ClassReport]
    unknown_rate: float = 0.0
    false_positive_rate: float = 0.0
    false_negative_rate: float = 0.0
    samples: int = 0

    def as_dict(self) -> dict:
        return {
            "samples": self.samples,
            "accuracy": round(self.accuracy, 4),
            "macro_f1": round(self.macro_f1, 4),
            "weighted_f1": round(self.weighted_f1, 4),
            "unknown_rate": round(self.unknown_rate, 4),
            "false_positive_rate": round(self.false_positive_rate, 4),
            "false_negative_rate": round(self.false_negative_rate, 4),
            "per_class": [
                {"label": c.label, "support": c.support,
                 "precision": round(c.precision, 4),
                 "recall": round(c.recall, 4), "f1": round(c.f1, 4)}
                for c in self.per_class
            ],
            "confusion_matrix": self.matrix.tolist(),
        }

    def format_table(self) -> str:
        lines = [f"{'class':16s}{'support':>8s}{'precision':>11s}{'recall':>9s}{'f1':>8s}"]
        for c in self.per_class:
            lines.append(f"{c.label:16s}{c.support:8d}{c.precision:11.3f}"
                         f"{c.recall:9.3f}{c.f1:8.3f}")
        lines.append("")
        lines.append(f"accuracy {self.accuracy:.3f}  macro-F1 {self.macro_f1:.3f}  "
                     f"samples {self.samples}")
        return "\n".join(lines)


def confusion_matrix(y_true: list[str], y_pred: list[str],
                     labels: list[str] | None = None) -> tuple[np.ndarray, list[str]]:
    """Count predictions per (truth, prediction) pair."""
    if len(y_true) != len(y_pred):
        raise ValueError("y_true and y_pred must have the same length")
    if labels is None:
        labels = sorted(set(y_true) | set(y_pred))
    index = {label: i for i, label in enumerate(labels)}
    matrix = np.zeros((len(labels), len(labels)), dtype=int)
    for truth, prediction in zip(y_true, y_pred):
        if truth not in index:
            raise ValueError(f"label {truth!r} missing from the label list")
        if prediction not in index:
            raise ValueError(f"prediction {prediction!r} missing from the label list")
        matrix[index[truth], index[prediction]] += 1
    return matrix, list(labels)


def evaluate(y_true: list[str], y_pred: list[str],
             labels: list[str] | None = None,
             negative_label: str | None = None) -> EvaluationReport:
    """Compute the full report, including per-class precision/recall/F1."""
    matrix, labels = confusion_matrix(y_true, y_pred, labels)
    samples = int(matrix.sum())
    per_class: list[ClassReport] = []
    for i, label in enumerate(labels):
        tp = int(matrix[i, i])
        support = int(matrix[i, :].sum())
        predicted = int(matrix[:, i].sum())
        precision = tp / predicted if predicted else 0.0
        recall = tp / support if support else 0.0
        f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0
        per_class.append(ClassReport(label, support, precision, recall, f1))

    accuracy = float(np.trace(matrix) / samples) if samples else 0.0
    macro_f1 = float(np.mean([c.f1 for c in per_class])) if per_class else 0.0
    total_support = sum(c.support for c in per_class) or 1
    weighted_f1 = float(sum(c.f1 * c.support for c in per_class) / total_support)

    unknown_rate = 0.0
    fpr = 0.0
    fnr = 0.0
    if "UNKNOWN" in labels:
        unknown_index = labels.index("UNKNOWN")
        unknown_rate = float(matrix[:, unknown_index].sum() / samples) if samples else 0.0
    if negative_label is not None and negative_label in labels:
        neg_index = labels.index(negative_label)
        negatives = int(matrix[neg_index, :].sum())
        false_positives = int(matrix[neg_index, :].sum() - matrix[neg_index, neg_index])
        fpr = false_positives / negatives if negatives else 0.0
        positives = int(samples - negatives)
        false_negatives = int(matrix[:, neg_index].sum() - matrix[neg_index, neg_index])
        fnr = false_negatives / positives if positives else 0.0

    return EvaluationReport(labels=labels, matrix=matrix, accuracy=accuracy,
                            macro_f1=macro_f1, weighted_f1=weighted_f1,
                            per_class=per_class, unknown_rate=unknown_rate,
                            false_positive_rate=fpr, false_negative_rate=fnr,
                            samples=samples)
