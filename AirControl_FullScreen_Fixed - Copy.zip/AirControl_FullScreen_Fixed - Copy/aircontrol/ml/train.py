"""Multinomial logistic regression, trained with numpy only.

Small, transparent and reproducible: eight input features, eight classes, a
few hundred epochs of mini-batch gradient descent. A larger model would not
help here -- the point of the ML path is to show a real, honest hybrid, not to
compete with the geometric rules that actually ship.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from aircontrol.ml.dataset import Dataset

ARTIFACT_VERSION = 1


def softmax(logits: np.ndarray) -> np.ndarray:
    shifted = logits - logits.max(axis=1, keepdims=True)
    exp = np.exp(shifted)
    return exp / exp.sum(axis=1, keepdims=True)


@dataclass
class TrainingResult:
    weights: np.ndarray
    bias: np.ndarray
    mean: np.ndarray
    std: np.ndarray
    classes: list[str]
    train_accuracy: float
    validation_accuracy: float
    validation_loss: float
    epochs: int


def train(dataset: Dataset, *, epochs: int = 240, learning_rate: float = 0.35,
          l2: float = 1e-3, batch_size: int = 64, seed: int = 0,
          verbose: bool = False) -> TrainingResult:
    """Fit the classifier on ``dataset`` and report train/validation accuracy."""
    train_set, val_set = dataset.split(seed=seed)
    classes = dataset.classes
    class_index = {label: i for i, label in enumerate(classes)}

    mean = train_set.features.mean(axis=0)
    std = train_set.features.std(axis=0)
    std[std < 1e-6] = 1.0

    x_train = (train_set.features - mean) / std
    y_train = np.array([class_index[label] for label in train_set.labels])
    x_val = (val_set.features - mean) / std
    y_val = np.array([class_index[label] for label in val_set.labels])

    rng = np.random.default_rng(seed)
    n_features = x_train.shape[1]
    n_classes = len(classes)
    weights = rng.normal(0.0, 0.01, size=(n_features, n_classes))
    bias = np.zeros(n_classes)

    one_hot = np.eye(n_classes)[y_train]
    best_loss = float("inf")
    best = (weights.copy(), bias.copy())
    for epoch in range(epochs):
        order = rng.permutation(len(x_train))
        for start in range(0, len(x_train), batch_size):
            batch = order[start:start + batch_size]
            xb, yb = x_train[batch], one_hot[batch]
            probabilities = softmax(xb @ weights + bias)
            error = (probabilities - yb) / len(batch)
            weights -= learning_rate * (xb.T @ error + l2 * weights)
            bias -= learning_rate * error.sum(axis=0)

        if (epoch + 1) % 10 == 0 or epoch == epochs - 1:
            probabilities = softmax(x_val @ weights + bias)
            loss = float(-np.log(np.clip(probabilities[np.arange(len(y_val)), y_val],
                                         1e-9, 1.0)).mean())
            if loss < best_loss:
                best_loss = loss
                best = (weights.copy(), bias.copy())
            if verbose:
                print(f"epoch {epoch + 1:3d}  val_loss {loss:.4f}")

    weights, bias = best
    train_accuracy = float((softmax(x_train @ weights + bias).argmax(axis=1)
                            == y_train).mean())
    val_predictions = softmax(x_val @ weights + bias).argmax(axis=1)
    validation_accuracy = float((val_predictions == y_val).mean())
    return TrainingResult(weights=weights, bias=bias, mean=mean, std=std,
                          classes=classes, train_accuracy=train_accuracy,
                          validation_accuracy=validation_accuracy,
                          validation_loss=best_loss, epochs=epochs)


def save_artifact(result: TrainingResult, path: Path | str, *,
                  dataset_size: int, extra: dict | None = None) -> Path:
    """Write the trained model as JSON so it can be inspected and diffed."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "artifact_version": ARTIFACT_VERSION,
        "trained_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "classes": result.classes,
        "mean": result.mean.tolist(),
        "std": result.std.tolist(),
        "weights": result.weights.tolist(),
        "bias": result.bias.tolist(),
        "metrics": {
            "train_accuracy": round(result.train_accuracy, 4),
            "validation_accuracy": round(result.validation_accuracy, 4),
            "validation_loss": round(result.validation_loss, 4),
            "epochs": result.epochs,
            "dataset_size": dataset_size,
            "dataset": "synthetic (aircontrol.ml.synth)",
        },
    }
    if extra:
        payload.update(extra)
    target.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return target
