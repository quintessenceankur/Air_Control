"""Train the optional gesture classifier and report honest metrics.

    python scripts/train_ml.py

Writes ``aircontrol/models/gesture_classifier.json`` and prints the train and
validation numbers. The dataset is synthetic (see ``aircontrol.ml.synth``), so
these numbers describe how separable the parametric hand model is -- they are
not real-world accuracy and are never presented as such.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from aircontrol.ml.dataset import build_dataset  # noqa: E402
from aircontrol.ml.metrics import evaluate  # noqa: E402
from aircontrol.ml.train import save_artifact, train  # noqa: E402

ARTIFACT = ROOT / "aircontrol" / "models" / "gesture_classifier.json"
SAMPLES_PER_CLASS = 400


def main() -> int:
    print(f"building synthetic dataset ({SAMPLES_PER_CLASS} samples/class) ...")
    dataset = build_dataset(samples_per_class=SAMPLES_PER_CLASS, seed=11)
    print(f"dataset: {len(dataset)} samples, classes {dataset.classes}")

    print("training softmax regression ...")
    result = train(dataset, epochs=240, seed=11, verbose=False)
    print(f"train accuracy      {result.train_accuracy:.4f}")
    print(f"validation accuracy {result.validation_accuracy:.4f}")
    print(f"validation loss     {result.validation_loss:.4f}")

    path = save_artifact(result, ARTIFACT, dataset_size=len(dataset))
    print(f"artifact written to {path}")

    # Independent held-out set, generated with a different seed.
    held_out = build_dataset(samples_per_class=150, seed=999)
    import numpy as np
    from aircontrol.ml.inference import MLClassifier

    classifier = MLClassifier.load(path)
    assert classifier is not None
    predictions = []
    for vector in held_out.features:
        probabilities = classifier.predict_proba(vector)
        predictions.append(max(probabilities, key=probabilities.get))
    report = evaluate(held_out.labels, predictions, labels=held_out.classes,
                      negative_label="NONE")
    print("\nheld-out (seed 999, synthetic):")
    print(report.format_table())

    summary = ROOT / "docs" / "evaluation_ml.json"
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(json.dumps({
        "dataset": "synthetic",
        "samples_per_class": SAMPLES_PER_CLASS,
        "train_accuracy": round(result.train_accuracy, 4),
        "validation_accuracy": round(result.validation_accuracy, 4),
        "held_out": report.as_dict(),
    }, indent=2), encoding="utf-8")
    print(f"\nwrote {summary}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
