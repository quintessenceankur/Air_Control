"""Generate the landmark replay fixtures under ``tests/fixtures``.

Fixtures are *synthetic*: they come from :mod:`aircontrol.ml.synth`, so they
prove the engine's timing and decision logic, not real-world accuracy. Real
clips are recorded with ``python -m aircontrol.vision.recorder`` and dropped
into the same directory; the replay test picks up every ``*.jsonl`` file and
reads its ``label`` / ``expect`` keys, so a recorded clip needs no code
change.

Usage:
    python scripts/generate_fixtures.py
"""

from __future__ import annotations

import json
import math
import sys
from dataclasses import replace
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from aircontrol.ml.synth import (  # noqa: E402
    GESTURE_POSES,
    NEGATIVE_POSES,
    HandPose,
    sample_pose,
    synth_landmarks,
)

FIXTURES = ROOT / "tests" / "fixtures"
FPS = 30.0
FRAME_DT = 1.0 / FPS


def rows_for_pose(pose: HandPose, frames: int, rng: np.random.Generator,
                  *, start_t: float = 0.0, presence: float = 0.97,
                  drift: float = 0.0) -> list[dict]:
    """Render ``frames`` frames of one pose with per-frame noise."""
    rows: list[dict] = []
    for i in range(frames):
        drift_pose = pose
        if drift:
            # Slow lateral drift, as a hand actually moves while held up.
            dx = drift * math.sin(i / max(frames - 1, 1) * math.pi)
            drift_pose = replace(pose, center=(pose.center[0] + dx, pose.center[1]))
        landmarks = synth_landmarks(drift_pose, rng)
        rows.append({
            "t": round(start_t + i * FRAME_DT, 4),
            "presence": presence,
            "handedness": pose.handedness,
            "landmarks": landmarks,
        })
    return rows


def gap_rows(frames: int, start_t: float, presence: float = 0.0) -> list[dict]:
    """Frames where no hand is present."""
    return [{"t": round(start_t + i * FRAME_DT, 4), "presence": presence,
             "handedness": "Right", "landmarks": []} for i in range(frames)]


def write(name: str, rows: list[dict], *, label: str, expect: list[str]) -> None:
    FIXTURES.mkdir(parents=True, exist_ok=True)
    path = FIXTURES / name
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row) + "\n")
    meta = {"label": label, "expect": expect, "synthetic": True,
            "frames": len(rows), "source": name}
    (FIXTURES / f"{name}.meta.json").write_text(json.dumps(meta, indent=2) + "\n",
                                               encoding="utf-8")
    print(f"{name:34s} {len(rows):4d} frames  expect={expect}")


def main() -> None:
    FIXTURES.mkdir(parents=True, exist_ok=True)
    for old in FIXTURES.glob("*.jsonl"):
        old.unlink()
    for old in FIXTURES.glob("*.meta.json"):
        old.unlink()

    # --- one hold clip per gesture, at a nominal distance -------------------
    for index, gesture in enumerate(GESTURE_POSES):
        rng = np.random.default_rng(1000 + index)
        pose = sample_pose(gesture, rng, noise=0.0)
        rows = rows_for_pose(pose, 60, rng, drift=0.02)
        write(f"hold_{gesture.lower()}.jsonl", rows, label=gesture, expect=[gesture])

    # --- distance robustness: the same gestures far from the camera ---------
    for index, gesture in enumerate(("OPEN_PALM", "PINCH", "TWO_FINGERS")):
        rng = np.random.default_rng(2000 + index)
        pose = replace(sample_pose(gesture, rng, noise=0.0), scale=0.13)
        write(f"far_{gesture.lower()}.jsonl", rows_for_pose(pose, 60, rng),
              label=gesture, expect=[gesture])

    # --- transitions --------------------------------------------------------
    rng = np.random.default_rng(3001)
    palm = sample_pose("OPEN_PALM", rng, noise=0.0)
    pinch = sample_pose("PINCH", rng, noise=0.0)
    rows = (rows_for_pose(palm, 30, rng, start_t=0.0)
            + rows_for_pose(pinch, 40, rng, start_t=30 * FRAME_DT)
            + rows_for_pose(palm, 30, rng, start_t=70 * FRAME_DT))
    write("transition_palm_pinch_palm.jsonl", rows, label="transition",
          expect=["OPEN_PALM", "PINCH", "OPEN_PALM"])

    # --- pinch repeat: hold, release, hold again ----------------------------
    rng = np.random.default_rng(3002)
    # The palm between the two pinches is held only briefly: long enough to
    # release the pinch, too short to dwell into an OPEN_PALM activation.
    rows = (rows_for_pose(pinch, 25, rng, start_t=0.0)
            + rows_for_pose(palm, 4, rng, start_t=25 * FRAME_DT)
            + rows_for_pose(pinch, 25, rng, start_t=29 * FRAME_DT))
    write("pinch_repeat.jsonl", rows, label="PINCH", expect=["PINCH", "PINCH"])

    # --- tracking loss and recovery ----------------------------------------
    rng = np.random.default_rng(3003)
    rows = (rows_for_pose(palm, 25, rng, start_t=0.0)
            + gap_rows(6, 25 * FRAME_DT)
            + rows_for_pose(palm, 30, rng, start_t=31 * FRAME_DT))
    write("hand_loss_recovery.jsonl", rows, label="OPEN_PALM",
          expect=["OPEN_PALM", "OPEN_PALM"])

    # --- negative clips: a hand is present but no gesture is meant ----------
    for index, (name, pose) in enumerate(NEGATIVE_POSES.items()):
        rng = np.random.default_rng(4000 + index)
        write(f"negative_{name}.jsonl", rows_for_pose(pose, 60, rng),
              label="NEGATIVE", expect=[])

    # --- no hand at all -----------------------------------------------------
    write("negative_no_hand.jsonl", gap_rows(40, 0.0), label="NEGATIVE", expect=[])

    # --- low confidence frames are ignored ---------------------------------
    rng = np.random.default_rng(5001)
    write("low_presence_palm.jsonl",
          rows_for_pose(palm, 40, rng, presence=0.20), label="NEGATIVE", expect=[])

    print(f"\nfixtures written to {FIXTURES}")


if __name__ == "__main__":
    main()
