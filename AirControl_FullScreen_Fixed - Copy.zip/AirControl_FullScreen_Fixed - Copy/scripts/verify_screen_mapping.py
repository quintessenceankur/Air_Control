"""Print the cursor mapping AirControl will use on this machine.

Run this on the Windows machine when the cursor cannot reach part of the
desktop -- it prints every coordinate space involved and the exact pixels the
air mouse can command, so the diagnosis needs no guessing:

    python scripts/verify_screen_mapping.py

It moves no cursor and opens no window.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from aircontrol.automation.recorder import RecordingExecutor  # noqa: E402
from aircontrol.automation.screen import (  # noqa: E402
    bounds_from_qt,
    describe_environment,
    query_primary_screen,
    resolve_screen_bounds,
    virtual_desktop_size,
)
from aircontrol.config import AirMouseConfig, load_config  # noqa: E402
from aircontrol.controllers.air_mouse import AirMouseController  # noqa: E402


def main() -> int:
    print("AirControl cursor mapping check")
    print("=" * 60)

    screen = None
    try:  # Qt is optional here: the Win32 numbers are the ones that matter.
        from PySide6.QtGui import QGuiApplication

        app = QGuiApplication.instance() or QGuiApplication([])
        screen = QGuiApplication.primaryScreen()
        del app
    except Exception as exc:  # pragma: no cover - headless machines
        print(f"(Qt unavailable: {exc})")

    for line in describe_environment(screen):
        print(f"  {line}")

    win32 = query_primary_screen()
    qt = bounds_from_qt(screen)
    bounds = resolve_screen_bounds(screen)
    print(f"\n  win32 metrics : {win32.describe() if win32 else 'unavailable'}")
    print(f"  qt physical   : {qt.describe() if qt else 'unavailable'}")
    print(f"  chosen space  : {bounds.describe()}")
    print(f"  addressable   : x 0-{bounds.max_x}, y 0-{bounds.max_y}")

    virtual = virtual_desktop_size()
    if virtual:
        x, y, width, height = virtual
        multi = (width, height) != bounds.as_tuple()
        print(f"  virtual desktop: {width}x{height} at ({x},{y})"
              + ("  <- multi-monitor: primary only" if multi else ""))

    config = load_config().air_mouse
    controller = AirMouseController(RecordingExecutor(), config=config,
                                    screen_bounds=bounds)
    print(f"\n  settings      : {config.describe_for_log()}")
    print("\n  hand position -> commanded pixel")
    for label, (hx, hy) in {
        "top-left": (0.0, 0.0),
        "top-right": (1.0, 0.0),
        "bottom-left": (0.0, 1.0),
        "bottom-right": (1.0, 1.0),
        "centre": (0.5, 0.5),
    }.items():
        px, py = controller.map_to_screen(hx, hy)
        print(f"    {label:13s} ({hx:.1f}, {hy:.1f}) -> ({px:.0f}, {py:.0f})")

    ok = (controller.map_to_screen(0.0, 0.0) == (0.0, 0.0)
          and controller.map_to_screen(1.0, 1.0) == (float(bounds.max_x),
                                                     float(bounds.max_y)))
    print("\n  corners reachable:", "YES" if ok else "NO")
    print("\nIf the addressable range above is smaller than your real desktop, "
          "the display space is being mis-detected: send this output with a bug "
          "report. Press Ctrl+Alt+X to stop gesture control at any time.")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
