"""Record and evaluate real webcam clips.

Two modes:

Record labelled clips (needs a camera; this is the owner's job, not CI's):

    python scripts/evaluate_webcam.py --record --gesture PINCH --clips 10

Evaluate every recorded (non-synthetic) fixture and write a report:

    python scripts/evaluate_webcam.py

The report goes to ``docs/WEB_EVALUATION.md``. Until real clips exist this
script says so plainly instead of inventing numbers -- synthetic fixtures are
ignored on purpose, because the synthetic evaluation already lives in
``docs/EVALUATION.md``.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from aircontrol.core.gestures.engine import GestureEngine, hand_from_row  # noqa: E402
from aircontrol.core.gestures.spec import VOCABULARY  # noqa: E402
from aircontrol.ml.dataset import NEGATIVE_LABEL  # noqa: E402
from aircontrol.ml.metrics import evaluate  # noqa: E402

FIXTURES = ROOT / "tests" / "fixtures"
CLIPS = ROOT / "tests" / "fixtures" / "webcam"
REPORT = ROOT / "docs" / "WEB_EVALUATION.md"
LABELS = list(VOCABULARY) + [NEGATIVE_LABEL]


# --------------------------------------------------------------------------- #
# Recording
# --------------------------------------------------------------------------- #
def record(gesture: str, clips: int, frames: int, seconds_settle: float = 1.5) -> int:
    """Record ``clips`` labelled clips of one gesture with the webcam."""
    from aircontrol.config import load_config
    from aircontrol.vision.capture import CameraCapture, CameraError
    from aircontrol.vision.detector import DetectorError, HandLandmarkerDetector
    from aircontrol.vision.recorder import LandmarkRecorder

    config = load_config()
    CLIPS.mkdir(parents=True, exist_ok=True)
    capture = CameraCapture(config.camera)
    try:
        capture.open()
    except CameraError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    try:
        detector = HandLandmarkerDetector(config.model_file())
    except DetectorError as exc:
        capture.close()
        print(f"error: {exc}", file=sys.stderr)
        return 3

    expect = [] if gesture.upper() == "NEGATIVE" else [gesture]
    print(f"Recording {clips} clips of {gesture}. Hold the pose when prompted.")
    try:
        for clip in range(clips):
            input(f"\nClip {clip + 1}/{clips}: press Enter, then hold {gesture} ...")
            path = CLIPS / f"real_{gesture.lower()}_{clip:02d}.jsonl"
            recorder = LandmarkRecorder(path, label=gesture, expect=expect)
            start = time.monotonic()
            while time.monotonic() - start < frames / 30.0:
                frame = capture.read()
                if frame is None:
                    continue
                hands = detector.detect(frame.image, int(frame.timestamp * 1000))
                recorder.write(hands, frame.timestamp)
            recorder.write_meta()
            print(f"  wrote {recorder.frames} frames to {path.name}")
            time.sleep(seconds_settle)
    except KeyboardInterrupt:
        print("\nstopped early")
    finally:
        detector.close()
        capture.close()
    print("\nNow run without --record to evaluate.")
    return 0


# --------------------------------------------------------------------------- #
# Evaluation
# --------------------------------------------------------------------------- #
def real_fixtures() -> list[Path]:
    """Fixtures that came from a camera (meta says synthetic: false)."""
    found: list[Path] = []
    for path in sorted(FIXTURES.rglob("*.jsonl")):
        meta_path = path.with_suffix(".jsonl.meta.json")
        if not meta_path.exists():
            continue
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            continue
        if meta.get("synthetic") is False:
            found.append(path)
    return found


def replay_clip(path: Path) -> list[str]:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()]
    engine = GestureEngine()
    fired: list[str] = []
    for row in rows:
        hand = hand_from_row(row)
        fired.extend(event.name for event in engine.update([hand] if hand else [],
                                                           now=row.get("t", 0.0)))
    return fired


def evaluate_clips() -> int:
    fixtures = real_fixtures()
    if not fixtures:
        REPORT.write_text(
            "# Real-world recognition evaluation\n\n"
            "**Not yet measured.**\n\n"
            "No webcam clips have been recorded on this machine, so there is no "
            "real-world accuracy figure for AirControl. The numbers in "
            "`docs/EVALUATION.md` are measured on synthetic poses and describe the "
            "geometry, not a human hand.\n\n"
            "To produce this report on Windows:\n\n"
            "```bat\n"
            "python scripts/evaluate_webcam.py --record --gesture PINCH --clips 10\n"
            "python scripts/evaluate_webcam.py --record --gesture OPEN_PALM --clips 10\n"
            "rem ... one run per gesture, plus NEGATIVE for near-miss clips\n"
            "python scripts/evaluate_webcam.py\n"
            "```\n\n"
            "Aim for at least 10 clips per gesture at varied distance and lighting, "
            "plus 5 negative clips (relaxed hand, hand on a desk, hand holding an "
            "object, typing, mid-transition). The script replays each clip through "
            "the real engine and reports clip accuracy, per-gesture precision, recall "
            "and F1, and the false-positive rate on the negative clips.\n",
            encoding="utf-8")
        print("No real webcam fixtures found.")
        print(f"Wrote {REPORT} explaining what to record and how.")
        return 0

    truths: list[str] = []
    predictions: list[str] = []
    for path in fixtures:
        meta = json.loads(path.with_suffix(".jsonl.meta.json").read_text(encoding="utf-8"))
        expected = meta.get("expect") or []
        label = meta.get("label", NEGATIVE_LABEL)
        fired = replay_clip(path)
        truth = expected[0] if expected else NEGATIVE_LABEL
        if not fired:
            prediction = NEGATIVE_LABEL
        elif len(set(fired)) == 1:
            prediction = fired[0]
        else:
            prediction = "MIXED"
        truths.append(truth)
        predictions.append(prediction if prediction in LABELS else NEGATIVE_LABEL)
        print(f"{path.name:44s} expected {truth:14s} got {prediction}")

    report = evaluate(truths, predictions, labels=LABELS, negative_label=NEGATIVE_LABEL)
    print()
    print(report.format_table())
    REPORT.write_text(
        "# Real-world recognition evaluation\n\n"
        f"Generated by `python scripts/evaluate_webcam.py` from {report.samples} "
        "recorded webcam clips.\n\n"
        "```\n" + report.format_table() + "\n```\n\n"
        "## Confusion matrix\n\n"
        "Rows are the expected gesture, columns the prediction, in the order: "
        + ", ".join(report.labels) + ".\n\n```\n" + str(report.matrix) + "\n```\n",
        encoding="utf-8")
    print(f"\nWrote {REPORT}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Record and evaluate webcam clips")
    parser.add_argument("--record", action="store_true", help="record new clips")
    parser.add_argument("--gesture", default="OPEN_PALM",
                        help="gesture to record, or NEGATIVE")
    parser.add_argument("--clips", type=int, default=10)
    parser.add_argument("--frames", type=int, default=90)
    args = parser.parse_args(argv)
    if args.record:
        return record(args.gesture, args.clips, args.frames)
    return evaluate_clips()


if __name__ == "__main__":
    raise SystemExit(main())
