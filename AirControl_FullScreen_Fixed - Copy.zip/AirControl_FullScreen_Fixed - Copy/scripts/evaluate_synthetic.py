"""Evaluate the recognition path on held-out synthetic data.

    python scripts/evaluate_synthetic.py

Produces ``docs/EVALUATION.md`` with measured numbers and a confusion matrix
for the shipped geometric classifier, plus the optional ML classifier for
comparison. Every number printed here is computed in this run.

What these numbers mean -- and do not mean:

* They measure how well the geometric rules separate the poses of the
  parametric hand model in ``aircontrol.ml.synth``, under noise, distance and
  rotation stress.
* They are **not** real-world accuracy. Real accuracy depends on lighting,
  skin tone, camera optics and how each person holds a pose. The owner's
  webcam evaluation (``scripts/evaluate_webcam.py``) is the only honest
  source for that, and it has not been run here because there is no camera.
"""

from __future__ import annotations

import json
import sys
from dataclasses import replace
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from aircontrol.core.features import extract_features  # noqa: E402
from aircontrol.core.gestures.classifiers import score_all  # noqa: E402
from aircontrol.core.gestures.spec import GESTURE_SPECS, VOCABULARY  # noqa: E402
from aircontrol.ml.dataset import NEGATIVE_LABEL, build_dataset  # noqa: E402
from aircontrol.ml.inference import MLClassifier  # noqa: E402
from aircontrol.ml.metrics import EvaluationReport, evaluate  # noqa: E402
from aircontrol.ml.synth import (  # noqa: E402
    GESTURE_POSES,
    NEGATIVE_POSES,
    sample_negative,
    sample_pose,
    synth_hand,
)

LABELS = list(VOCABULARY) + [NEGATIVE_LABEL]


def geometric_predict(pose) -> str:
    """Classify one pose the way the engine does, per frame.

    "No gesture" is a real answer, not a failure: below the enter threshold
    the correct label is NONE, and rejecting a negative pose is a success.
    """
    features = extract_features(synth_hand(pose))
    scores = score_all(features)
    best = max(scores, key=scores.get)
    return best if scores[best] >= GESTURE_SPECS[best].enter else NEGATIVE_LABEL


def ml_predict(classifier: MLClassifier, pose) -> str:
    features = extract_features(synth_hand(pose))
    probabilities = classifier.predict_proba(
        __import__("aircontrol.core.features", fromlist=["feature_vector"])
        .feature_vector(features))
    return max(probabilities, key=probabilities.get)


def build_poses(*, samples: int, seed: int, noise: float = 0.006,
                scale_range: tuple[float, float] | None = None,
                roll_jitter: float = 12.0) -> list[tuple[object, str]]:
    """Held-out poses for every gesture plus negatives."""
    rng = np.random.default_rng(seed)
    items: list[tuple[object, str]] = []
    for gesture in VOCABULARY:
        for _ in range(samples):
            pose = sample_pose(gesture, rng, noise=noise)
            if scale_range is not None:
                pose = replace(pose, scale=float(rng.uniform(*scale_range)))
            if roll_jitter:
                base_roll = GESTURE_POSES[gesture].roll_deg
                pose = replace(pose, roll_deg=base_roll + float(rng.normal(0, roll_jitter)))
            items.append((pose, gesture))
    for name in NEGATIVE_POSES:
        for _ in range(samples):
            pose = sample_negative(rng, noise=noise)
            if scale_range is not None:
                pose = replace(pose, scale=float(rng.uniform(*scale_range)))
            items.append((pose, NEGATIVE_LABEL))
    return items


def clip_prediction(pose, *, frames: int = 30, noise: float, rng) -> str:
    """Run a whole clip through the real engine and report what it fired.

    This is the number that matters for the product: the engine sees a
    sequence, smooths it and requires a dwell, so a frame that is ambiguous
    in isolation can still resolve correctly in context. Exactly one
    activation of one gesture counts as correct; no activation counts as
    NONE.
    """
    from aircontrol.core.gestures.engine import GestureEngine
    from aircontrol.ml.synth import synth_landmarks
    from aircontrol.core.landmarks import hand_from_array

    engine = GestureEngine()
    fired: list[str] = []
    for index in range(frames):
        landmarks = synth_landmarks(pose, rng)
        hand = hand_from_array(landmarks, handedness=pose.handedness, presence=0.97)
        fired.extend(event.name for event in engine.update([hand], now=index / 30.0))
    if not fired:
        return NEGATIVE_LABEL
    return fired[0] if len(set(fired)) == 1 else "MIXED"


def evaluate_clips(condition: str, *, clips_per_class: int = 12, seed: int = 5150,
                   frames: int = 30) -> EvaluationReport:
    rng = np.random.default_rng(seed)
    params = CONDITIONS[condition]
    truths: list[str] = []
    predictions: list[str] = []
    for gesture in VOCABULARY:
        for _ in range(clips_per_class):
            pose = sample_pose(gesture, rng, noise=0.0)
            if params["scale_range"] is not None:
                pose = replace(pose, scale=float(rng.uniform(*params["scale_range"])))
            if params["roll_jitter"]:
                pose = replace(pose, roll_deg=GESTURE_POSES[gesture].roll_deg
                               + float(rng.normal(0, params["roll_jitter"])))
            truths.append(gesture)
            predictions.append(clip_prediction(pose, frames=frames,
                                               noise=params["noise"], rng=rng))
    for _ in range(clips_per_class * len(NEGATIVE_POSES)):
        pose = sample_negative(rng, noise=0.0)
        truths.append(NEGATIVE_LABEL)
        predictions.append(clip_prediction(pose, frames=frames,
                                           noise=params["noise"], rng=rng))
    return evaluate(truths, predictions, labels=LABELS, negative_label=NEGATIVE_LABEL)


CONDITIONS = {
    "nominal": dict(noise=0.006, scale_range=None, roll_jitter=12.0),
    "far_from_camera": dict(noise=0.006, scale_range=(0.11, 0.17), roll_jitter=12.0),
    "high_landmark_noise": dict(noise=0.014, scale_range=None, roll_jitter=12.0),
    "rolled_hand": dict(noise=0.006, scale_range=None, roll_jitter=28.0),
}


def run(condition: str, predictor, samples: int = 120, seed: int = 4242) -> EvaluationReport:
    items = build_poses(samples=samples, seed=seed, **CONDITIONS[condition])
    truths = [label for _pose, label in items]
    predictions = [predictor(pose) for pose, _label in items]
    return evaluate(truths, predictions, labels=LABELS,
                    negative_label=NEGATIVE_LABEL)


def main() -> int:
    classifier = MLClassifier.load()
    results: dict[str, dict] = {}
    geometric_reports: dict[str, EvaluationReport] = {}
    ml_reports: dict[str, EvaluationReport] = {}

    print("Evaluating the geometric classifier (the shipped path)")
    for condition in CONDITIONS:
        report = run(condition, geometric_predict)
        geometric_reports[condition] = report
        print(f"  {condition:20s} accuracy {report.accuracy:.3f}  "
              f"macro-F1 {report.macro_f1:.3f}  unknown {report.unknown_rate:.3f}")
        results[f"geometric/{condition}"] = report.as_dict()

    if classifier is not None:
        print("\nEvaluating the optional ML classifier (same held-out poses)")
        for condition in CONDITIONS:
            report = run(condition, lambda pose, c=classifier: ml_predict(c, pose))
            ml_reports[condition] = report
            print(f"  {condition:20s} accuracy {report.accuracy:.3f}  "
                  f"macro-F1 {report.macro_f1:.3f}")
            results[f"ml/{condition}"] = report.as_dict()

    # Also evaluate the ML classifier on the feature-level dataset for reference.
    feature_dataset = build_dataset(samples_per_class=150, seed=777)
    if classifier is not None:
        predictions = [
            max(classifier.predict_proba(vector), key=classifier.predict_proba(vector).get)
            for vector in feature_dataset.features]
        report = evaluate(feature_dataset.labels, predictions,
                          labels=feature_dataset.classes, negative_label=NEGATIVE_LABEL)
        results["ml/feature_dataset"] = report.as_dict()
        print(f"\nML on feature dataset (seed 777): macro-F1 {report.macro_f1:.3f}")

    print("\nEvaluating the full engine on 30-frame clips (dwell + smoothing)")
    clip_reports: dict[str, EvaluationReport] = {}
    for condition in CONDITIONS:
        report = evaluate_clips(condition)
        clip_reports[condition] = report
        print(f"  {condition:20s} clip accuracy {report.accuracy:.3f}  "
              f"macro-F1 {report.macro_f1:.3f}  false positives {report.false_positive_rate:.3f}")
        results[f"engine_clips/{condition}"] = report.as_dict()

    out_json = ROOT / "docs" / "evaluation_synthetic.json"
    out_json.write_text(json.dumps(results, indent=2), encoding="utf-8")

    lines = [
        "# Recognition evaluation -- synthetic",
        "",
        "Generated by `python scripts/evaluate_synthetic.py`. Every figure below was",
        "computed in that run; nothing is estimated.",
        "",
        "**What this measures.** The parametric hand model in `aircontrol/ml/synth.py`",
        "renders 21 landmarks for each gesture pose, plus the negative poses a real",
        "user produces (relaxed hand, hand on a desk, typing, mid-transition). The",
        "classifiers are run on those frames. This tests the geometry and the",
        "decision bands under controlled stress: distance, landmark noise and hand",
        "rotation.",
        "",
        "**What this does not measure.** Real-world accuracy. The generator is a",
        "model of a hand, not a hand. Lighting, skin tone, camera optics, motion",
        "blur and individual anatomy all move the real feature distribution. The",
        "webcam workflow in `scripts/evaluate_webcam.py` is the only honest source",
        "for those numbers, and it requires the owner's camera.",
        "",
        "## Geometric classifier (shipped path)",
        "",
        "| condition | accuracy | macro-F1 | unknown rate | samples |",
        "| --- | --- | --- | --- | --- |",
    ]
    for condition, report in geometric_reports.items():
        lines.append(f"| {condition} | {report.accuracy:.3f} | {report.macro_f1:.3f} | "
                     f"{report.unknown_rate:.3f} | {report.samples} |")

    lines += ["", "### Full engine on 30-frame clips (dwell + temporal smoothing)", "",
              "The per-frame numbers above are the conservative case: each frame is judged",
              "alone. The engine also smooths landmarks and requires a five-frame dwell, so",
              "a clip is the unit the product actually acts on. Each clip is 30 frames at",
              "30 fps; a clip counts as correct when the engine fires exactly one gesture,",
              "and negatives count as correct when nothing fires.", "",
              "| condition | clip accuracy | macro-F1 | false positives | clips |",
              "| --- | --- | --- | --- | --- |"]
    for condition, report in clip_reports.items():
        lines.append(f"| {condition} | {report.accuracy:.3f} | {report.macro_f1:.3f} | "
                     f"{report.false_positive_rate:.3f} | {report.samples} |")
    lines += ["", "### Per-class detail (nominal condition)", "",
              "```", geometric_reports["nominal"].format_table(), "```", "",
              "### Confusion matrix (nominal)", "",
              "Rows are the true pose, columns the prediction, in the order: "
              + ", ".join(geometric_reports["nominal"].labels) + ".", "",
              "```", str(geometric_reports["nominal"].matrix), "```", ""]

    if ml_reports:
        lines += ["## Optional ML classifier (softmax regression, synthetic training data)", "",
                  "| condition | accuracy | macro-F1 |", "| --- | --- | --- |"]
        for condition, report in ml_reports.items():
            lines.append(f"| {condition} | {report.accuracy:.3f} | {report.macro_f1:.3f} |")
        lines += ["",
                  "Trained on 3200 synthetic samples by `scripts/train_ml.py`; artifact at",
                  "`aircontrol/models/gesture_classifier.json`. It is **off by default**",
                  "(`RecognitionConfig.ml_enabled = false`). Its high score here is expected",
                  "and not evidence of real-world quality: the training data and this test",
                  "data come from the same parametric hand model, so the classifier has",
                  "learned that model's geometry. It is shipped as an inspectable example of",
                  "the hybrid path, not as the recognition engine.", ""]

    lines += ["## Weakest classes", ""]
    nominal = geometric_reports["nominal"]
    weakest = sorted(nominal.per_class, key=lambda c: c.f1)[:3]
    for report in weakest:
        lines.append(f"* `{report.label}` -- F1 {report.f1:.3f} "
                     f"(precision {report.precision:.3f}, recall {report.recall:.3f}, "
                     f"support {report.support})")
    lines += ["", "The weakest classes in the stressed conditions are the same ones: see",
              "`docs/evaluation_synthetic.json` for the full per-condition breakdown.", ""]

    out_md = ROOT / "docs" / "EVALUATION.md"
    out_md.write_text("\n".join(lines), encoding="utf-8")
    print(f"\nwrote {out_md} and {out_json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
