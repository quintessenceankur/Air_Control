# AirControl

Gesture control for the Windows desktop. A webcam watches your hand; seven
hand poses drive the cursor, media playback and presentation slides.

Python 3.11 · PySide6 · MediaPipe Tasks · OpenCV · SQLite · PyInstaller

---

## Status of this build

This repository is a complete, tested, runnable application on Linux (headless
verification) and is packaged for Windows. Three things could not be verified
in the environment it was built in, and they are stated here rather than
implied away:

| Item | State |
| --- | --- |
| Recognition engine, controllers, database, UI, tests | Implemented, 455 automated tests passing |
| Real-world gesture accuracy on a human hand | **Not measured** — needs the owner's webcam; workflow provided |
| Windows `.exe` and installer | **Not built here** — CI or the owner's Windows machine produces them |
| Live camera capture, key injection, camera permission prompt | **Not exercised here** — no camera or desktop in the build environment |

Recognition accuracy is measured on synthetic poses (macro-F1 0.98 at clip
level); see [docs/EVALUATION.md](docs/EVALUATION.md) for exactly what that does
and does not prove.

---

## Quick start

### On Windows, from a release

1. Run `AirControl-Setup-1.0.1.exe` and finish the wizard (no admin rights needed).
2. Start **AirControl** from the Start menu.
3. Allow camera access when Windows asks (Settings → Privacy → Camera).
4. Open **Air Mouse**, press **Activate Air Mouse**, then **Enable control**.
5. Hold two fingers up and move your hand — the cursor follows your index fingertip.

Press **Ctrl+Alt+X** at any time to stop gesture control immediately.

### From source (development)

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows
pip install -e ".[dev]"
python -m aircontrol
python -m aircontrol --selftest  # verifies model, database, engine, backend
```

---

## The gesture vocabulary

Seven gestures, fixed by the product specification. What each one *does* is
configurable in the app.

| Gesture | Hand shape | Default in Air Mouse | Default in Media | Default in Presentation |
| --- | --- | --- | --- | --- |
| `OPEN_PALM` | all five fingers extended | scroll | play / pause | start presentation |
| `CLOSED_FIST` | all five fingers curled | pause the mouse | mute | exit presentation |
| `PINCH` | thumb tip touches index tip | click / drag | unbound | unbound |
| `TWO_FINGERS` | index + middle extended | pointer | next track | next slide |
| `THREE_FINGERS` | index + middle + ring extended | right click | previous track | previous slide |
| `THUMBS_UP` | thumb up, other fingers curled | unbound | volume up | unbound |
| `THUMBS_DOWN` | thumb down, other fingers curled | unbound | volume down | unbound |

Every threshold, binding and hotkey lives in
`aircontrol/core/gestures/spec.py` and `aircontrol/core/actions.py`, and every
value the rebuild chose (rather than inheriting from the specification) is
listed in `spec.PENDING_APPROVAL` for the owner to confirm.

---

## How recognition works

Five stages, each independently testable, none of which needs a camera:

1. **Normalise** — landmarks are translated to the wrist, divided by palm width
   and mirrored for left hands, so distance, camera and handedness drop out.
2. **Extract** — per-finger extension scores from joint angles *and* length
   ratios, normalised pinch distance, palm roll, fingertip position, motion.
3. **Score** — one pure function per gesture returns 0..1, combining evidence
   with a geometric mean so a single imperfect finger degrades the score
   instead of collapsing it.
4. **Decide** — the engine smooths landmarks, applies an enter/exit hysteresis
   band, requires a five-frame dwell, fires exactly one event per activation,
   then enforces a 600 ms cooldown.
5. **Act** — the active controller turns the event into a cursor move, a media
   key or a slide key, behind an interface the tests replace with a recorder.

Why it does not misfire: a resting hand scores below every enter threshold
(there are negative fixtures that assert this), a held gesture fires once
rather than thirty times a second, a one-frame tracking dropout cannot re-fire
an action, and nothing runs at all until the user enables control.

---

## Screens

Dashboard · Live Gesture Studio · Air Mouse · Media Controls · Presentation ·
Gesture Training Arena · Custom Gesture Studio · Analytics · Settings.

The UI owns no recognition logic. One `QThread` runs capture → detect →
engine → controllers and emits signals; the widgets only render.

---

## Project layout

```
aircontrol/
  __main__.py        CLI entry point (--selftest, --version, --debug)
  config.py          dataclass config, JSON persistence, frozen-aware paths
  core/              PURE: landmarks, features, gestures, actions, smoothing
  vision/            capture, MediaPipe detector, fixture recorder
  automation/        executor protocol, pynput backends, recording double
  controllers/       air mouse, media, presentation, manager (safety gates)
  data/              SQLite schema, repository, analytics
  services/          calibration, practice, session tracking, safety/hotkeys
  ml/                synthetic hand model, dataset, training, inference, metrics
  ui/                theme, components, overlay, camera thread, 9 pages
  resources/         hand_landmarker.task, icons
  models/            trained gesture_classifier.json
tests/               unit, integration, performance, fixtures
packaging/           PyInstaller spec, Inno Setup script, version metadata
scripts/             fixture generation, ML training, evaluation
docs/                audit, architecture, installation, guide, reports
```

`core/` imports nothing from `cv2`, `PySide6` or the OS. That boundary is what
makes the recognition path replayable from a JSONL file.

---

## Testing

```bash
pytest -q                      # 456 tests: unit, integration, UI (offscreen)
pytest -m performance -s -q    # throughput measurements
pytest -m camera -q            # only with a real webcam
pytest --cov=aircontrol.core --cov=aircontrol.data
```

Last full run in the build environment: **456 passed, 3 deselected**, coverage
88.3% overall and 94.2% on `core/` + `data/`. Full detail, including what could
not run, is in [docs/TESTING_REPORT.md](docs/TESTING_REPORT.md).

---

## Building the Windows application

On Windows, from the repository root:

```bat
pip install -e ".[dev]" pyinstaller
pytest -q
pyinstaller packaging\aircontrol.spec --noconfirm
dist\AirControl\AirControl.exe --selftest
iscc packaging\installer.iss
```

Artefacts: `dist\AirControl\` (one-dir build) and
`dist\AirControl-Setup-1.0.1.exe`. `.github/workflows/build-windows.yml` runs
the same steps on a Windows runner and uploads both.

---

## Safety and privacy

- Control starts **disabled**; enabling it is an explicit action.
- **Ctrl+Alt+X** emergency stop works globally; **Ctrl+Alt+A** toggles control.
- Every action is debounced, cooled down and mode-gated.
- No video is recorded, no frames or landmarks are stored, and the application
  makes no network requests. Usage counters and settings live in
  `%APPDATA%\AirControl`.

---

## Documentation

- [docs/PROJECT_AUDIT.md](docs/PROJECT_AUDIT.md) — what the original prototype did, and its faults
- [docs/BUGFIX_FULLSCREEN_MAPPING.md](docs/BUGFIX_FULLSCREEN_MAPPING.md) — why the cursor could not reach the taskbar, and the fix
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) — layers, data flow, threading, decisions
- [docs/INSTALLATION.md](docs/INSTALLATION.md) — install, permissions, packaging
- [docs/USER_GUIDE.md](docs/USER_GUIDE.md) — every screen and gesture
- [docs/TESTING_REPORT.md](docs/TESTING_REPORT.md) — commands, results, limitations
- [docs/EVALUATION.md](docs/EVALUATION.md) — measured recognition results
- [docs/WEB_EVALUATION.md](docs/WEB_EVALUATION.md) — the real-world evaluation workflow
- [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) — when something does not work
- [docs/DEVELOPMENT_ROADMAP.md](docs/DEVELOPMENT_ROADMAP.md) — what comes next

---

## Known limitations

- Recognition thresholds are tuned against a synthetic hand model; real hands
  will need one calibration pass (Settings → Recognition, or the Training Arena).
- `THUMBS_UP` and `THUMBS_DOWN` are the weakest classes under hand roll, because
  the thumb direction is measured in image space.
- Gestures are recognised for one hand at a time (the nearer hand); no gesture
  in the current vocabulary is two-handed.
- The ML classifier is trained on synthetic data only and is **off by default**;
  it is a demonstrated extension point, not the recognition engine.
- Windows-only for desktop automation: on other platforms the app runs, the UI
  works and every action is suppressed.
