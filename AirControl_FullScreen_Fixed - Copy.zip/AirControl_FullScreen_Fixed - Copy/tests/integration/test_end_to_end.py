"""End-to-end: recorded landmarks in, recorded OS calls out.

These are the tests that prove the wiring works without a camera and without
touching the real desktop: the executor is the recording double throughout.
"""

from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path

import numpy as np
import pytest

from aircontrol.automation.recorder import RecordingExecutor
from aircontrol.controllers.manager import ControllerManager
from aircontrol.core.actions import DEFAULT_MEDIA_BINDINGS, DEFAULT_PRESENTATION_BINDINGS, ControlMode
from aircontrol.core.gestures.engine import GestureEngine, hand_from_row
from aircontrol.core.gestures.events import GestureEvent
from aircontrol.data.repository import Repository
from aircontrol.ml.synth import GESTURE_POSES, synth_landmarks
from aircontrol.services.session import SessionTracker

FIXTURES = Path(__file__).resolve().parents[1] / "fixtures"


def rows(name: str) -> list[dict]:
    return [json.loads(line) for line in
            (FIXTURES / name).read_text(encoding="utf-8").splitlines() if line.strip()]


def run_clip(name: str, mode: ControlMode, *, enabled: bool = True,
             stop_after: float | None = None):
    """Replay a fixture through engine + manager, returning the executor."""
    executor = RecordingExecutor()
    manager = ControllerManager(executor, mode=mode, enabled=enabled,
                                screen_size=(1000, 600))
    engine = GestureEngine()
    for row in rows(name):
        hand = hand_from_row(row)
        events = engine.update([hand] if hand else [], now=row["t"])
        manager.handle(events, engine.state, row["t"])
        if stop_after is not None and row["t"] > stop_after:
            manager.emergency_stop()
    return executor, manager


def test_media_mode_turns_a_thumb_into_volume_up():
    executor, manager = run_clip("hold_thumbs_up.jsonl", ControlMode.MEDIA)
    keys = [call.args[0] for call in executor.of("media_key")]
    assert keys == ["volume_up"]
    assert manager.actions_fired == 1


def test_presentation_mode_turns_two_fingers_into_next_slide():
    executor, _manager = run_clip("hold_two_fingers.jsonl", ControlMode.PRESENTATION)
    assert [call.args[0] for call in executor.of("send_key")] == ["next_slide"]


def test_palm_pinch_palm_sequence_produces_one_action_per_palm():
    """The engine fires three gestures; only the two palms are bound."""
    executor, manager = run_clip("transition_palm_pinch_palm.jsonl", ControlMode.MEDIA)
    keys = [call.args[0] for call in executor.of("media_key")]
    assert keys == ["play_pause", "play_pause"]
    assert manager.actions_fired == 2
    assert DEFAULT_MEDIA_BINDINGS["PINCH"].kind == "none"


def test_unbound_gesture_produces_no_os_call():
    executor, _manager = run_clip("transition_palm_pinch_palm.jsonl", ControlMode.MEDIA)
    assert len(executor.of("media_key")) == 2, "PINCH is unbound: two palms only"


def test_negative_clips_produce_no_actions():
    for name in ("negative_typing.jsonl", "negative_relaxed_at_side.jsonl",
                 "negative_mid_transition.jsonl", "negative_no_hand.jsonl"):
        executor, manager = run_clip(name, ControlMode.MEDIA)
        assert len(executor) == 0, f"{name} produced {executor.calls}"
        assert manager.actions_fired == 0


def test_disabled_control_produces_no_actions():
    executor, _manager = run_clip("hold_thumbs_up.jsonl", ControlMode.MEDIA, enabled=False)
    assert len(executor) == 0


def test_emergency_stop_stops_actions_mid_clip():
    executor, manager = run_clip("transition_palm_pinch_palm.jsonl",
                                 ControlMode.MEDIA, stop_after=0.5)
    assert manager.enabled is False
    assert len(executor) <= 1


def test_air_mouse_moves_the_cursor_across_a_clip():
    executor = RecordingExecutor()
    manager = ControllerManager(executor, mode=ControlMode.AIR_MOUSE, enabled=True,
                                screen_size=(1000, 600))
    manager.air_mouse.config.smoothing = "none"
    manager.air_mouse.config.dead_zone_px = 0
    engine = GestureEngine()
    pose = replace(GESTURE_POSES["TWO_FINGERS"], noise=0.0)
    for index in range(40):
        # Drift the hand to the right while holding the pointer pose.
        moved = replace(pose, center=(0.30 + index * 0.01, 0.5))
        hand = __import__("aircontrol.ml.synth", fromlist=["synth_hand"]).synth_hand(
            moved, timestamp=index / 30.0)
        events = engine.update([hand], now=index / 30.0)
        manager.handle(events, engine.state, index / 30.0)
    moves = executor.of("move_mouse_to")
    assert len(moves) > 5
    xs = [call.args[0] for call in moves]
    assert xs == sorted(xs), "the cursor must follow the hand to the right"


def test_session_tracker_records_the_clip(tmp_path: Path):
    repository = Repository.open(str(tmp_path / "e2e.db"))
    tracker = SessionTracker(repository, buffer_limit=1)
    tracker.start()
    executor = RecordingExecutor()
    manager = ControllerManager(executor, mode=ControlMode.MEDIA, enabled=True,
                                screen_size=(1000, 600))
    engine = GestureEngine()
    for row in rows("hold_thumbs_up.jsonl"):
        hand = hand_from_row(row)
        events = engine.update([hand] if hand else [], now=row["t"])
        acted = manager.handle(events, engine.state, row["t"])
        for event in events:
            tracker.record(event.name, event.confidence, event in acted, "media", row["t"])
    tracker.end()
    stored = repository.recent_events()
    assert stored and stored[0].gesture == "THUMBS_UP"
    assert stored[0].executed is True
    assert repository.sessions()[0].ended_at is not None
    repository.close()


def test_presentation_bindings_cover_every_target():
    assert {action.target for action in DEFAULT_PRESENTATION_BINDINGS.values()
            if action.kind != "none"} == {"next_slide", "previous_slide",
                                          "start_presentation", "exit_presentation"}
