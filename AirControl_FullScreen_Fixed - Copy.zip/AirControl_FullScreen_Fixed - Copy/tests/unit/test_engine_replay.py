"""Replay every fixture through the engine and assert the exact event sequence.

This is the test that protects the product. Each fixture declares its expected
event sequence in a sibling ``.meta.json``; negative fixtures expect *nothing*,
and those assertions must never be relaxed to make a change pass.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from aircontrol.core.gestures.engine import GestureEngine, replay
from aircontrol.core.gestures.spec import EngineConfig

FIXTURES = Path(__file__).resolve().parents[1] / "fixtures"


def fixture_files() -> list[Path]:
    return sorted(FIXTURES.glob("*.jsonl"))


def load_meta(path: Path) -> dict:
    meta_path = path.with_suffix(".jsonl.meta.json")
    if not meta_path.exists():
        return {"expect": [], "label": "unknown"}
    return json.loads(meta_path.read_text(encoding="utf-8"))


def load_rows(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()]


def test_fixtures_exist():
    assert fixture_files(), "no fixtures found; run scripts/generate_fixtures.py"


@pytest.mark.parametrize("path", fixture_files(), ids=lambda p: p.stem)
def test_fixture_produces_the_expected_events(path: Path):
    meta = load_meta(path)
    expected = meta["expect"]
    rows = load_rows(path)
    events = replay(rows, GestureEngine())
    assert [e.name for e in events] == expected, (
        f"{path.name}: expected {expected}, got {[e.name for e in events]}")


@pytest.mark.parametrize("path", fixture_files(), ids=lambda p: p.stem)
def test_replay_is_deterministic(path: Path):
    rows = load_rows(path)
    first = [e.name for e in replay(rows, GestureEngine())]
    second = [e.name for e in replay(rows, GestureEngine())]
    assert first == second


@pytest.mark.parametrize("path", fixture_files(), ids=lambda p: p.stem)
def test_smoothing_does_not_change_decisions(path: Path):
    """EMA is a jitter filter, not a decision maker: on/off must agree."""
    rows = load_rows(path)
    smoothed = [e.name for e in replay(rows, GestureEngine())]
    raw = [e.name for e in replay(rows, GestureEngine(EngineConfig(ema_alpha=1.0)))]
    assert smoothed == raw


@pytest.mark.parametrize("path", fixture_files(), ids=lambda p: p.stem)
def test_event_timestamps_are_monotonic(path: Path):
    events = replay(load_rows(path), GestureEngine())
    stamps = [e.timestamp for e in events]
    assert stamps == sorted(stamps)


@pytest.mark.parametrize("path", fixture_files(), ids=lambda p: p.stem)
def test_fired_events_meet_the_enter_threshold(path: Path):
    from aircontrol.core.gestures.spec import GESTURE_SPECS
    for event in replay(load_rows(path), GestureEngine()):
        assert event.confidence >= GESTURE_SPECS[event.name].enter - 1e-9


@pytest.mark.parametrize("path", fixture_files(), ids=lambda p: p.stem)
def test_no_event_fires_twice_without_a_release(path: Path):
    """Two consecutive events of the same gesture must be >= cooldown apart."""
    from aircontrol.core.gestures.spec import GESTURE_SPECS
    events = replay(load_rows(path), GestureEngine())
    for previous, current in zip(events, events[1:]):
        if previous.name == current.name:
            gap_ms = (current.timestamp - previous.timestamp) * 1000.0
            assert gap_ms >= GESTURE_SPECS[current.name].cooldown_ms - 1e-6
