"""Feature extraction: scale/rotation invariance, bands, motion."""

from __future__ import annotations

import math

import numpy as np
import pytest

from aircontrol.core.features import (
    EXTENDED_SCORE,
    FEATURE_VECTOR_ORDER,
    MotionTracker,
    extract_features,
    feature_vector,
    finger_spread,
    pinch_ratio,
)
from aircontrol.core.landmarks import Point, to_canonical
from aircontrol.ml.synth import GESTURE_POSES, HandPose, synth_hand


def features(pose: HandPose):
    return extract_features(synth_hand(pose))


def test_open_palm_extends_every_finger():
    f = features(GESTURE_POSES["OPEN_PALM"])
    assert all(v >= 0.75 for v in f.extension.values()), f.extension
    assert f.extended_count == 5


def test_closed_fist_curls_every_finger():
    f = features(GESTURE_POSES["CLOSED_FIST"])
    assert all(v <= 0.25 for v in f.extension.values()), f.extension
    assert f.extended_count == 0


def test_extension_scores_are_scale_invariant():
    near = features(HandPose(scale=0.40))
    far = features(HandPose(scale=0.14))
    for finger in near.extension:
        assert near.extension[finger] == pytest.approx(
            far.extension[finger], abs=1e-6), finger


def test_pinch_ratio_is_scale_invariant():
    near = features(HandPose(pinch_gap=0.2, scale=0.35))
    far = features(HandPose(pinch_gap=0.2, scale=0.15))
    assert near.pinch_ratio == pytest.approx(far.pinch_ratio, abs=1e-6)


def test_pinch_ratio_is_rotation_invariant():
    upright = features(HandPose(pinch_gap=0.2, curl={"index": 0.6, "middle": 0.3,
                                                     "ring": 0.3, "pinky": 0.3}))
    tilted = features(HandPose(pinch_gap=0.2, curl={"index": 0.6, "middle": 0.3,
                                                    "ring": 0.3, "pinky": 0.3},
                               roll_deg=45.0))
    assert upright.pinch_ratio == pytest.approx(tilted.pinch_ratio, abs=0.02)


def test_pinch_ratio_grows_with_gap():
    tight = features(HandPose(pinch_gap=0.05, curl={"index": 0.6, "middle": 0.3,
                                                    "ring": 0.3, "pinky": 0.3}))
    loose = features(HandPose(pinch_gap=0.60, curl={"index": 0.6, "middle": 0.3,
                                                    "ring": 0.3, "pinky": 0.3}))
    assert tight.pinch_ratio < 0.36 < loose.pinch_ratio


def test_finger_extension_is_monotonic_in_curl():
    scores = [features(HandPose(curl={k: c for k in ("index", "middle", "ring", "pinky")}))
              .extension["index"] for c in (0.0, 0.1, 0.2, 0.4, 0.8)]
    assert scores == sorted(scores, reverse=True)
    assert scores[0] > 0.9 and scores[-1] < 0.1


def test_extended_threshold_sits_inside_the_band():
    assert 0.0 < EXTENDED_SCORE < 1.0


def test_spread_grows_with_an_open_hand():
    open_hand = features(GESTURE_POSES["OPEN_PALM"])
    fist = features(GESTURE_POSES["CLOSED_FIST"])
    assert open_hand.spread > fist.spread


def test_palm_roll_reports_orientation():
    upright = features(HandPose())
    rotated = features(HandPose(roll_deg=90.0))
    assert abs(upright.palm_roll_deg) < 10.0
    assert abs(abs(rotated.palm_roll_deg) - 90.0) < 12.0


def test_palm_facing_is_a_known_label():
    assert features(HandPose()).palm_facing in {"camera", "away", "edge"}


def test_pointer_tracks_the_index_tip():
    hand = synth_hand(HandPose(center=(0.4, 0.45)))
    f = extract_features(hand)
    assert f.pointer[0] == pytest.approx(hand.point(8).x)
    assert f.pointer[1] == pytest.approx(hand.point(8).y)


def test_pointer_moves_with_the_hand():
    left = extract_features(synth_hand(HandPose(center=(0.35, 0.5))))
    right = extract_features(synth_hand(HandPose(center=(0.65, 0.5))))
    assert right.pointer[0] - left.pointer[0] == pytest.approx(0.30, abs=0.01)


def test_feature_vector_layout_is_stable():
    f = features(GESTURE_POSES["PINCH"])
    vec = feature_vector(f)
    assert vec.shape == (len(FEATURE_VECTOR_ORDER),)
    assert vec[0] == pytest.approx(f.extension["thumb"])
    assert vec[5] == pytest.approx(f.pinch_ratio)
    assert FEATURE_VECTOR_ORDER[0] == "thumb"  # order must not change


def test_handedness_is_carried_through():
    assert features(HandPose(handedness="Left")).handedness == "Left"


def test_motion_tracker_reports_direction_and_scale():
    tracker = MotionTracker(window=5)
    tracker.update(Point(0.30, 0.50), 0.28, now=0.0)
    vx, vy = tracker.update(Point(0.50, 0.50), 0.28, now=0.5)
    assert vx > 0.0 and abs(vy) < 1e-6


def test_motion_tracker_needs_two_samples():
    tracker = MotionTracker()
    assert tracker.update(Point(0.5, 0.5), 0.3, now=0.0) == (0.0, 0.0)


def test_motion_tracker_reset_clears_history():
    tracker = MotionTracker()
    tracker.update(Point(0.3, 0.5), 0.3, now=0.0)
    tracker.update(Point(0.4, 0.5), 0.3, now=0.1)
    tracker.reset()
    assert tracker.update(Point(0.5, 0.5), 0.3, now=0.2) == (0.0, 0.0)


def test_motion_tracker_rejects_short_window():
    with pytest.raises(ValueError):
        MotionTracker(window=1)


def test_finger_spread_of_canonical_open_hand():
    c = to_canonical(synth_hand(GESTURE_POSES["OPEN_PALM"]))
    assert 0.3 < finger_spread(c) < 2.5


def test_pinch_ratio_of_canonical_is_finite():
    c = to_canonical(synth_hand())
    assert math.isfinite(pinch_ratio(c))
