"""Camera lifecycle and failure handling, with a fake device."""

from __future__ import annotations

import numpy as np
import pytest

from aircontrol.config import CameraConfig
from aircontrol.vision.capture import CameraCapture, CameraError


class FakeCapture:
    """Minimal stand-in for ``cv2.VideoCapture``."""

    def __init__(self, *, opened: bool = True, frames: int = 3,
                 fail_after: int | None = None) -> None:
        self._opened = opened
        self._frames = frames
        self._fail_after = fail_after
        self.reads = 0
        self.released = False
        self.settings: dict = {}

    def isOpened(self) -> bool:  # noqa: N802 - cv2 naming
        return self._opened

    def read(self):
        self.reads += 1
        if self._fail_after is not None and self.reads > self._fail_after:
            return False, None
        frame = np.zeros((48, 64, 3), dtype=np.uint8)
        frame[0, 0] = (0, 0, 255)  # marker pixel for the mirror test
        return True, frame

    def set(self, prop, value):
        self.settings[prop] = value
        return True

    def release(self) -> None:
        self.released = True


def test_open_failure_raises_a_clear_error():
    capture = CameraCapture(CameraConfig(), factory=lambda _i: FakeCapture(opened=False))
    with pytest.raises(CameraError) as excinfo:
        capture.open()
    assert "could not be opened" in str(excinfo.value)
    assert capture.is_open is False


def test_read_before_open_raises():
    with pytest.raises(CameraError):
        CameraCapture().read()


def test_frame_is_mirrored_and_timestamped():
    config = CameraConfig(width=640, height=480, mirror=True)
    capture = CameraCapture(config, factory=lambda _i: FakeCapture())
    capture.open()
    frame = capture.read()
    assert frame is not None
    assert frame.width == 64 and frame.height == 48
    assert frame.image[0, -1, 2] == 255, "the marker pixel must move to the right edge"
    assert frame.timestamp >= 0.0
    capture.close()


def test_mirror_can_be_disabled():
    capture = CameraCapture(CameraConfig(mirror=False), factory=lambda _i: FakeCapture())
    capture.open()
    frame = capture.read()
    assert frame.image[0, 0, 2] == 255
    capture.close()


def test_read_failure_returns_none_then_raises():
    capture = CameraCapture(CameraConfig(), factory=lambda _i: FakeCapture(fail_after=0),
                            max_consecutive_failures=3)
    capture.open()
    assert capture.read() is None
    assert capture.read() is None
    with pytest.raises(CameraError):
        capture.read()


def test_close_is_idempotent():
    device = FakeCapture()
    capture = CameraCapture(CameraConfig(), factory=lambda _i: device)
    capture.open()
    capture.close()
    capture.close()
    assert device.released is True
    assert capture.is_open is False


def test_open_is_idempotent():
    calls = []

    def factory(index):
        calls.append(index)
        return FakeCapture()

    capture = CameraCapture(CameraConfig(), factory=factory)
    capture.open()
    capture.open()
    assert calls == [0]
    capture.close()


def test_capture_uses_configured_resolution():
    device = FakeCapture()
    capture = CameraCapture(CameraConfig(width=800, height=600), factory=lambda _i: device)
    capture.open()
    assert 800 in device.settings.values()
    assert 600 in device.settings.values()
    capture.close()
