"""UI smoke tests, offscreen: pages build, signals route, nothing blocks.

Marked ``ui``. Runs with ``QT_QPA_PLATFORM=offscreen`` so no display is needed.
"""

from __future__ import annotations

import os
import time

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
import pytest

pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication  # noqa: E402

from aircontrol.automation.recorder import RecordingExecutor  # noqa: E402
from aircontrol.config import AppConfig  # noqa: E402
from aircontrol.controllers.manager import ControllerManager  # noqa: E402
from aircontrol.core.actions import ControlMode  # noqa: E402
from aircontrol.core.gestures.engine import GestureEngine  # noqa: E402
from aircontrol.core.gestures.events import GestureEvent, RecognitionState  # noqa: E402
from aircontrol.core.features import extract_features  # noqa: E402
from aircontrol.data.analytics import Analytics  # noqa: E402
from aircontrol.data.repository import Repository  # noqa: E402
from aircontrol.ml.synth import GESTURE_POSES, synth_hand  # noqa: E402
from aircontrol.services.calibration import CalibrationService  # noqa: E402
from aircontrol.services.practice import PracticeService  # noqa: E402
from aircontrol.services.safety import SafetyManager  # noqa: E402
from aircontrol.services.session import SessionTracker  # noqa: E402
from aircontrol.ui.camera_thread import CameraWorker  # noqa: E402
from aircontrol.ui.context import AppContext  # noqa: E402
from aircontrol.ui.main_window import MainWindow  # noqa: E402
from aircontrol.ui.overlay import frame_to_qimage, placeholder_image, render_frame  # noqa: E402

pytestmark = pytest.mark.ui

PAGES = ["dashboard", "live", "air_mouse", "media", "presentation", "training",
         "custom", "analytics", "settings"]


@pytest.fixture(scope="session")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


@pytest.fixture
def context(tmp_path, qapp, monkeypatch):
    # Point the profile directory at tmp_path: saving settings from a page must
    # never touch the developer's real %APPDATA%\AirControl\config.json.
    monkeypatch.setenv("AIRCONTROL_DATA_DIR", str(tmp_path / "profile"))
    config = AppConfig()
    config.storage.database_path = str(tmp_path / "ui.db")
    executor = RecordingExecutor()
    repository = Repository.open(str(tmp_path / "ui.db"))
    manager = ControllerManager(executor, mode=ControlMode.NONE, enabled=False,
                                screen_size=(1280, 720))
    ctx = AppContext(
        config=config, engine=GestureEngine(), manager=manager,
        safety=SafetyManager(manager), executor=executor, repository=repository,
        analytics=Analytics(repository.conn),
        calibration=CalibrationService(repository), practice=PracticeService(repository),
        session=SessionTracker(repository))
    yield ctx
    repository.close()


@pytest.fixture
def window(context, qapp):
    win = MainWindow(context, None)
    yield win
    win.close()


def test_window_builds_every_page(window):
    assert window.stack.count() == len(PAGES)
    for key in PAGES:
        window._show_page(key)
        assert window.stack.currentWidget() is window.pages[key]


def test_state_payload_routes_to_all_pages(window):
    hand = synth_hand(GESTURE_POSES["OPEN_PALM"])
    state = RecognitionState(stable="OPEN_PALM", candidate="OPEN_PALM",
                             confidence=0.92, scores={"OPEN_PALM": 0.92},
                             features=extract_features(hand), tracking=True,
                             handedness="Right", hands_detected=1)
    window._on_state({"state": state, "fps": 27.0, "enabled": True,
                      "mode": "air_mouse", "last_action": "move",
                      "actions_fired": 3, "air_mouse": window.context.manager.air_mouse.status})
    assert window.pages["live"].gesture_value.text() == "Open Palm"
    assert window.pages["live"].finger_labels["index"].text() != "0.00"


def test_event_routes_to_training_page(window):
    window.context.practice.start("PINCH")
    window._on_events([GestureEvent("PINCH", 0.9, 0.0)])
    session = window.context.practice.session
    assert session.correct == 1


def test_emergency_stop_button_disables_control(window):
    window.context.set_mode(ControlMode.MEDIA)
    window.context.set_enabled(True)
    assert window.context.manager.enabled is True
    window._emergency_stop()
    assert window.context.manager.enabled is False


def test_enable_button_arms_control(window):
    window._toggle_control()
    assert window.context.manager.enabled is True
    window._toggle_control()
    assert window.context.manager.enabled is False


def test_failed_signal_is_shown_not_raised(window):
    window._on_failed("camera 0 could not be opened")
    assert "camera" in window.statusBar().currentMessage().lower()


def test_overlay_renders_the_frame_size():
    frame = np.zeros((120, 200, 3), dtype=np.uint8)
    image = frame_to_qimage(frame)
    assert image.width() == 200 and image.height() == 120
    state = RecognitionState()
    rendered = render_frame(frame, [synth_hand()], state)
    assert rendered.width() == 200


def test_placeholder_image_is_valid():
    image = placeholder_image(320, 200, "test")
    assert image.width() == 320 and not image.isNull()


def test_close_event_stops_cleanly(context, qapp):
    window = MainWindow(context, None)
    window.close()
    assert window._closing is True


def _wait_for_thread(worker, qapp, timeout: float = 20.0) -> None:
    """Wait for a QThread while pumping the event loop so signals arrive."""
    deadline = time.time() + timeout
    while worker.isRunning() and time.time() < deadline:
        qapp.processEvents()
        time.sleep(0.01)
    worker.wait(5000)
    qapp.processEvents()


class FakeCap:
    def __init__(self, *, opened: bool = True):
        self._opened = opened
        self.released = False

    def isOpened(self):  # noqa: N802
        return self._opened

    def read(self):
        return True, np.zeros((240, 320, 3), dtype=np.uint8)

    def set(self, *_args):
        return True

    def release(self):
        self.released = True


@pytest.mark.slow
def test_camera_worker_processes_frames_and_stops(context, qapp):
    config = context.config
    config.camera.width, config.camera.height = 320, 240
    worker = CameraWorker(config, context.engine, context.manager, None,
                          capture_factory=lambda _i: FakeCap(), max_frames=5)
    received: dict = {}
    worker.state_ready.connect(lambda payload: received.setdefault("state", payload))
    worker.failed.connect(lambda message: received.setdefault("failed", message))
    worker.start()
    _wait_for_thread(worker, qapp, timeout=20.0)
    assert worker.frames_processed == 5
    assert "failed" not in received
    assert "state" in received


def test_camera_worker_reports_a_missing_camera(context, qapp):
    config = context.config
    worker = CameraWorker(config, context.engine, context.manager, None,
                          capture_factory=lambda _i: FakeCap(opened=False))
    failures: list[str] = []
    worker.failed.connect(failures.append)
    worker.start()
    _wait_for_thread(worker, qapp, timeout=10.0)
    assert failures and "camera" in failures[0].lower()


# --------------------------------------------------------------------------- #
# Air Mouse page: settings must reach the running controller (regression)
# --------------------------------------------------------------------------- #
def test_air_mouse_page_apply_updates_the_running_controller(window):
    page = window.pages["air_mouse"]
    page.speed.slider.setValue(180)
    page.sensitivity.slider.setValue(120)
    page.dead_zone.slider.setValue(6)
    page.smoothing.slider.setValue(70)
    page.region.slider.setValue(10)
    page.drag_delay.slider.setValue(30)
    page._apply()

    controller = window.context.manager.air_mouse
    assert controller.config.gain == pytest.approx(1.8)
    assert controller.config.sensitivity == pytest.approx(1.2)
    assert controller.config.dead_zone_px == 6
    assert controller.config.active_region == pytest.approx(0.10)
    assert window.context.config.air_mouse.gain == pytest.approx(1.8)
    # The filter is rebuilt from the new cutoff, so smoothing takes effect now.
    assert controller._filter._x.min_cutoff == pytest.approx(max(0.3, 0.7 * 2.4))


def test_air_mouse_page_shows_the_detected_desktop(window):
    page = window.pages["air_mouse"]
    page.refresh()
    assert "1280" in page.bounds_label.text()
    assert "x 0-1279" in page.bounds_label.text()


def test_air_mouse_page_redetect_retargets_the_controller(window):
    from aircontrol.automation.screen import ScreenBounds

    window.context.screen_resolver = lambda: ScreenBounds(1920, 1080, source="test")
    page = window.pages["air_mouse"]
    page._refresh_bounds()
    assert window.context.manager.screen_bounds.as_tuple() == (1920, 1080)
    assert "1920" in page.bounds_label.text()
    assert window.context.manager.air_mouse.map_to_screen(1.0, 1.0) == (1919, 1079)


def test_page_settings_keep_the_corners_reachable(window):
    page = window.pages["air_mouse"]
    page.speed.slider.setValue(20)          # slowest cursor
    page.sensitivity.slider.setValue(20)
    page.region.slider.setValue(35)         # large margin
    page.dead_zone.slider.setValue(15)
    page._apply()

    controller = window.context.manager.air_mouse
    bounds = controller.screen_bounds
    assert controller.map_to_screen(1.0, 1.0) == (bounds.max_x, bounds.max_y)
    assert controller.map_to_screen(0.0, 0.0) == (0.0, 0.0)
