"""Cursor filters: behaviour, not implementation."""

from __future__ import annotations

import pytest

from aircontrol.core.smoothing import EMASmoother, OneEuroFilter, PointerFilter


def test_ema_first_sample_passes_through():
    ema = EMASmoother(0.3)
    assert ema((10.0, 20.0)) == (10.0, 20.0)


def test_ema_moves_towards_new_value():
    ema = EMASmoother(0.5)
    ema((0.0, 0.0))
    assert ema((10.0, 10.0)) == pytest.approx((5.0, 5.0))


def test_ema_alpha_validation():
    with pytest.raises(ValueError):
        EMASmoother(0.0)


def test_ema_reset():
    ema = EMASmoother(0.5)
    ema((5.0, 5.0))
    ema.reset()
    assert ema((1.0, 1.0)) == (1.0, 1.0)


def test_one_euro_smooths_jitter():
    filt = OneEuroFilter(min_cutoff=1.0, beta=0.01)
    values = [100.0, 103.0, 99.0, 101.0, 100.0]
    out = [filt(v, timestamp=i / 30.0) for i, v in enumerate(values)]
    spread_in = max(values) - min(values)
    spread_out = max(out[1:]) - min(out[1:])
    assert spread_out < spread_in


def test_one_euro_follows_a_fast_move_without_stalling():
    filt = OneEuroFilter(min_cutoff=1.0, beta=0.05)
    for i in range(5):
        filt(0.0, timestamp=i / 30.0)
    for i in range(5, 10):
        value = filt(200.0, timestamp=i / 30.0)
    assert value > 120.0, "a fast move must not be filtered into a crawl"


def test_one_euro_works_without_timestamps():
    filt = OneEuroFilter()
    assert filt(5.0) == 5.0
    assert filt(6.0) == pytest.approx(6.0, abs=1.0)


def test_one_euro_validation():
    with pytest.raises(ValueError):
        OneEuroFilter(min_cutoff=0.0)


def test_pointer_filter_strategies():
    for strategy in PointerFilter.STRATEGIES:
        pointer = PointerFilter(strategy)
        first = pointer((10.0, 10.0))
        assert first == pytest.approx((10.0, 10.0))


def test_pointer_filter_rejects_unknown_strategy():
    with pytest.raises(ValueError):
        PointerFilter("kalman")


def test_pointer_filter_reset_restarts():
    pointer = PointerFilter("ema", alpha=0.2)
    pointer((0.0, 0.0))
    pointer((100.0, 100.0))
    pointer.reset()
    assert pointer((7.0, 7.0)) == pytest.approx((7.0, 7.0))
