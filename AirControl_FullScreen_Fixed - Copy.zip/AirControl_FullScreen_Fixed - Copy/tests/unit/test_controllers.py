"""Controllers: air mouse, media, presentation and the manager's safety gates.

Every test drives a RecordingExecutor, so no test can move a real cursor.
"""

from __future__ import annotations

import pytest

from aircontrol.automation.recorder import RecordingExecutor
from aircontrol.config import AirMouseConfig
from aircontrol.controllers.air_mouse import AirMouseController
from aircontrol.controllers.manager import ControllerManager
from aircontrol.controllers.media import MediaController
from aircontrol.controllers.presentation import PresentationController
from aircontrol.core.actions import ControlMode, DEFAULT_MEDIA_BINDINGS
from aircontrol.core.features import extract_features
from aircontrol.core.gestures.events import GestureEvent, RecognitionState
from aircontrol.ml.synth import HandPose, synth_hand

DT = 1.0 / 30.0


def state_for(gesture: str | None, *, centre=(0.5, 0.5), scale: float = 0.28,
              tracking: bool = True) -> RecognitionState:
    hand = synth_hand(HandPose(center=centre, scale=scale))
    features = extract_features(hand)
    return RecognitionState(stable=gesture, candidate=gesture, confidence=0.9,
                            scores={gesture: 0.9} if gesture else {},
                            features=features, tracking=tracking,
                            handedness="Right", hands_detected=1 if tracking else 0)


def event(name: str, now: float = 0.0) -> GestureEvent:
    return GestureEvent(name=name, confidence=0.9, timestamp=now)


# --------------------------------------------------------------------------- #
# Air mouse
# --------------------------------------------------------------------------- #
def make_air_mouse(**config) -> tuple[AirMouseController, RecordingExecutor]:
    executor = RecordingExecutor()
    cfg = AirMouseConfig(smoothing="none", dead_zone_px=0, drag_delay_s=0.25,
                         scroll_min_velocity=0.2, scroll_interval_ms=50)
    for key, value in config.items():
        setattr(cfg, key, value)
    return AirMouseController(executor, config=cfg, screen_size=(1000, 500)), executor


def test_pointer_moves_the_cursor():
    controller, executor = make_air_mouse()
    controller.tick(state_for("TWO_FINGERS", centre=(0.7, 0.4)), now=0.0)
    moves = executor.of("move_mouse_to")
    assert len(moves) == 1
    x, y = moves[0].args
    assert x > 500 and y < 250


def test_pointer_maps_edges_to_screen_edges():
    controller, _ = make_air_mouse()
    left = controller.map_to_screen(0.0, 0.5)
    right = controller.map_to_screen(1.0, 0.5)
    assert left[0] == pytest.approx(0.0, abs=1.0)
    assert right[0] == pytest.approx(999.0, abs=1.0)


def test_active_region_margin_is_ignored():
    controller, _ = make_air_mouse(active_region=0.2)
    inside = controller.map_to_screen(0.2, 0.5)
    assert inside[0] == pytest.approx(0.0, abs=2.0)


def test_dead_zone_suppresses_jitter():
    controller, executor = make_air_mouse(dead_zone_px=8)
    controller.tick(state_for("TWO_FINGERS", centre=(0.5, 0.5)), now=0.0)
    executor.clear()
    controller.tick(state_for("TWO_FINGERS", centre=(0.501, 0.5)), now=DT)
    assert executor.of("move_mouse_to") == []


def test_quick_pinch_is_a_click():
    controller, executor = make_air_mouse(drag_delay_s=0.3)
    controller.tick(state_for("PINCH"), now=0.0)
    controller.tick(state_for("PINCH"), now=0.1)
    controller.tick(state_for("TWO_FINGERS"), now=0.2)
    assert executor.of("click") and executor.of("click")[0].args[0] == "left"
    assert executor.of("mouse_down") == []


def test_long_pinch_is_a_drag():
    controller, executor = make_air_mouse(drag_delay_s=0.2)
    controller.tick(state_for("PINCH"), now=0.0)
    controller.tick(state_for("PINCH"), now=0.25)
    assert executor.of("mouse_down"), "holding the pinch must start a drag"
    controller.tick(state_for("TWO_FINGERS"), now=0.4)
    assert executor.of("mouse_up"), "releasing the pinch must drop"


def test_drag_is_released_when_the_hand_disappears():
    controller, executor = make_air_mouse(drag_delay_s=0.2)
    controller.tick(state_for("PINCH"), now=0.0)
    controller.tick(state_for("PINCH"), now=0.3)
    controller.tick(state_for(None, tracking=False), now=0.5)
    assert executor.of("mouse_up")


def test_right_click_fires_once_per_activation():
    controller, executor = make_air_mouse()
    controller.handle_event(event("THREE_FINGERS"), now=0.0)
    controller.handle_event(event("THREE_FINGERS"), now=0.1)
    clicks = executor.of("click")
    assert len(clicks) == 1 and clicks[0].args[0] == "right"


def test_scroll_uses_vertical_motion_and_rate_limits():
    controller, executor = make_air_mouse(scroll_gain=10.0, scroll_min_velocity=0.1,
                                          scroll_interval_ms=100)
    controller.tick(state_for("OPEN_PALM", centre=(0.5, 0.30)), now=0.0)
    controller.tick(state_for("OPEN_PALM", centre=(0.5, 0.55)), now=0.1)
    scrolls = executor.of("scroll")
    assert scrolls and scrolls[0].args[0] < 0, "moving the hand down scrolls down"
    controller.tick(state_for("OPEN_PALM", centre=(0.5, 0.90)), now=0.12)
    assert len(executor.of("scroll")) == 1, "scroll must respect its interval"


def test_fist_pauses_the_air_mouse():
    controller, executor = make_air_mouse()
    controller.tick(state_for("CLOSED_FIST"), now=0.0)
    controller.tick(state_for("TWO_FINGERS", centre=(0.8, 0.2)), now=0.1)
    assert controller.status.paused is True
    assert executor.of("move_mouse_to") == []


def test_reset_releases_and_unpauses():
    controller, executor = make_air_mouse(drag_delay_s=0.1)
    controller.tick(state_for("PINCH"), now=0.0)
    controller.tick(state_for("PINCH"), now=0.2)
    controller.tick(state_for("CLOSED_FIST"), now=0.3)
    controller.reset()
    assert controller.status.dragging is False
    assert controller.status.paused is False
    assert executor.of("mouse_up")


def test_air_mouse_ignores_untracked_frames():
    controller, executor = make_air_mouse()
    controller.tick(state_for(None, tracking=False), now=0.0)
    assert len(executor) == 0


# --------------------------------------------------------------------------- #
# Media and presentation
# --------------------------------------------------------------------------- #
def test_media_binding_sends_the_right_key():
    executor = RecordingExecutor()
    controller = MediaController(executor)
    assert controller.handle_event(event("THUMBS_UP"), now=0.0) is True
    assert executor.of("media_key")[0].args[0] == "volume_up"


def test_media_guard_interval_blocks_a_repeat():
    executor = RecordingExecutor()
    controller = MediaController(executor, min_interval_ms=250)
    controller.handle_event(event("THUMBS_UP"), now=0.0)
    controller.handle_event(event("THUMBS_UP"), now=0.1)
    assert len(executor.of("media_key")) == 1


def test_unbound_gesture_does_nothing():
    executor = RecordingExecutor()
    controller = MediaController(executor)
    assert controller.handle_event(event("PINCH"), now=0.0) is False
    assert len(executor) == 0


def test_media_binding_table_is_respected():
    executor = RecordingExecutor()
    bindings = dict(DEFAULT_MEDIA_BINDINGS)
    from aircontrol.core.actions import Action
    bindings["OPEN_PALM"] = Action("media", "next", "Next")
    controller = MediaController(executor, bindings=bindings)
    controller.handle_event(event("OPEN_PALM"), now=0.0)
    assert executor.of("media_key")[0].args[0] == "next"


def test_presentation_sends_slide_keys():
    executor = RecordingExecutor()
    controller = PresentationController(executor)
    controller.handle_event(event("TWO_FINGERS"), now=0.0)
    controller.handle_event(event("THREE_FINGERS"), now=1.0)
    keys = [call.args[0] for call in executor.of("send_key")]
    assert keys == ["next_slide", "previous_slide"]


def test_presentation_window_guard_blocks_when_window_missing():
    class Guarded(RecordingExecutor):
        def focus_window(self, title_pattern: str) -> bool:
            super().focus_window(title_pattern)
            return False

    executor = Guarded()
    controller = PresentationController(executor, focus_window="PowerPoint")
    assert controller.handle_event(event("TWO_FINGERS"), now=0.0) is False
    assert executor.of("send_key") == []
    assert controller.blocked == 1


# --------------------------------------------------------------------------- #
# Manager
# --------------------------------------------------------------------------- #
def make_manager(**kwargs) -> tuple[ControllerManager, RecordingExecutor]:
    executor = RecordingExecutor()
    return ControllerManager(executor, screen_size=(1000, 500), **kwargs), executor


def test_disabled_manager_does_nothing():
    manager, executor = make_manager(mode=ControlMode.MEDIA, enabled=False)
    manager.handle([event("THUMBS_UP")], state_for(None), now=0.0)
    assert len(executor) == 0


def test_enabled_manager_routes_to_the_active_mode():
    manager, executor = make_manager(mode=ControlMode.MEDIA, enabled=True)
    acted = manager.handle([event("THUMBS_UP")], state_for(None), now=0.0)
    assert [e.name for e in acted] == ["THUMBS_UP"]
    assert executor.of("media_key")


def test_idle_mode_performs_no_actions():
    manager, executor = make_manager(mode=ControlMode.NONE, enabled=True)
    manager.handle([event("THUMBS_UP")], state_for(None), now=0.0)
    assert len(executor) == 0


def test_emergency_stop_disables_and_stays_disabled():
    manager, executor = make_manager(mode=ControlMode.MEDIA, enabled=True)
    manager.emergency_stop()
    assert manager.enabled is False
    manager.handle([event("THUMBS_UP")], state_for(None), now=1.0)
    assert len(executor) == 0


def test_switching_mode_resets_controllers():
    manager, _ = make_manager(mode=ControlMode.MEDIA, enabled=True)
    manager.media.handle_event(event("THUMBS_UP"), now=0.0)
    manager.set_mode(ControlMode.PRESENTATION)
    assert manager.media._last == {}


def test_toggle_flips_enabled():
    manager, _ = make_manager()
    assert manager.enabled is False
    assert manager.toggle() is True
    assert manager.toggle() is False


def test_on_action_listener_receives_actions():
    calls = []
    executor = RecordingExecutor()
    manager = ControllerManager(executor, mode=ControlMode.MEDIA, enabled=True,
                                screen_size=(1000, 500),
                                on_action=lambda *args: calls.append(args))
    manager.handle([event("THUMBS_UP")], state_for(None), now=0.0)
    assert calls and calls[0][0] == "THUMBS_UP"


def test_listener_failure_does_not_break_control():
    def boom(*_args):
        raise RuntimeError("listener exploded")

    executor = RecordingExecutor()
    manager = ControllerManager(executor, mode=ControlMode.MEDIA, enabled=True,
                                screen_size=(1000, 500), on_action=boom)
    manager.handle([event("THUMBS_UP")], state_for(None), now=0.0)
    assert executor.of("media_key")


def test_status_text_reflects_state():
    manager, _ = make_manager()
    assert "off" in manager.status_text().lower()
    manager.set_enabled(True)
    manager.set_mode(ControlMode.AIR_MOUSE)
    assert "Air Mouse" in manager.status_text()


def test_pause_latches_until_a_different_pose_is_shown():
    controller, executor = make_air_mouse()
    controller.tick(state_for("CLOSED_FIST"), now=0.0)
    controller.tick(state_for("TWO_FINGERS", centre=(0.8, 0.2)), now=0.1)
    assert controller.status.paused is True
    controller.tick(state_for("OPEN_PALM", centre=(0.8, 0.2)), now=0.2)
    assert controller.status.paused is False
