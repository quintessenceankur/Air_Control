"""ML path: metrics, dataset, training, inference and engine blending.

The numbers asserted here are about the pipeline being correct and
reproducible, not about real-world accuracy.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

from aircontrol.core.features import extract_features, feature_vector
from aircontrol.core.gestures.engine import GestureEngine
from aircontrol.core.gestures.spec import EngineConfig, VOCABULARY
from aircontrol.ml.dataset import NEGATIVE_LABEL, build_dataset
from aircontrol.ml.inference import MLClassifier, default_artifact_path
from aircontrol.ml.metrics import confusion_matrix, evaluate
from aircontrol.ml.synth import GESTURE_POSES, synth_hand
from aircontrol.ml.train import save_artifact, softmax, train


# -- metrics -----------------------------------------------------------------
def test_confusion_matrix_counts():
    matrix, labels = confusion_matrix(["a", "a", "b"], ["a", "b", "b"])
    assert labels == ["a", "b"]
    assert matrix.tolist() == [[1, 1], [0, 1]]


def test_confusion_matrix_length_mismatch():
    with pytest.raises(ValueError):
        confusion_matrix(["a"], ["a", "b"])


def test_perfect_classification_scores_one():
    report = evaluate(["a", "b", "c"], ["a", "b", "c"])
    assert report.accuracy == 1.0
    assert report.macro_f1 == 1.0
    assert report.samples == 3


def test_false_positive_rate_on_the_negative_class():
    report = evaluate(["NONE", "NONE", "PINCH"], ["PINCH", "NONE", "PINCH"],
                      negative_label="NONE")
    assert report.false_positive_rate == pytest.approx(0.5)
    assert report.accuracy == pytest.approx(2 / 3)


def test_unknown_rate_is_reported():
    report = evaluate(["PINCH", "PINCH"], ["PINCH", "UNKNOWN"],
                      labels=["PINCH", "UNKNOWN"])
    assert report.unknown_rate == pytest.approx(0.5)


def test_report_serialises():
    report = evaluate(["a"], ["a"])
    payload = report.as_dict()
    assert payload["accuracy"] == 1.0
    assert "confusion_matrix" in payload
    assert payload["per_class"][0]["label"] == "a"


# -- dataset -----------------------------------------------------------------
def test_dataset_shape_and_classes():
    dataset = build_dataset(samples_per_class=5, seed=1)
    assert len(dataset) == 5 * (len(VOCABULARY) + 1)
    assert dataset.features.shape[1] == 8
    assert NEGATIVE_LABEL in dataset.classes


def test_dataset_split_is_disjoint_and_stratified():
    dataset = build_dataset(samples_per_class=10, seed=2)
    train_set, val_set = dataset.split(validation=0.2, seed=2)
    assert len(train_set) + len(val_set) == len(dataset)
    assert len(val_set) == 2 * len(dataset.classes)
    assert set(val_set.labels) == set(dataset.classes)


# -- training and inference --------------------------------------------------
@pytest.fixture(scope="module")
def small_model(tmp_path_factory) -> tuple[Path, object]:
    dataset = build_dataset(samples_per_class=25, seed=3)
    result = train(dataset, epochs=60, seed=3)
    path = tmp_path_factory.mktemp("model") / "model.json"
    save_artifact(result, path, dataset_size=len(dataset))
    return path, result


def test_training_reaches_high_accuracy_on_synthetic_data(small_model):
    _path, result = small_model
    assert result.train_accuracy > 0.9
    assert result.validation_accuracy > 0.85


def test_artifact_round_trips(small_model):
    path, result = small_model
    classifier = MLClassifier.load(path)
    assert classifier is not None
    assert classifier.classes == result.classes
    payload = json.loads(path.read_text())
    assert payload["artifact_version"] == 1


def test_inference_probabilities_are_normalised(small_model):
    path, _result = small_model
    classifier = MLClassifier.load(path)
    features = extract_features(synth_hand(GESTURE_POSES["PINCH"]))
    probabilities = classifier.predict_proba(feature_vector(features))
    assert sum(probabilities.values()) == pytest.approx(1.0)
    assert all(0.0 <= p <= 1.0 for p in probabilities.values())


def test_inference_names_the_right_gesture(small_model):
    path, _result = small_model
    classifier = MLClassifier.load(path)
    for gesture in ("OPEN_PALM", "CLOSED_FIST", "PINCH", "THUMBS_UP"):
        features = extract_features(synth_hand(GESTURE_POSES[gesture]))
        probabilities = classifier.predict_proba(feature_vector(features))
        assert max(probabilities, key=probabilities.get) == gesture


def test_gesture_probabilities_exclude_the_negative_class(small_model):
    path, _result = small_model
    classifier = MLClassifier.load(path)
    features = extract_features(synth_hand(GESTURE_POSES["OPEN_PALM"]))
    probabilities = classifier.gesture_probabilities(features)
    assert set(probabilities) == set(VOCABULARY)
    assert all(0.0 <= value <= 1.0 for value in probabilities.values())


def test_missing_artifact_returns_none(tmp_path: Path):
    assert MLClassifier.load(tmp_path / "absent.json") is None


def test_corrupt_artifact_returns_none(tmp_path: Path):
    path = tmp_path / "broken.json"
    path.write_text('{"artifact_version": 99}', encoding="utf-8")
    assert MLClassifier.load(path) is None


def test_shipped_artifact_loads_and_matches_layout():
    path = default_artifact_path()
    if not path.exists():  # pragma: no cover - artifact is generated by a script
        pytest.skip("no shipped artifact; run scripts/train_ml.py")
    classifier = MLClassifier.load(path)
    assert classifier is not None
    assert classifier.weights.shape == (8, len(classifier.classes))


def test_engine_blends_ml_scores(small_model):
    path, _result = small_model
    classifier = MLClassifier.load(path)
    engine = GestureEngine(config=EngineConfig(ml_weight=0.5), ml_scorer=classifier)
    hand = synth_hand(GESTURE_POSES["OPEN_PALM"])
    scores = engine.scores_for(engine._features_for(hand))
    assert max(scores, key=scores.get) == "OPEN_PALM"


def test_softmax_is_stable_for_large_logits():
    logits = np.array([[1000.0, 0.0, -1000.0]])
    probabilities = softmax(logits)
    assert np.isfinite(probabilities).all()
    assert probabilities.sum() == pytest.approx(1.0)
