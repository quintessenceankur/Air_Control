"""The real MediaPipe model file: load it, run it, close it.

Marked ``slow``: it needs the bundled ``hand_landmarker.task``.
"""

from __future__ import annotations

import numpy as np
import pytest

from aircontrol.config import default_model_path
from aircontrol.vision.detector import DetectorError, HandLandmarkerDetector

pytestmark = pytest.mark.slow


@pytest.fixture(scope="module")
def detector():
    model = default_model_path()
    if not model.exists():  # pragma: no cover - model ships with the package
        pytest.skip("hand_landmarker.task not present")
    instance = HandLandmarkerDetector(model)
    yield instance
    instance.close()


def test_model_loads(detector):
    assert detector.num_hands == 2


def test_blank_frame_yields_no_hands(detector):
    frame = np.zeros((480, 640, 3), dtype=np.uint8)
    assert detector.detect(frame, 0) == []


def test_timestamps_are_forced_monotonic(detector):
    frame = np.zeros((240, 320, 3), dtype=np.uint8)
    detector.detect(frame, 100)
    detector.detect(frame, 50)  # going backwards must not raise
    assert detector._last_timestamp_ms >= 100


def test_empty_frame_is_rejected(detector):
    with pytest.raises(DetectorError):
        detector.detect(np.zeros((0, 0, 3), dtype=np.uint8), 0)


def test_missing_model_raises_a_clear_error(tmp_path):
    with pytest.raises(DetectorError) as excinfo:
        HandLandmarkerDetector(tmp_path / "nope.task")
    assert "not found" in str(excinfo.value)


def test_close_is_idempotent():
    model = default_model_path()
    if not model.exists():  # pragma: no cover
        pytest.skip("model missing")
    instance = HandLandmarkerDetector(model)
    instance.close()
    instance.close()
