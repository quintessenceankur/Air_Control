"""Regression tests for full-desktop cursor mapping.

These cover the bug where the air mouse could not reach the taskbar or the
bottom-right corner of the desktop:

* the mapping was fed Qt *logical* geometry instead of the pixel space the
  injector writes to (a 125% display lost 20% of the screen);
* ``availableGeometry`` was used, which excludes the taskbar by definition;
* ``gain``/``sensitivity`` scaled the range about the centre, so any value
  below 1.0 made the outer desktop unreachable;
* the pointer filter and the screen size were captured at construction, so
  applying settings from the UI changed nothing until restart.

Every test drives a ``RecordingExecutor``: no real cursor is moved.
"""

from __future__ import annotations

from dataclasses import replace

import pytest

from aircontrol.automation.recorder import RecordingExecutor
from aircontrol.automation.screen import (
    ScreenBounds,
    bounds_from_qt,
    describe_environment,
    query_primary_screen,
    resolve_screen_bounds,
    virtual_desktop_size,
)
from aircontrol.config import AirMouseConfig
from aircontrol.controllers.air_mouse import AirMouseController, _response_curve
from aircontrol.controllers.manager import ControllerManager
from aircontrol.core.features import extract_features
from aircontrol.core.gestures.events import RecognitionState
from aircontrol.ml.synth import HandPose, synth_hand

#: The reporter's machine: 1920x1080 physical at 125% scaling.
LOGICAL_1536x864 = ScreenBounds(1536, 864, source="qt logical")
PHYSICAL_1920x1080 = ScreenBounds(1920, 1080, source="win32")


def make_controller(screen_size=(1536, 864), **config_overrides):
    executor = RecordingExecutor()
    config = AirMouseConfig(**config_overrides)
    controller = AirMouseController(executor, config=config, screen_size=screen_size)
    return controller, executor


def state_at(x: float, y: float, gesture: str = "TWO_FINGERS") -> RecognitionState:
    """Recognition state whose fingertip is exactly at ``(x, y)``."""
    features = replace(extract_features(synth_hand(HandPose())), pointer=(x, y))
    return RecognitionState(stable=gesture, features=features, tracking=True)


def settle(controller: AirMouseController, x: float, y: float,
           frames: int = 240) -> tuple[int, int]:
    """Hold the fingertip at a point and return the last emitted pixel."""
    executor = controller.executor
    executor.clear()
    for index in range(frames):
        controller.tick(state_at(x, y), now=index / 30.0)
    moves = executor.of("move_mouse_to")
    assert moves, "the controller emitted no cursor movement at all"
    return moves[-1].args


# --------------------------------------------------------------------------- #
# 1-2. The corners, at several resolutions
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("size", [(1536, 864), (1920, 1080), (2560, 1440),
                                  (1280, 720), (1000, 500)])
def test_normalised_origin_maps_to_the_top_left(size):
    controller, _ = make_controller(size)
    assert controller.map_to_screen(0.0, 0.0) == (0.0, 0.0)


@pytest.mark.parametrize("size", [(1536, 864), (1920, 1080), (2560, 1440),
                                  (1280, 720), (1000, 500)])
def test_normalised_corner_maps_to_the_bottom_right(size):
    controller, _ = make_controller(size)
    width, height = size
    assert controller.map_to_screen(1.0, 1.0) == (width - 1, height - 1)


@pytest.mark.parametrize("size", [(1536, 864), (1920, 1080), (3840, 2160)])
def test_all_four_corners_are_reachable(size):
    controller, _ = make_controller(size)
    width, height = size
    corners = {
        (0.0, 0.0): (0, 0),
        (1.0, 0.0): (width - 1, 0),
        (0.0, 1.0): (0, height - 1),
        (1.0, 1.0): (width - 1, height - 1),
    }
    for hand, expected in corners.items():
        assert controller.map_to_screen(*hand) == expected
        assert settle(controller, *hand) == expected


def test_the_last_row_and_column_are_addressable():
    """The taskbar row is pixel 863 on the reporter's display, not 815."""
    controller, _ = make_controller((1536, 864))
    assert controller.screen_bounds.max_y == 863
    assert controller.map_to_screen(0.5, 1.0)[1] == 863


# --------------------------------------------------------------------------- #
# 3. Active area margin
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("margin", [0.0, 0.03, 0.18, 0.30])
def test_margin_defines_where_the_screen_edge_starts(margin):
    controller, _ = make_controller((1536, 864), active_region=margin)
    assert controller.map_to_screen(margin, 0.5)[0] == 0
    assert controller.map_to_screen(1.0 - margin, 0.5)[0] == 1535
    assert controller.map_to_screen(0.0, 0.5)[0] == 0  # beyond the margin clamps
    assert controller.map_to_screen(1.0, 0.5)[0] == 1535


def test_margin_does_not_restrict_the_screen_side():
    """A 30% margin still reaches every pixel; it only shortens hand travel."""
    controller, _ = make_controller((1536, 864), active_region=0.30)
    assert controller.map_to_screen(0.30, 0.30) == (0.0, 0.0)
    assert controller.map_to_screen(0.70, 0.70) == (1535, 863)


def test_margin_is_clamped_to_a_usable_range():
    controller, _ = make_controller((1536, 864), active_region=5.0)
    assert controller.map_to_screen(0.0, 0.0) == (0.0, 0.0)
    assert controller.map_to_screen(1.0, 1.0) == (1535, 863)


# --------------------------------------------------------------------------- #
# 4. Gain and sensitivity must not shrink the reachable area
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("gain", [0.2, 0.5, 1.0, 1.5, 3.0])
@pytest.mark.parametrize("sensitivity", [0.2, 0.5, 1.0, 3.0])
def test_gain_and_sensitivity_never_block_the_boundaries(gain, sensitivity):
    controller, _ = make_controller((1536, 864), gain=gain, sensitivity=sensitivity)
    assert controller.map_to_screen(0.0, 0.0) == (0.0, 0.0)
    assert controller.map_to_screen(1.0, 1.0) == (1535, 863)


def test_low_gain_slows_the_middle_but_keeps_the_ends():
    slow, _ = make_controller((1536, 864), gain=0.5, sensitivity=1.0)
    fast, _ = make_controller((1536, 864), gain=2.0, sensitivity=1.0)
    mid_slow = slow.map_to_screen(0.59, 0.5)[0]   # mid-frame, just right of centre
    mid_fast = fast.map_to_screen(0.59, 0.5)[0]
    assert mid_slow < mid_fast, "gain must change the response in the middle"
    assert slow.map_to_screen(1.0, 1.0) == fast.map_to_screen(1.0, 1.0)


def test_response_curve_is_monotonic_and_pinned_at_the_ends():
    for scale in (0.2, 0.5, 1.0, 2.0, 4.0):
        values = [_response_curve(t / 20.0, scale) for t in range(21)]
        assert values[0] == 0.0 and values[-1] == 1.0
        assert values == sorted(values), f"curve not monotonic at scale {scale}"
        assert values[10] == pytest.approx(0.5)


def test_extreme_gain_values_are_bounded():
    controller, _ = make_controller((1536, 864), gain=99.0, sensitivity=99.0)
    assert 0.0 <= controller.map_to_screen(0.5, 0.5)[0] <= 1535
    assert controller.map_to_screen(1.0, 1.0) == (1535, 863)


# --------------------------------------------------------------------------- #
# 5. Smoothing and the dead zone must not leave the cursor short
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("smoothing", ["one_euro", "ema", "none"])
def test_smoothing_does_not_permanently_restrict_the_range(smoothing):
    controller, _ = make_controller((1536, 864), smoothing=smoothing)
    assert settle(controller, 1.0, 1.0) == (1535, 863)
    assert settle(controller, 0.0, 0.0) == (0, 0)


def test_large_dead_zone_still_reaches_the_corner():
    controller, _ = make_controller((1536, 864), dead_zone_px=25, smoothing="one_euro")
    assert settle(controller, 1.0, 1.0) == (1535, 863)


def test_dead_zone_still_suppresses_jitter_away_from_the_edge():
    controller, executor = make_controller((1536, 864), dead_zone_px=8,
                                           smoothing="none")
    controller.tick(state_at(0.5, 0.5), now=0.0)
    executor.clear()
    controller.tick(state_at(0.5004, 0.5), now=1 / 30.0)
    assert executor.of("move_mouse_to") == []


def test_motion_between_frames_is_emitted_every_step():
    controller, executor = make_controller((1536, 864), smoothing="none",
                                           dead_zone_px=0)
    for index in range(10):
        controller.tick(state_at(0.30 + index * 0.03, 0.5), now=index / 30.0)
    assert len(executor.of("move_mouse_to")) >= 8


# --------------------------------------------------------------------------- #
# 6. Screen dimensions reach the controller
# --------------------------------------------------------------------------- #
def test_screen_bounds_object_is_accepted():
    controller = AirMouseController(RecordingExecutor(),
                                    screen_bounds=ScreenBounds(1920, 1080))
    assert controller.screen_size == (1920, 1080)
    assert controller.map_to_screen(1.0, 1.0) == (1919, 1079)


def test_set_screen_bounds_retargets_and_clamps_the_cursor():
    controller, _ = make_controller((1536, 864))
    assert settle(controller, 1.0, 1.0) == (1535, 863)
    controller.set_screen_bounds(ScreenBounds(1024, 768))
    assert controller.screen_size == (1024, 768)
    assert controller.map_to_screen(1.0, 1.0) == (1023, 767)
    assert controller.status.cursor[0] <= 1023
    assert controller.status.cursor[1] <= 767


def test_offsets_are_honoured_for_a_non_zero_origin():
    controller = AirMouseController(RecordingExecutor(),
                                    screen_bounds=ScreenBounds(800, 600, 1920, 0))
    assert controller.map_to_screen(0.0, 0.0) == (1920.0, 0.0)
    assert controller.map_to_screen(1.0, 1.0) == (2719.0, 599.0)


def test_manager_passes_bounds_through():
    manager = ControllerManager(RecordingExecutor(), screen_bounds=ScreenBounds(1600, 900))
    assert manager.screen_bounds.as_tuple() == (1600, 900)
    assert manager.air_mouse.map_to_screen(1.0, 1.0) == (1599, 899)


def test_manager_accepts_a_legacy_size_tuple():
    manager = ControllerManager(RecordingExecutor(), screen_size=(1280, 1024))
    assert manager.screen_bounds.as_tuple() == (1280, 1024)


# --------------------------------------------------------------------------- #
# 7. Applying settings updates the running controller
# --------------------------------------------------------------------------- #
def test_apply_config_rebuilds_the_pointer_filter():
    controller, _ = make_controller((1536, 864))
    before = controller._filter._x.min_cutoff
    updated = replace(controller.config, min_cutoff=2.2, gain=1.7)
    controller.apply_config(updated)
    assert controller._filter._x.min_cutoff == pytest.approx(2.2)
    assert controller.config.gain == pytest.approx(1.7)
    assert controller._filter._x.min_cutoff != before


def test_apply_config_switches_the_smoothing_strategy():
    controller, _ = make_controller((1536, 864), smoothing="one_euro")
    controller.apply_config(replace(controller.config, smoothing="none"))
    assert controller._filter.strategy == "none"
    assert settle(controller, 1.0, 1.0) == (1535, 863)


def test_manager_applies_air_mouse_config_to_the_live_controller():
    manager = ControllerManager(RecordingExecutor(), screen_bounds=ScreenBounds(1536, 864))
    manager.apply_air_mouse_config(replace(manager.air_mouse.config, dead_zone_px=17))
    assert manager.air_mouse.config.dead_zone_px == 17


def test_applying_settings_keeps_the_corners_reachable():
    controller, _ = make_controller((1536, 864))
    controller.apply_config(replace(controller.config, gain=0.3, sensitivity=0.3,
                                    active_region=0.25, dead_zone_px=12))
    assert settle(controller, 1.0, 1.0) == (1535, 863)


# --------------------------------------------------------------------------- #
# 8. DPI scaling
# --------------------------------------------------------------------------- #
class FakeGeometry:
    def __init__(self, width: int, height: int) -> None:
        self._width, self._height = width, height

    def width(self) -> int:
        return self._width

    def height(self) -> int:
        return self._height


class FakeScreen:
    """A Qt screen stand-in: logical geometry plus a device pixel ratio."""

    def __init__(self, width: int, height: int, dpr: float) -> None:
        self._geometry = FakeGeometry(width, height)
        self._available = FakeGeometry(width, height - 48)
        self._dpr = dpr

    def geometry(self):
        return self._geometry

    def availableGeometry(self):
        return self._available

    def devicePixelRatio(self) -> float:
        return self._dpr


@pytest.mark.parametrize("dpr,expected", [
    (1.0, (1920, 1080)),
    (1.25, (2400, 1350)),
    (1.5, (2880, 1620)),
    (2.0, (3840, 2160)),
])
def test_bounds_from_qt_multiplies_logical_geometry_by_dpr(dpr, expected):
    bounds = bounds_from_qt(FakeScreen(1920, 1080, dpr))
    assert bounds is not None
    assert bounds.as_tuple() == expected


def test_reporter_machine_logical_geometry_becomes_physical():
    """1536x864 logical at 125% is 1920x1080 physical, not 1536x864."""
    bounds = bounds_from_qt(FakeScreen(1536, 864, 1.25))
    assert bounds.as_tuple() == (1920, 1080)
    controller = AirMouseController(RecordingExecutor(), screen_bounds=bounds)
    assert controller.map_to_screen(1.0, 1.0) == (1919, 1079)


def test_available_geometry_is_not_used_for_mapping():
    """The taskbar strip must remain addressable: 864 tall, not 816."""
    screen = FakeScreen(1536, 864, 1.0)
    bounds = bounds_from_qt(screen)
    assert bounds.height == 864
    assert bounds.max_y == 863
    assert screen.availableGeometry().height() == 816  # what the old code used


def test_win32_metrics_take_priority_over_qt(monkeypatch):
    import aircontrol.automation.screen as screen_module

    monkeypatch.setattr(screen_module, "query_primary_screen",
                        lambda: ScreenBounds(1920, 1080, source="fake win32"))
    bounds = screen_module.resolve_screen_bounds(FakeScreen(1536, 864, 1.25))
    assert bounds.as_tuple() == (1920, 1080)
    assert "win32" in bounds.source


def test_resolver_falls_back_to_qt_then_to_a_default(monkeypatch):
    import aircontrol.automation.screen as screen_module

    monkeypatch.setattr(screen_module, "query_primary_screen", lambda: None)
    bounds = screen_module.resolve_screen_bounds(FakeScreen(1280, 720, 1.0))
    assert bounds.as_tuple() == (1280, 720)
    fallback = screen_module.resolve_screen_bounds(None)
    assert fallback.as_tuple() == (1920, 1080)
    assert "fallback" in fallback.source


def test_screen_bounds_reject_a_degenerate_size():
    with pytest.raises(ValueError):
        ScreenBounds(0, 1080)
    with pytest.raises(ValueError):
        ScreenBounds(1920, -1)


def test_clamp_rounds_and_bounds():
    bounds = ScreenBounds(1536, 864)
    assert bounds.clamp(-50, -50) == (0, 0)
    assert bounds.clamp(99999, 99999) == (1535, 863)
    assert bounds.clamp(10.4, 10.6) == (10, 11)


# --------------------------------------------------------------------------- #
# 9. Platform plumbing
# --------------------------------------------------------------------------- #
def test_query_primary_screen_is_none_off_windows():
    import os

    if os.name == "nt":  # pragma: no cover - Windows runner
        bounds = query_primary_screen()
        assert bounds is None or (bounds.width > 0 and bounds.height > 0)
    else:
        assert query_primary_screen() is None


def test_virtual_desktop_query_does_not_crash_off_windows():
    result = virtual_desktop_size()
    assert result is None or (len(result) == 4 and result[2] > 0)


def test_describe_environment_reports_the_qt_space():
    lines = describe_environment(FakeScreen(1536, 864, 1.25))
    assert any("dpr 1.25" in line for line in lines)
    assert any("1536x864" in line for line in lines)


def test_executor_screen_size_returns_a_size_not_a_cursor_position():
    """Regression: this used to return ``Controller().position``."""
    from aircontrol.automation.mouse import MouseExecutor

    executor = MouseExecutor.__new__(MouseExecutor)  # no pynput needed
    size = MouseExecutor.screen_size(executor)
    assert isinstance(size, tuple) and len(size) == 2
    assert size[0] >= 320 and size[1] >= 240


def test_approach_to_the_corner_is_smooth_not_a_jump():
    """Reaching the edge must not teleport: no step may exceed 25% of the screen."""
    controller, executor = make_controller((1536, 864), smoothing="one_euro")
    controller.tick(state_at(0.5, 0.5), now=0.0)
    executor.clear()
    for index in range(1, 60):
        # Sweep the fingertip from the centre towards the bottom-right corner.
        progress = index / 59.0
        controller.tick(state_at(0.5 + 0.5 * progress, 0.5 + 0.5 * progress),
                        now=index / 30.0)
    points = [call.args for call in executor.of("move_mouse_to")]
    assert points[-1] == (1535, 863)
    steps = [abs(b[0] - a[0]) for a, b in zip(points, points[1:])]
    assert max(steps) <= 1536 * 0.25, f"largest step {max(steps)} px looks like a jump"
    assert all(b[0] >= a[0] for a, b in zip(points, points[1:])), "motion must be monotonic"
