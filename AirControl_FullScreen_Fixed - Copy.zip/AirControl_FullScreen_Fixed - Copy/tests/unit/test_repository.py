"""Persistence: schema, settings, bindings, sessions, events, analytics."""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from aircontrol.core.actions import Action, ControlMode
from aircontrol.data.analytics import Analytics
from aircontrol.data.db import (
    DatabaseError,
    backup,
    connect,
    initialize,
    open_database,
    schema_version,
)
from aircontrol.data.models import CalibrationProfile, GestureEventRow, PracticeAttempt
from aircontrol.data.repository import Repository, RepositoryError


@pytest.fixture
def repo(tmp_path: Path) -> Repository:
    repository = Repository.open(str(tmp_path / "test.db"))
    yield repository
    repository.close()


def test_schema_is_created(tmp_path: Path):
    conn = open_database(tmp_path / "fresh.db")
    assert schema_version(conn) == 1
    tables = {row[0] for row in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"settings", "bindings", "sessions", "gesture_events",
            "practice_attempts", "calibration_profiles"} <= tables
    conn.close()


def test_initialize_is_idempotent(tmp_path: Path):
    conn = connect(tmp_path / "again.db")
    assert initialize(conn) == 1
    assert initialize(conn) == 1
    conn.close()


def test_settings_round_trip(repo: Repository):
    repo.set_setting("theme", {"mode": "dark"})
    assert repo.get_setting("theme") == {"mode": "dark"}
    assert repo.get_setting("missing", 42) == 42
    repo.set_setting("theme", "light")
    assert repo.get_setting("theme") == "light"
    assert "theme" in repo.all_settings()


def test_setting_key_validation(repo: Repository):
    with pytest.raises(RepositoryError):
        repo.set_setting("", 1)


def test_profiles_and_active_selection(repo: Repository):
    repo.save_profile(CalibrationProfile(name="laptop", is_active=True,
                                         cursor_speed=1.4))
    repo.save_profile(CalibrationProfile(name="desk", is_active=False))
    assert repo.active_profile().name == "laptop"
    assert repo.activate_profile("desk") is True
    assert repo.active_profile().name == "desk"
    assert len(repo.profiles()) == 2
    assert repo.delete_profile("desk") is True
    assert repo.active_profile() is None


def test_profile_validation(repo: Repository):
    with pytest.raises(RepositoryError):
        repo.save_profile(CalibrationProfile(name=""))
    with pytest.raises(RepositoryError):
        repo.save_profile(CalibrationProfile(name="x", cursor_speed=99.0))
    with pytest.raises(RepositoryError):
        repo.save_profile(CalibrationProfile(name="x", active_region=0.9))


def test_bindings_round_trip(repo: Repository):
    bindings = {gesture: Action("media", "mute", "Mute")
                for gesture in ("OPEN_PALM", "CLOSED_FIST", "PINCH",
                                "TWO_FINGERS", "THREE_FINGERS",
                                "THUMBS_UP", "THUMBS_DOWN")}
    repo.save_bindings(ControlMode.MEDIA, bindings)
    loaded = repo.load_bindings(ControlMode.MEDIA)
    assert loaded["OPEN_PALM"].target == "mute"


def test_invalid_bindings_are_rejected(repo: Repository):
    with pytest.raises(RepositoryError):
        repo.save_bindings(ControlMode.MEDIA, {"WAVE": Action("media", "mute")})


def test_corrupt_binding_rows_fall_back_to_defaults(repo: Repository):
    repo.conn.execute("INSERT INTO bindings (mode, gesture, kind, target) "
                      "VALUES ('media', 'OPEN_PALM', 'media', 'eject')")
    repo.conn.commit()
    loaded = repo.load_bindings(ControlMode.MEDIA)
    assert loaded["OPEN_PALM"].target == "play_pause"


def test_air_mouse_roles_round_trip(repo: Repository):
    roles = {"TWO_FINGERS": "pointer", "PINCH": "click", "THREE_FINGERS": "right_click",
             "OPEN_PALM": "scroll", "CLOSED_FIST": "pause"}
    repo.save_air_mouse_roles(roles)
    assert repo.load_air_mouse_roles() == roles
    with pytest.raises(RepositoryError):
        repo.save_air_mouse_roles({"WAVE": "pointer"})


def test_sessions_and_events(repo: Repository):
    session_id = repo.start_session(started_at=1000.0)
    repo.end_session(session_id, ended_at=1060.0, gestures_fired=3, actions_fired=2)
    sessions = repo.sessions()
    assert sessions[0].duration_s == pytest.approx(60.0)
    assert sessions[0].gestures_fired == 3

    repo.log_event(GestureEventRow(gesture="PINCH", confidence=0.9, executed=True,
                                   mode="media", occurred_at=1010.0,
                                   session_id=session_id))
    recent = repo.recent_events()
    assert recent[0].gesture == "PINCH" and recent[0].executed is True


def test_unknown_gesture_events_are_rejected(repo: Repository):
    with pytest.raises(RepositoryError):
        repo.log_event(GestureEventRow(gesture="WAVE", confidence=0.9, executed=True,
                                       mode="media", occurred_at=1.0))


def test_practice_history(repo: Repository):
    repo.log_practice(PracticeAttempt("PINCH", "PINCH", True, 0.9, 1.0))
    repo.log_practice(PracticeAttempt("PINCH", "CLOSED_FIST", False, 0.5, 2.0))
    history = repo.practice_history()
    assert len(history) == 2
    repo.clear_practice_history()
    assert repo.practice_history() == []


def test_analytics_snapshot(repo: Repository):
    session_id = repo.start_session(started_at=100.0)
    repo.end_session(session_id, ended_at=160.0, gestures_fired=2, actions_fired=1)
    for index, gesture in enumerate(("PINCH", "PINCH", "OPEN_PALM")):
        repo.log_event(GestureEventRow(gesture=gesture, confidence=0.8,
                                       executed=index < 2, mode="media",
                                       occurred_at=110.0 + index))
    repo.log_practice(PracticeAttempt("PINCH", "PINCH", True, 0.9, 1.0))
    snapshot = Analytics(repo.conn).snapshot()
    assert snapshot.total_sessions == 1
    assert snapshot.total_gestures == 3
    assert snapshot.gesture_counts[0] == ("PINCH", 2)
    assert snapshot.practice_accuracy == pytest.approx(1.0)
    assert len(snapshot.daily) == 14
    assert snapshot.mean_confidence == pytest.approx(0.8)


def test_reset_all_clears_user_data(repo: Repository):
    repo.set_setting("a", 1)
    repo.log_practice(PracticeAttempt("PINCH", "PINCH", True, 0.9, 1.0))
    repo.reset_all()
    assert repo.all_settings() == {}
    assert repo.practice_history() == []


def test_backup_writes_a_readable_copy(repo: Repository, tmp_path: Path):
    repo.set_setting("keep", "me")
    target = backup(repo.conn, tmp_path / "copy.db")
    with sqlite3.connect(target) as copy:
        row = copy.execute("SELECT value FROM settings WHERE key='keep'").fetchone()
    assert row[0] == '"me"'


def test_opening_an_unwritable_path_raises(monkeypatch, tmp_path: Path):
    """Repository.open must surface a database failure as RepositoryError.

    The failure is injected at ``sqlite3.connect`` instead of being provoked
    with a path such as ``/proc/...``: that path is Linux-specific, and on
    Windows it resolves to ``C:\\proc\\...``, which may be perfectly writable
    (or may fail only when the process is not elevated). Patching the connect
    call is deterministic on every platform and needs no administrator rights.
    """
    import aircontrol.data.db as db_module

    def refuse_to_connect(*_args, **_kwargs):
        raise sqlite3.OperationalError("unable to open database file")

    monkeypatch.setattr(db_module.sqlite3, "connect", refuse_to_connect)
    target = tmp_path / "unopenable.db"
    with pytest.raises(RepositoryError) as excinfo:
        Repository.open(str(target))
    message = str(excinfo.value)
    assert "cannot open database" in message
    assert str(target) in message
    assert isinstance(excinfo.value.__cause__, DatabaseError)
    assert not target.exists(), "a failed open must not leave a database behind"


def test_opening_a_path_below_a_regular_file_raises(tmp_path: Path):
    """A real filesystem failure, with no OS-specific path and no permissions.

    ``blocker`` is a regular file, so creating ``blocker/nested/x.db`` fails
    with an ``OSError`` (``FileExistsError`` on Linux, ``NotADirectoryError``
    or ``FileExistsError`` on Windows) before SQLite is ever reached.
    """
    blocker = tmp_path / "blocker"
    blocker.write_text("not a directory", encoding="utf-8")
    target = blocker / "nested" / "aircontrol.db"
    with pytest.raises(RepositoryError) as excinfo:
        Repository.open(str(target))
    assert "cannot open database" in str(excinfo.value)
    assert blocker.is_file(), "the blocker must still be an untouched file"
