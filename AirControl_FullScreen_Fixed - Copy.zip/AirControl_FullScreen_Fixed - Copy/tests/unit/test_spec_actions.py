"""The vocabulary table and the binding table are consistent and complete."""

from __future__ import annotations

import pytest

from aircontrol.core.actions import (
    AIR_MOUSE_ROLES,
    DEFAULT_AIR_MOUSE_ROLES,
    DEFAULT_MEDIA_BINDINGS,
    DEFAULT_PRESENTATION_BINDINGS,
    MEDIA_TARGETS,
    NONE,
    PRESENTATION_TARGETS,
    Action,
    ControlMode,
    bindings_for,
    validate_air_mouse_roles,
    validate_bindings,
)
from aircontrol.core.gestures.spec import (
    APPROVED,
    GESTURE_SPECS,
    PENDING_APPROVAL,
    PROPOSED,
    VOCABULARY,
    EngineConfig,
    spec_for,
    validate_specs,
)


def test_vocabulary_matches_the_owner_specification():
    assert VOCABULARY == ("OPEN_PALM", "CLOSED_FIST", "PINCH", "TWO_FINGERS",
                          "THREE_FINGERS", "THUMBS_UP", "THUMBS_DOWN")


def test_specs_are_internally_valid():
    validate_specs()
    for spec in GESTURE_SPECS.values():
        assert spec.exit < spec.enter
        assert spec.dwell_frames >= 1
        assert spec.cooldown_ms >= 0
        assert spec.description


def test_provenance_markers_are_known_values():
    for spec in GESTURE_SPECS.values():
        assert spec.provenance in (APPROVED, PROPOSED)


def test_unapproved_defaults_are_declared():
    assert len(PENDING_APPROVAL) >= 5, "proposed defaults must be listed for review"


def test_spec_for_unknown_gesture_raises():
    with pytest.raises(KeyError):
        spec_for("WAVE")


def test_every_gesture_is_accounted_for_in_each_binding_table():
    for mode, table in ((ControlMode.MEDIA, DEFAULT_MEDIA_BINDINGS),
                        (ControlMode.PRESENTATION, DEFAULT_PRESENTATION_BINDINGS)):
        assert set(table) == set(VOCABULARY), mode
        validate_bindings(mode, table)


def test_media_bindings_cover_every_media_target():
    targets = {a.target for a in DEFAULT_MEDIA_BINDINGS.values() if a.kind != NONE}
    assert targets == set(MEDIA_TARGETS)


def test_presentation_bindings_cover_every_target():
    targets = {a.target for a in DEFAULT_PRESENTATION_BINDINGS.values() if a.kind != NONE}
    assert targets == set(PRESENTATION_TARGETS)


def test_air_mouse_roles_are_valid_and_unique():
    validate_air_mouse_roles(DEFAULT_AIR_MOUSE_ROLES)
    assert set(DEFAULT_AIR_MOUSE_ROLES.values()) == set(AIR_MOUSE_ROLES)


def test_bindings_for_idle_and_air_mouse_are_empty():
    assert bindings_for(ControlMode.NONE) == {}
    assert bindings_for(ControlMode.AIR_MOUSE) == {}


def test_validate_rejects_an_unknown_gesture():
    with pytest.raises(ValueError):
        validate_bindings(ControlMode.MEDIA, {"WAVE": Action("media", "mute")})


def test_validate_rejects_an_unknown_target():
    with pytest.raises(ValueError):
        validate_bindings(ControlMode.MEDIA, {"OPEN_PALM": Action("media", "eject")})


def test_validate_rejects_an_unknown_action_kind():
    with pytest.raises(ValueError):
        validate_bindings(ControlMode.MEDIA, {"OPEN_PALM": Action("shell", "calc")})


def test_validate_air_mouse_rejects_duplicate_roles():
    with pytest.raises(ValueError):
        validate_air_mouse_roles({"TWO_FINGERS": "pointer", "PINCH": "pointer"})


def test_control_mode_labels():
    assert ControlMode.AIR_MOUSE.label == "Air Mouse"
    assert ControlMode.NONE.label == "Idle"


def test_engine_config_defaults_are_documented():
    config = EngineConfig()
    assert config.pinch_enter_ratio == pytest.approx(0.36)
    assert config.pinch_exit_ratio == pytest.approx(0.48)
