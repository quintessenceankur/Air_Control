"""Classifier behaviour: each gesture wins its own pose, negatives lose."""

from __future__ import annotations

import pytest

from aircontrol.core.features import extract_features
from aircontrol.core.gestures.classifiers import (
    GESTURE_CLASSIFIERS,
    score_all,
    score_closed_fist,
    score_open_palm,
    score_pinch,
    score_thumbs_down,
    score_thumbs_up,
)
from aircontrol.core.gestures.spec import GESTURE_SPECS, VOCABULARY
from aircontrol.ml.synth import GESTURE_POSES, NEGATIVE_POSES, HandPose, synth_hand


def features_for(gesture: str):
    return extract_features(synth_hand(GESTURE_POSES[gesture]))


def test_every_vocabulary_gesture_has_a_classifier():
    assert set(GESTURE_CLASSIFIERS) == set(VOCABULARY)


@pytest.mark.parametrize("gesture", VOCABULARY)
def test_gesture_scores_above_its_enter_threshold(gesture):
    scores = score_all(features_for(gesture))
    assert scores[gesture] >= GESTURE_SPECS[gesture].enter, scores


@pytest.mark.parametrize("gesture", VOCABULARY)
def test_gesture_is_the_argmax_for_its_own_pose(gesture):
    scores = score_all(features_for(gesture))
    best = max(scores, key=scores.get)
    assert best == gesture, f"{gesture} pose was read as {best}: {scores}"


@pytest.mark.parametrize("name", list(NEGATIVE_POSES))
def test_negative_poses_stay_below_every_enter_threshold(name):
    scores = score_all(extract_features(synth_hand(NEGATIVE_POSES[name])))
    for gesture, spec in GESTURE_SPECS.items():
        assert scores[gesture] < spec.enter, f"{name} triggered {gesture}: {scores}"


def test_scores_are_bounded():
    for gesture in VOCABULARY:
        for value in score_all(features_for(gesture)).values():
            assert 0.0 <= value <= 1.0


def test_open_palm_and_fist_are_opposites():
    palm = features_for("OPEN_PALM")
    fist = features_for("CLOSED_FIST")
    assert score_open_palm(palm) > 0.8 and score_open_palm(fist) < 0.2
    assert score_closed_fist(fist) > 0.8 and score_closed_fist(palm) < 0.2


def test_pinch_score_is_guarded_against_an_open_palm():
    """A straight hand with the thumb near the index tip is not a pinch."""
    pose = HandPose(curl={f: 0.0 for f in ("index", "middle", "ring", "pinky")},
                    thumb_abduction=1.0, pinch_gap=0.12)
    f = extract_features(synth_hand(pose))
    assert f.pinch_ratio < 0.36, "fixture must actually be a close pinch"
    assert score_pinch(f) < GESTURE_SPECS["PINCH"].enter


def test_pinch_score_rises_as_the_tips_close():
    wide = extract_features(synth_hand(HandPose(
        curl={"index": 0.55, "middle": 0.35, "ring": 0.3, "pinky": 0.3},
        pinch_gap=0.45)))
    close = extract_features(synth_hand(HandPose(
        curl={"index": 0.55, "middle": 0.35, "ring": 0.3, "pinky": 0.3},
        pinch_gap=0.10)))
    assert score_pinch(close) > score_pinch(wide)


def test_thumbs_up_and_down_are_direction_selected():
    up = features_for("THUMBS_UP")
    down = features_for("THUMBS_DOWN")
    assert score_thumbs_up(up) > 0.8 and score_thumbs_down(up) < 0.2
    assert score_thumbs_down(down) > 0.8 and score_thumbs_up(down) < 0.2


def test_thumbs_up_tolerates_moderate_tilt():
    tilted = extract_features(synth_hand(HandPose(
        curl={f: 1.0 for f in ("index", "middle", "ring", "pinky")},
        thumb_abduction=1.0, roll_deg=-30.0)))
    assert score_thumbs_up(tilted) >= GESTURE_SPECS["THUMBS_UP"].enter


def test_thumbs_up_rejects_a_fist():
    fist = features_for("CLOSED_FIST")
    assert score_thumbs_up(fist) < 0.2


def test_scores_are_scale_invariant():
    near = score_all(extract_features(synth_hand(HandPose(scale=0.38))))
    far = score_all(extract_features(synth_hand(HandPose(scale=0.13))))
    for gesture in VOCABULARY:
        assert near[gesture] == pytest.approx(far[gesture], abs=1e-6)


def test_scores_are_rotation_tolerant_for_palm_gestures():
    upright = score_all(extract_features(synth_hand(GESTURE_POSES["OPEN_PALM"])))
    tilted = score_all(extract_features(synth_hand(HandPose(roll_deg=20.0))))
    assert tilted["OPEN_PALM"] == pytest.approx(upright["OPEN_PALM"], abs=1e-6)
