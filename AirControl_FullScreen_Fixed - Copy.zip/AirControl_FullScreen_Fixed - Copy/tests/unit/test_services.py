"""Services: calibration, practice, session tracking and safety."""

from __future__ import annotations

from pathlib import Path

import pytest

from aircontrol.automation.recorder import RecordingExecutor
from aircontrol.config import AppConfig
from aircontrol.controllers.manager import ControllerManager
from aircontrol.data.repository import Repository
from aircontrol.services.calibration import CalibrationService
from aircontrol.services.practice import PracticeService, PracticeSession
from aircontrol.services.safety import HotkeyConfig, SafetyManager
from aircontrol.services.session import SessionTracker


@pytest.fixture
def repo(tmp_path: Path) -> Repository:
    repository = Repository.open(str(tmp_path / "svc.db"))
    yield repository
    repository.close()


# -- calibration -------------------------------------------------------------
def test_default_profile_is_created(repo: Repository):
    service = CalibrationService(repo)
    profile = service.current()
    assert profile.name == "default" and profile.is_active


def test_adjust_and_reset(repo: Repository):
    service = CalibrationService(repo)
    service.adjust(cursor_speed=1.6, active_region=0.25)
    assert service.current().cursor_speed == pytest.approx(1.6)
    service.reset()
    assert service.current().cursor_speed == pytest.approx(1.0)


def test_apply_to_config_changes_gain_and_thresholds(repo: Repository):
    service = CalibrationService(repo)
    service.adjust(cursor_speed=1.5, pinch_sensitivity=1.2, active_region=0.2)
    config = AppConfig()
    before = config.recognition.pinch_enter_ratio
    service.apply_to(config)
    assert config.air_mouse.gain == pytest.approx(1.5)
    assert config.air_mouse.active_region == pytest.approx(0.2)
    assert config.recognition.pinch_enter_ratio > before


def test_sensitivity_scale_is_bounded(repo: Repository):
    service = CalibrationService(repo)
    assert 0.2 <= service.sensitivity_scale() <= 3.0


# -- practice ----------------------------------------------------------------
def test_practice_session_counts():
    session = PracticeSession(target="PINCH")
    session.record("PINCH", 0.9)
    session.record("CLOSED_FIST", 0.5)
    assert session.correct == 1 and session.incorrect == 1
    assert session.accuracy == pytest.approx(0.5)
    session.reset()
    assert session.attempts == []


def test_practice_rejects_unknown_target():
    with pytest.raises(ValueError):
        PracticeSession(target="WAVE")


def test_practice_service_persists(repo: Repository):
    service = PracticeService(repo)
    service.start("PINCH")
    service.record("PINCH", 0.95)
    service.record("OPEN_PALM", 0.7)
    service.stop()
    history = repo.practice_history()
    assert len(history) == 2
    assert history[0].target_gesture == "PINCH"


def test_practice_service_without_session_is_safe(repo: Repository):
    service = PracticeService(repo)
    assert service.record("PINCH", 0.9) is None


# -- session tracker ---------------------------------------------------------
def test_session_tracker_buffers_and_flushes(repo: Repository):
    tracker = SessionTracker(repo, buffer_limit=2)
    tracker.start()
    tracker.record("PINCH", 0.9, True, "media", now=1.0)
    assert repo.recent_events() == []
    tracker.record("PINCH", 0.9, True, "media", now=2.0)
    assert len(repo.recent_events()) == 2
    tracker.end()
    assert tracker.stats.gestures == 2 and tracker.stats.actions == 2


def test_session_tracker_without_repository():
    tracker = SessionTracker(None)
    tracker.start()
    tracker.record("PINCH", 0.9, False, "media", now=1.0)
    tracker.end()
    assert tracker.stats.gestures == 1


# -- safety ------------------------------------------------------------------
def make_manager(enabled: bool = False) -> ControllerManager:
    return ControllerManager(RecordingExecutor(), enabled=enabled,
                             screen_size=(800, 600))


def test_arming_requires_confirmation():
    manager = make_manager()
    safety = SafetyManager(manager)
    assert safety.arm(confirm=False) is False
    assert manager.enabled is False
    assert safety.arm(confirm=True) is True
    assert manager.enabled is True


def test_toggle_and_emergency_stop():
    manager = make_manager(enabled=True)
    safety = SafetyManager(manager)
    assert safety.toggle() is False
    safety.arm(confirm=True)
    safety.emergency_stop()
    assert manager.enabled is False
    assert safety.emergency_stops == 1


def test_hotkey_registration_uses_the_injected_backend():
    registered: dict = {}

    class FakeListener:
        def __init__(self, mapping):
            registered.update(mapping)

        def start(self):
            registered["started"] = True

        def stop(self):
            registered["stopped"] = True

    manager = make_manager()
    safety = SafetyManager(manager, HotkeyConfig(toggle="<ctrl>+<alt>+a",
                                                 emergency="<ctrl>+<alt>+x"),
                           hotkey_factory=lambda mapping: FakeListener(mapping))
    assert safety.start_hotkeys() is True
    assert registered["started"] is True
    assert "<ctrl>+<alt>+a" in registered
    safety.stop_hotkeys()
    assert registered["stopped"] is True


def test_hotkey_callbacks_control_the_manager():
    callbacks: dict = {}

    class FakeListener:
        def __init__(self, mapping):
            callbacks.update(mapping)

        def start(self):
            pass

        def stop(self):
            pass

    manager = make_manager()
    safety = SafetyManager(manager, hotkey_factory=lambda m: FakeListener(m))
    safety.start_hotkeys()
    callbacks["<ctrl>+<alt>+a"]()
    assert manager.enabled is True
    callbacks["<ctrl>+<alt>+x"]()
    assert manager.enabled is False


def test_invalid_hotkey_is_rejected():
    manager = make_manager()
    safety = SafetyManager(manager, HotkeyConfig(toggle="ctrl+a"))
    assert safety.start_hotkeys() is False
