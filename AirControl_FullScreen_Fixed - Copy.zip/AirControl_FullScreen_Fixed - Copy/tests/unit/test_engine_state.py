"""Engine state machine: dwell, hysteresis, cooldown, switching, reset.

The engine's scores are replaced with scripted values here so that each rule
can be tested in isolation from the geometry.
"""

from __future__ import annotations

import pytest

from aircontrol.core.gestures.engine import GestureEngine
from aircontrol.core.gestures.spec import EngineConfig, GestureSpec

DT = 1.0 / 30.0
PALM = {"OPEN_PALM": 0.9}
PINCH = {"PINCH": 0.9}


def make_engine(**overrides) -> GestureEngine:
    config = dict(ema_alpha=1.0, min_presence=0.5, ml_weight=0.0,
                  switch_dwell_frames=3)
    config.update(overrides)
    return GestureEngine(config=EngineConfig(**config))


def drive(engine, synth, scores, frames, t0=0.0, dt=DT, gesture="OPEN_PALM"):
    """Feed ``frames`` identical frames with scripted scores."""
    events = []
    now = t0
    hand = synth(gesture=gesture)
    engine._score = lambda _features, _scores=dict(scores): dict(_scores)
    for _ in range(frames):
        events.extend(engine.update([hand], now=now))
        now += dt
    return events, now


def test_fires_once_after_dwell(engine, synth):
    events, _ = drive(engine, synth, PALM, 60)
    assert [e.name for e in events] == ["OPEN_PALM"]
    assert events[0].timestamp == pytest.approx(4 * DT)


def test_never_fires_below_enter_threshold(engine, synth):
    events, _ = drive(engine, synth, {"OPEN_PALM": 0.79}, 60)
    assert events == []
    assert engine.state.stable is None


def test_dwell_requires_consecutive_frames(engine, synth):
    events, _ = drive(engine, synth, PALM, 4)
    assert events == []
    events, _ = drive(engine, synth, {"OPEN_PALM": 0.2}, 1, t0=4 * DT)
    events2, _ = drive(engine, synth, PALM, 4, t0=5 * DT)
    assert events == [] and events2 == []


def test_hysteresis_keeps_a_borderline_gesture_active(engine, synth):
    events, t = drive(engine, synth, PALM, 10)
    assert len(events) == 1
    # 0.70 is between exit (0.60) and enter (0.80): must stay active, no refire.
    later, _ = drive(engine, synth, {"OPEN_PALM": 0.70}, 30, t0=t)
    assert later == []
    assert engine.state.stable == "OPEN_PALM"


def test_release_needs_consecutive_low_frames(engine, synth):
    drive(engine, synth, PALM, 10)
    engine._score = lambda _f: {"OPEN_PALM": 0.5}
    hand = synth(gesture="OPEN_PALM")
    engine.update([hand], now=0.5)
    engine.update([hand], now=0.5 + DT)
    assert engine.state.stable == "OPEN_PALM"  # 2 frames < release_frames (3)
    engine.update([hand], now=0.5 + 2 * DT)
    assert engine.state.stable is None


def test_cooldown_blocks_a_second_activation(engine, synth):
    events, t = drive(engine, synth, PALM, 10)
    assert len(events) == 1
    first_fire = events[0].timestamp
    # Release, then present the gesture again immediately.
    _, t = drive(engine, synth, {"OPEN_PALM": 0.3}, 4, t0=t)
    events2, t = drive(engine, synth, PALM, 6, t0=t)
    assert events2 == [], "must not re-fire inside the 600 ms cooldown"
    # Keep holding until the cooldown has expired.
    events3, _ = drive(engine, synth, PALM, 30, t0=t)
    assert [e.name for e in events3] == ["OPEN_PALM"]
    assert events3[0].timestamp - first_fire >= 0.6


def test_no_scores_means_no_candidate(engine, synth):
    events, _ = drive(engine, synth, {}, 30)
    assert events == []
    assert engine.state.candidate is None
    assert engine.state.confidence == 0.0


def test_switches_to_a_better_gesture_after_switch_dwell(engine, synth):
    drive(engine, synth, PALM, 10)
    assert engine.state.stable == "OPEN_PALM"
    events, _ = drive(engine, synth, {"OPEN_PALM": 0.85, "PINCH": 0.95}, 5, t0=0.4)
    assert [e.name for e in events] == ["PINCH"]
    assert engine.state.stable == "PINCH"


def test_active_gesture_is_released_before_a_challenger_takes_over(engine, synth):
    drive(engine, synth, PALM, 10)
    # Palm drops out of the band; pinch rises. Palm releases, then pinch dwells.
    events, _ = drive(engine, synth, {"OPEN_PALM": 0.2, "PINCH": 0.9}, 10, t0=0.4)
    assert [e.name for e in events] == ["PINCH"]


def test_reset_clears_everything(engine, synth):
    drive(engine, synth, PALM, 10)
    engine.reset()
    assert engine.state.stable is None
    assert engine.active_gesture is None
    events, _ = drive(engine, synth, PALM, 4)
    assert events == [], "reset must also clear the dwell counter"


def test_custom_spec_dwell_is_respected(synth):
    fast = {"OPEN_PALM": GestureSpec(name="OPEN_PALM", description="test",
                                     enter=0.8, exit=0.6, dwell_frames=2,
                                     release_frames=1, cooldown_ms=0)}
    engine = GestureEngine(config=EngineConfig(ema_alpha=1.0), specs=fast)
    events, _ = drive(engine, synth, PALM, 2)
    assert [e.name for e in events] == ["OPEN_PALM"]


def test_spec_rejects_an_inverted_band():
    with pytest.raises(ValueError):
        GestureSpec(name="X", description="", enter=0.5, exit=0.6,
                    dwell_frames=1, release_frames=1, cooldown_ms=0)


def test_spec_rejects_zero_dwell():
    with pytest.raises(ValueError):
        GestureSpec(name="X", description="", enter=0.9, exit=0.6,
                    dwell_frames=0, release_frames=1, cooldown_ms=0)


def test_state_exposes_scores_and_features(engine, synth):
    events, _ = drive(engine, synth, {"OPEN_PALM": 0.9, "PINCH": 0.2}, 6)
    state = engine.state
    assert state.scores["OPEN_PALM"] == pytest.approx(0.9)
    assert state.candidate == "OPEN_PALM"
    assert state.features is not None
    assert state.tracking is True
    assert state.gesture_label == "OPEN_PALM"
    assert events[0].handedness == "Right"


def test_two_hands_selects_the_nearer_hand(engine, synth):
    near_open = synth(gesture="OPEN_PALM", scale=0.38)
    far_fist = synth(gesture="CLOSED_FIST", scale=0.12)
    engine.update([far_fist, near_open], now=0.0)
    assert engine.state.hands_detected == 2
    assert engine.state.candidate == "OPEN_PALM"


def test_ml_weight_blends_scores(synth):
    engine = make_engine(ml_weight=1.0)
    engine._ml_scorer = lambda _f: {"THUMBS_UP": 1.0}
    hand = synth(gesture="OPEN_PALM")
    scores = engine.scores_for(engine._features_for(hand))
    assert scores["THUMBS_UP"] == pytest.approx(1.0)


def test_ml_blend_is_off_by_default(synth):
    engine = make_engine()
    engine._ml_scorer = lambda _f: {"THUMBS_UP": 1.0}
    scores = engine.scores_for(engine._features_for(synth(gesture="OPEN_PALM")))
    assert scores["THUMBS_UP"] < 0.1
