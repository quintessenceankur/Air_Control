"""Configuration: defaults, persistence, validation, frozen resource paths."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

from aircontrol.config import (
    AppConfig,
    CameraConfig,
    app_root,
    default_model_path,
    load_config,
    resource_path,
    user_data_dir,
)


def test_defaults_are_conservative():
    config = AppConfig()
    assert config.safety.start_enabled is False, "control must not start armed"
    assert config.recognition.ml_enabled is False
    assert config.camera.mirror is True
    assert 0.0 < config.recognition.ema_alpha <= 1.0


def test_save_and_load_round_trip(tmp_path: Path):
    path = tmp_path / "config.json"
    config = AppConfig()
    config.camera.index = 2
    config.air_mouse.gain = 1.7
    config.safety.toggle_hotkey = "<ctrl>+<alt>+t"
    config.save(path)
    loaded = AppConfig.load(path)
    assert loaded.camera.index == 2
    assert loaded.air_mouse.gain == pytest.approx(1.7)
    assert loaded.safety.toggle_hotkey == "<ctrl>+<alt>+t"


def test_missing_file_yields_defaults(tmp_path: Path):
    loaded = AppConfig.load(tmp_path / "absent.json")
    assert loaded.camera.index == 0


def test_corrupt_file_yields_defaults(tmp_path: Path):
    path = tmp_path / "config.json"
    path.write_text("{not json", encoding="utf-8")
    assert AppConfig.load(path).camera.index == 0


def test_unknown_keys_are_ignored(tmp_path: Path):
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"camera": {"index": 1, "future_option": True},
                                "unknown_section": {"a": 1}}), encoding="utf-8")
    config = AppConfig.load(path)
    assert config.camera.index == 1


@pytest.mark.parametrize("mutate", [
    lambda c: setattr(c.camera, "width", 100),
    lambda c: setattr(c.camera, "fps", 0),
    lambda c: setattr(c.recognition, "ema_alpha", 0.0),
    lambda c: setattr(c.recognition, "min_presence", 1.5),
    lambda c: setattr(c.air_mouse, "smoothing", "magic"),
    lambda c: setattr(c.air_mouse, "active_region", 0.6),
    lambda c: setattr(c.air_mouse, "dead_zone_px", -1),
    lambda c: setattr(c.air_mouse, "drag_delay_s", 0.01),
    lambda c: setattr(c.air_mouse, "scroll_interval_ms", 5),
    lambda c: setattr(c.storage, "log_level", "CHATTY"),
])
def test_invalid_values_are_rejected(mutate):
    config = AppConfig()
    mutate(config)
    with pytest.raises(ValueError):
        config.validate()


def test_env_overrides(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("AIRCONTROL_CAMERA", "3")
    monkeypatch.setenv("AIRCONTROL_DB", str(tmp_path / "x.db"))
    monkeypatch.setenv("AIRCONTROL_LOG_LEVEL", "debug")
    config = load_config(tmp_path / "none.json")
    assert config.camera.index == 3
    assert config.storage.database_path.endswith("x.db")
    assert config.storage.log_level == "DEBUG"


def test_env_camera_garbage_is_ignored(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("AIRCONTROL_CAMERA", "front")
    assert load_config(tmp_path / "none.json").camera.index == 0


def test_model_path_override(monkeypatch, tmp_path: Path):
    model = tmp_path / "model.task"
    monkeypatch.setenv("AIRCONTROL_MODEL", str(model))
    config = load_config(tmp_path / "none.json")
    assert config.model_file() == model


def test_default_model_is_bundled():
    model = default_model_path()
    assert model.name == "hand_landmarker.task"
    assert model.exists(), "the MediaPipe model must ship with the package"


def test_resource_path_resolves_bundled_file():
    assert resource_path("hand_landmarker.task").exists()


def test_frozen_layout_is_resolved(monkeypatch, tmp_path: Path):
    """A one-dir build puts data beside the executable, in _internal."""
    internal = tmp_path / "_internal" / "aircontrol" / "resources"
    internal.mkdir(parents=True)
    (internal / "hand_landmarker.task").write_bytes(b"stub")
    monkeypatch.setattr(sys, "frozen", True, raising=False)
    monkeypatch.setattr(sys, "executable", str(tmp_path / "AirControl.exe"))
    assert app_root() == tmp_path / "_internal"
    assert resource_path("hand_landmarker.task").read_bytes() == b"stub"


def test_user_data_dir_honours_override(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("AIRCONTROL_DATA_DIR", str(tmp_path / "data"))
    assert user_data_dir() == tmp_path / "data"


def test_camera_config_defaults():
    camera = CameraConfig()
    assert camera.width >= 640 and camera.height >= 480
