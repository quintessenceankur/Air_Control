"""Tracking gates: missing hands, low presence, partial holds, recovery."""

from __future__ import annotations

import pytest

from aircontrol.core.gestures.engine import GestureEngine, hand_from_row
from aircontrol.core.gestures.spec import EngineConfig
from aircontrol.core.landmarks import hand_from_array
from aircontrol.ml.synth import GESTURE_POSES, synth_landmarks

DT = 1.0 / 30.0


def test_no_hand_reports_untracked(engine):
    engine.update([], now=0.0)
    assert engine.state.tracking is False
    assert engine.state.stable is None
    assert engine.state.features is None


def test_low_presence_is_ignored(engine, synth):
    hand = synth(gesture="OPEN_PALM", presence=0.2)
    events = []
    for i in range(30):
        events += engine.update([hand], now=i * DT)
    assert events == []
    assert engine.state.tracking is False


def test_incomplete_landmarks_are_ignored(engine):
    partial = hand_from_array(synth_landmarks(GESTURE_POSES["OPEN_PALM"])[:20])
    events = []
    for i in range(30):
        events += engine.update([partial], now=i * DT)
    assert events == []
    assert engine.state.tracking is False


def test_partial_hold_is_discarded_when_the_hand_disappears(engine, synth):
    hand = synth(gesture="OPEN_PALM")
    for i in range(3):  # 3 of the 5 dwell frames
        engine.update([hand], now=i * DT)
    engine.update([], now=3 * DT)
    events = []
    for i in range(4, 8):  # only 4 more frames: dwell must restart, not resume
        events += engine.update([hand], now=i * DT)
    assert events == []


def test_cooldown_survives_a_brief_tracking_loss(engine, synth):
    hand = synth(gesture="OPEN_PALM")
    events = []
    for i in range(10):
        events += engine.update([hand], now=i * DT)
    assert len(events) == 1
    engine.update([], now=10 * DT)  # one dropped frame
    more = []
    for i in range(11, 20):
        more += engine.update([hand], now=i * DT)
    assert more == [], "a one-frame dropout must not allow an instant re-fire"


def test_reacquire_after_a_long_gap_can_fire_again(engine, synth):
    hand = synth(gesture="OPEN_PALM")
    events = []
    for i in range(10):
        events += engine.update([hand], now=i * DT)
    for i in range(10, 40):
        engine.update([], now=i * DT)
    for i in range(40, 50):
        events += engine.update([hand], now=i * DT)
    assert [e.name for e in events] == ["OPEN_PALM", "OPEN_PALM"]


def test_handedness_change_resets_smoothing(engine, synth):
    right = synth(gesture="OPEN_PALM", handedness="Right")
    left = synth(gesture="OPEN_PALM", handedness="Left")
    engine.update([right], now=0.0)
    engine.update([left], now=DT)
    assert engine.state.handedness == "Left"


def test_non_finite_presence_is_treated_as_no_hand(engine, synth):
    hand = synth(gesture="OPEN_PALM", presence=float("nan"))
    engine.update([hand], now=0.0)
    assert engine.state.tracking is False


def test_engine_config_defaults_are_sane():
    config = EngineConfig()
    assert 0.0 < config.ema_alpha <= 1.0
    assert 0.0 < config.min_presence < 1.0
    assert config.pinch_enter_ratio < config.pinch_exit_ratio
    assert config.ml_weight == 0.0, "the ML path must be off unless asked for"


def test_hand_from_row_round_trip():
    row = {"t": 0.5, "presence": 0.9, "handedness": "Left",
           "landmarks": synth_landmarks(GESTURE_POSES["OPEN_PALM"])}
    hand = hand_from_row(row)
    assert hand is not None and hand.is_complete
    assert hand.handedness == "Left"
    assert hand.presence == pytest.approx(0.9)
    assert hand.timestamp == pytest.approx(0.5)


def test_hand_from_row_without_landmarks():
    assert hand_from_row({"t": 0.0, "landmarks": []}) is None
