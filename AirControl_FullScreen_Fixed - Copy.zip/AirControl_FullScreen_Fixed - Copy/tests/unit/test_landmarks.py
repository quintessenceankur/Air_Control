"""Landmark maths: normalisation, scale invariance, degenerate input."""

from __future__ import annotations

import math

import numpy as np
import pytest

from aircontrol.core.landmarks import (
    INDEX_MCP,
    INDEX_TIP,
    NUM_LANDMARKS,
    PINKY_MCP,
    WRIST,
    Point,
    angle_deg,
    bounding_box,
    centroid,
    distance,
    hand_from_array,
    is_plausible,
    mirror,
    palm_length,
    palm_width,
    smooth_landmarks,
    to_canonical,
)
from aircontrol.ml.synth import GESTURE_POSES, HandPose, synth_hand


def test_hand_frame_reports_completeness():
    assert synth_hand().is_complete
    assert len(synth_hand().points()) == NUM_LANDMARKS


def test_incomplete_hand_is_rejected():
    short = hand_from_array([[0.5, 0.5, 0.0]] * 20)
    assert not short.is_complete
    assert not is_plausible(short)


def test_degenerate_palm_width_is_rejected():
    # Every landmark on the same spot: a detection artefact, not a hand.
    collapsed = hand_from_array([[0.5, 0.5, 0.0]] * 21)
    assert not is_plausible(collapsed)
    with pytest.raises(ValueError):
        to_canonical(collapsed)


def test_nan_landmarks_are_rejected():
    points = [[0.5, 0.5, 0.0]] * 21
    points[3] = [float("nan"), 0.5, 0.0]
    assert not is_plausible(hand_from_array(points))


def test_distance_and_angle():
    a, b, c = Point(0, 0), Point(1, 0), Point(1, 1)
    assert distance(a, b) == pytest.approx(1.0)
    assert angle_deg(a, b, c) == pytest.approx(90.0)
    assert angle_deg(Point(0, 0), Point(0, 0), Point(1, 1)) == 0.0


def test_angle_is_rotation_invariant():
    base = synth_hand(HandPose(curl={"index": 0.4, "middle": 0.4,
                                     "ring": 0.4, "pinky": 0.4}))
    rotated = synth_hand(HandPose(curl={"index": 0.4, "middle": 0.4,
                                        "ring": 0.4, "pinky": 0.4},
                                  roll_deg=37.0))
    for hand in (base, rotated):
        c = to_canonical(hand)
        angle = angle_deg(c[5], c[6], c[7])
        assert 60.0 < angle < 179.0
    c1, c2 = to_canonical(base), to_canonical(rotated)
    assert angle_deg(c1[5], c1[6], c1[7]) == pytest.approx(
        angle_deg(c2[5], c2[6], c2[7]), abs=1.0)


def test_canonical_is_translation_and_scale_invariant():
    small = synth_hand(HandPose(scale=0.14, center=(0.3, 0.4)))
    large = synth_hand(HandPose(scale=0.40, center=(0.7, 0.6)))
    np.testing.assert_allclose(to_canonical(small), to_canonical(large), atol=1e-6)


def test_canonical_mirrors_left_hand_to_match_right():
    right = synth_hand(HandPose(handedness="Right"))
    left = synth_hand(HandPose(handedness="Left"))
    np.testing.assert_allclose(to_canonical(left), to_canonical(right), atol=1e-9)


def test_canonical_origin_is_the_wrist_and_palm_width_is_one():
    c = to_canonical(synth_hand())
    assert np.allclose(c[WRIST], 0.0, atol=1e-9)
    assert np.linalg.norm(c[INDEX_MCP] - c[PINKY_MCP]) == pytest.approx(1.0)


def test_palm_measurements_scale_with_distance():
    near = synth_hand(HandPose(scale=0.30))
    far = synth_hand(HandPose(scale=0.15))
    assert palm_width(near) == pytest.approx(2 * palm_width(far), rel=1e-6)
    assert palm_length(near) == pytest.approx(2 * palm_length(far), rel=1e-6)


def test_mirror_swaps_handedness_and_flips_x():
    hand = synth_hand()
    flipped = mirror(hand)
    assert flipped.handedness == "Left"
    assert flipped.point(WRIST).x == pytest.approx(1.0 - hand.point(WRIST).x)


def test_smooth_landmarks_alpha_one_is_passthrough():
    hand = synth_hand()
    assert smooth_landmarks(hand.landmarks, hand.landmarks, 1.0) == hand.landmarks


def test_smooth_landmarks_blends_towards_new_frame():
    first = synth_hand(HandPose(center=(0.4, 0.5)))
    second = synth_hand(HandPose(center=(0.6, 0.5)))
    blended = smooth_landmarks(first.landmarks, second.landmarks, 0.5)
    assert blended[WRIST].x == pytest.approx(
        0.5 * first.point(WRIST).x + 0.5 * second.point(WRIST).x)


def test_smooth_landmarks_handles_missing_history():
    hand = synth_hand()
    assert smooth_landmarks(None, hand.landmarks, 0.5) == hand.landmarks


def test_bounding_box_and_centroid():
    hand = synth_hand()
    min_x, min_y, max_x, max_y = bounding_box(hand)
    assert min_x < max_x and min_y < max_y
    mid = centroid(hand)
    assert min_x <= mid.x <= max_x and min_y <= mid.y <= max_y


def test_index_tip_is_above_wrist_for_an_upright_hand():
    hand = synth_hand(GESTURE_POSES["OPEN_PALM"])
    assert hand.point(INDEX_TIP).y < hand.point(WRIST).y
