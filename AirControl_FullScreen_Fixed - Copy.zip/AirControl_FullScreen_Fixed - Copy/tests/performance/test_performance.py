"""Measured throughput of the recognition path.

Marked ``performance`` and excluded from the default run: the numbers depend
on the machine. Run with ``pytest -m performance -s`` to see them.
"""

from __future__ import annotations

import time

import pytest

from aircontrol.automation.recorder import RecordingExecutor
from aircontrol.config import AirMouseConfig
from aircontrol.controllers.air_mouse import AirMouseController
from aircontrol.core.features import extract_features
from aircontrol.core.gestures.engine import GestureEngine
from aircontrol.core.gestures.events import RecognitionState
from aircontrol.ml.synth import GESTURE_POSES, synth_hand

pytestmark = pytest.mark.performance
FRAMES = 600


def test_engine_throughput():
    engine = GestureEngine()
    hand = synth_hand(GESTURE_POSES["OPEN_PALM"])
    start = time.perf_counter()
    for index in range(FRAMES):
        engine.update([hand], now=index / 30.0)
    elapsed = time.perf_counter() - start
    fps = FRAMES / elapsed
    per_frame_ms = elapsed / FRAMES * 1000
    print(f"\nengine: {fps:.0f} frames/s ({per_frame_ms:.3f} ms/frame)")
    assert fps > 100, "the pure engine must not be the bottleneck"


def test_feature_extraction_cost():
    hand = synth_hand(GESTURE_POSES["PINCH"])
    start = time.perf_counter()
    for _ in range(FRAMES):
        extract_features(hand)
    elapsed = time.perf_counter() - start
    per_call_ms = elapsed / FRAMES * 1000
    print(f"\nfeature extraction: {per_call_ms:.3f} ms/call")
    assert per_call_ms < 5.0


def test_air_mouse_tick_cost():
    controller = AirMouseController(RecordingExecutor(),
                                    config=AirMouseConfig(smoothing="one_euro"),
                                    screen_size=(1920, 1080))
    hand = synth_hand(GESTURE_POSES["TWO_FINGERS"])
    features = extract_features(hand)
    state = RecognitionState(stable="TWO_FINGERS", features=features, tracking=True)
    start = time.perf_counter()
    for index in range(FRAMES):
        controller.tick(state, now=index / 30.0)
    elapsed = time.perf_counter() - start
    per_tick_ms = elapsed / FRAMES * 1000
    print(f"\nair mouse tick: {per_tick_ms:.4f} ms")
    assert per_tick_ms < 2.0
