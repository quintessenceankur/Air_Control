# Replay fixtures

One JSON object per line:

```json
{"t": 0.033, "presence": 0.97, "handedness": "Right",
 "landmarks": [[x, y, z], "... 21 landmarks ..."]}
```

`t` is seconds; `landmarks` are MediaPipe-normalised image coordinates (x right,
y down, z relative to the wrist). An empty `landmarks` list means "no hand in
this frame", which is how tracking-loss clips are written.

Each clip has a sibling `<name>.jsonl.meta.json`:

```json
{"label": "PINCH", "expect": ["PINCH"], "synthetic": true, "frames": 60}
```

`expect` is the exact event sequence the engine must produce. A negative clip
has `"expect": []` — those assertions are the ones that protect the product and
must never be relaxed to make a change pass.

`tests/unit/test_engine_replay.py` discovers every `*.jsonl` in this directory,
so a newly recorded clip is picked up with no code change.

## Synthetic vs recorded

`synthetic: true` clips come from `scripts/generate_fixtures.py` and
`aircontrol/ml/synth.py`; they test the geometry and the state machine.
`synthetic: false` clips are recorded from a real webcam with
`python -m aircontrol.vision.recorder` (or `scripts/evaluate_webcam.py
--record`) and live under `webcam/`. Only recorded clips can speak to
real-world accuracy, and `scripts/evaluate_webcam.py` evaluates just those.
