"""Shared pytest fixtures.

Nothing here needs a camera, a display or the operating system's input APIs:
gesture tests use synthesised landmarks, and controller tests use
:class:`aircontrol.automation.recorder.RecordingExecutor`, which records calls
instead of moving the real mouse.
"""

from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path

import numpy as np
import pytest

from aircontrol.automation.recorder import RecordingExecutor
from aircontrol.core.gestures.engine import GestureEngine
from aircontrol.core.gestures.spec import DEFAULT_ENGINE_CONFIG, EngineConfig
from aircontrol.ml.synth import GESTURE_POSES, NEGATIVE_POSES, HandPose, synth_hand

FIXTURES_DIR = Path(__file__).parent / "fixtures"


@pytest.fixture
def synth():
    """Factory for a hand frame: ``synth(index_curl=..., pinch=...)``.

    Kept keyword-based so a test reads like the pose it builds.
    """
    def _make(*, gesture: str | None = None, curl: dict[str, float] | None = None,
              thumb_abduction: float = 1.0, pinch_gap: float | None = None,
              roll_deg: float = 0.0, scale: float = 0.28,
              center: tuple[float, float] = (0.5, 0.55), noise: float = 0.0,
              handedness: str = "Right", presence: float = 1.0,
              timestamp: float = 0.0):
        if gesture is not None:
            pose = replace(GESTURE_POSES[gesture], scale=scale, center=center,
                           noise=noise, handedness=handedness)
        else:
            pose = HandPose(curl=curl or {f: 0.0 for f in
                                          ("index", "middle", "ring", "pinky")},
                            thumb_abduction=thumb_abduction, pinch_gap=pinch_gap,
                            roll_deg=roll_deg, scale=scale, center=center,
                            noise=noise, handedness=handedness)
        return synth_hand(pose, presence=presence, timestamp=timestamp)
    return _make


@pytest.fixture
def negative_pose():
    """Factory for a named negative pose (hand present, no gesture meant)."""
    def _make(name: str):
        return synth_hand(NEGATIVE_POSES[name])
    return _make


@pytest.fixture
def engine() -> GestureEngine:
    return GestureEngine()


@pytest.fixture
def make_engine():
    """Factory for an engine with a custom config (e.g. no smoothing)."""
    def _make(**kwargs) -> GestureEngine:
        base = dict(ema_alpha=1.0, min_presence=0.5, pinch_enter_ratio=0.36,
                    pinch_exit_ratio=0.48, ml_weight=0.0, switch_dwell_frames=3)
        base.update(kwargs)
        return GestureEngine(config=EngineConfig(**base))
    return _make


@pytest.fixture
def recording_executor() -> RecordingExecutor:
    return RecordingExecutor()


@pytest.fixture
def clock():
    """A controllable clock: ``clock()`` returns now, ``clock.advance(dt)``."""
    class Clock:
        def __init__(self) -> None:
            self.now = 0.0

        def __call__(self) -> float:
            return self.now

        def advance(self, dt: float) -> float:
            self.now += dt
            return self.now
    return Clock()


@pytest.fixture
def load_fixture():
    """Load a ``*.jsonl`` fixture as a list of rows."""
    def _load(name: str) -> list[dict]:
        path = FIXTURES_DIR / name
        return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
                if line.strip()]
    return _load


@pytest.fixture
def rng() -> np.random.Generator:
    return np.random.default_rng(12345)
