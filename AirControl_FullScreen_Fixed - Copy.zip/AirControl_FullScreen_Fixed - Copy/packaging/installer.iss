; Inno Setup script for AirControl.
;
; Build after PyInstaller, on Windows:
;     iscc packaging\installer.iss
;
; Produces dist\AirControl-Setup-1.0.1.exe

#define AppName "AirControl"
#define AppVersion "1.0.1"
#define AppPublisher "Ankur Dey"
#define AppExeName "AirControl.exe"
#define ProjectRoot ".."

[Setup]
AppId={{8E4C1F42-5B7A-4D2E-9C3B-1A6F0D7E5C21}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputDir={#ProjectRoot}\dist
OutputBaseFilename={#AppName}-Setup-{#AppVersion}
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
; A per-user install needs no administrator rights; a camera app should not ask.
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
; WebCam and MediaPipe both misbehave on older Windows 10 builds.
MinVersion=10.0.18362
SetupIconFile={#ProjectRoot}\aircontrol\resources\icons\aircontrol.ico
UninstallDisplayIcon={app}\{#AppExeName}
LicenseFile={#ProjectRoot}\docs\LICENSE.txt
DisableWelcomePage=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "{#ProjectRoot}\dist\AirControl\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
; Ship the docs beside the app so the user can read them without the repo.
Source: "{#ProjectRoot}\docs\USER_GUIDE.md"; DestDir: "{app}\docs"; Flags: ignoreversion
Source: "{#ProjectRoot}\docs\TROUBLESHOOTING.md"; DestDir: "{app}\docs"; Flags: ignoreversion
Source: "{#ProjectRoot}\README.md"; DestDir: "{app}\docs"; Flags: ignoreversion

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExeName}"
Name: "{group}\{cm:UninstallProgram,{#AppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(AppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent
Filename: "{app}\docs\USER_GUIDE.md"; Description: "Open the user guide"; Flags: shellexec postinstall skipifsilent unchecked

[UninstallDelete]
; Remove only what the installer created.
Type: filesandordirs; Name: "{app}\_internal"
Type: dirifempty; Name: "{app}"

[Code]
var
  RemoveUserData: Boolean;

function InitializeUninstall(): Boolean;
var
  Answer: Integer;
begin
  Answer := MsgBox('Also delete your AirControl settings, calibration and usage history?'
    + #13#10 + #13#10 + 'Choose No to keep them for a future install.',
    mbConfirmation, MB_YESNO);
  RemoveUserData := (Answer = IDYES);
  Result := True;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  UserData: String;
begin
  if (CurUninstallStep = usPostUninstall) and RemoveUserData then
  begin
    UserData := ExpandConstant('{userappdata}\AirControl');
    if DirExists(UserData) then
      DelTree(UserData, True, True, True);
  end;
end;
