# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for AirControl (one-dir build).

Build on Windows from the repository root:

    pyinstaller packaging/aircontrol.spec --noconfirm

Produces ``dist/AirControl/AirControl.exe`` with the MediaPipe model bundled
inside ``dist/AirControl/_internal/aircontrol/resources``.

One-dir, not one-file: MediaPipe resolves native DLLs relative to the
executable, and one-file mode unpacks to a temp directory on every launch,
which breaks that resolution and adds seconds of start-up time.
"""

from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files, collect_dynamic_libs

ROOT = Path(SPECPATH).resolve().parent
RESOURCES = ROOT / "aircontrol" / "resources"

datas = collect_data_files("mediapipe")
datas += [
    (str(RESOURCES / "hand_landmarker.task"), "aircontrol/resources"),
    (str(RESOURCES / "icons" / "aircontrol.png"), "aircontrol/resources/icons"),
    (str(ROOT / "aircontrol" / "models" / "gesture_classifier.json"),
     "aircontrol/models"),
]
datas += collect_data_files("pynput")

binaries = collect_dynamic_libs("mediapipe")

hiddenimports = [
    "mediapipe.python._framework_bindings",
    "mediapipe.tasks.python.vision.hand_landmarker",
    "pynput.keyboard._win32",
    "pynput.mouse._win32",
    "PySide6.QtCore",
    "PySide6.QtGui",
    "PySide6.QtWidgets",
]

excludes = [
    "tkinter", "matplotlib", "pytest", "IPython", "notebook",
    "PySide6.QtWebEngineCore", "PySide6.Qt3DCore", "PySide6.QtCharts",
    "PySide6.QtMultimedia", "PySide6.QtQuick", "PySide6.QtQml",
]

a = Analysis(
    [str(ROOT / "aircontrol" / "__main__.py")],
    pathex=[str(ROOT)],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=excludes,
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="AirControl",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    icon=str(RESOURCES / "icons" / "aircontrol.ico"),
    version=str(ROOT / "packaging" / "version_info.txt"),
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="AirControl",
)

# A console build for bug reports: same code, with a terminal attached.
exe_debug = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="AirControl-debug",
    debug=False,
    strip=False,
    upx=False,
    console=True,
    icon=str(RESOURCES / "icons" / "aircontrol.ico"),
    version=str(ROOT / "packaging" / "version_info.txt"),
)

coll_debug = COLLECT(
    exe_debug,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="AirControl-debug",
)
