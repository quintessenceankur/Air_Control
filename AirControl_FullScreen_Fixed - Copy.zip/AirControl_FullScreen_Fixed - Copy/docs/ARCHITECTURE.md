# Architecture

## Four boundaries, and why they matter

```
camera ──▶ vision ──▶ core ──▶ controllers ──▶ automation ──▶ OS
            │           │            │
      landmarks      gesture      intent
      only           state only   routing
```

| Layer | May do | May not do |
| --- | --- | --- |
| `vision/` | open the camera, run MediaPipe, emit `HandFrame` | decide anything about gestures |
| `core/` | pure maths: landmarks → features → scores → events | import `cv2`, `PySide6`, `pynput`, touch a file, read the clock |
| `controllers/` | turn events + state into executor calls, gate on mode/safety | know about Qt or the camera |
| `automation/` | perform OS input events | decide when to act |
| `ui/` | render state, own threads | contain recognition logic |

The `core` boundary is the one that pays for itself: the entire recognition
path can be replayed from a JSONL fixture with no camera, no Qt and no
display, which is how most of the 456 tests run.

## Module map

```
aircontrol/
  __main__.py          argparse entry point, --selftest, --version
  config.py            AppConfig dataclasses, JSON + env overrides,
                       frozen-aware resource_path(), user_data_dir()
  logging_setup.py     rotating file log + console, idempotent

  core/                          (pure; numpy only)
    landmarks.py       Point, HandFrame, distance, angle, to_canonical,
                       smooth_landmarks, plausibility gate
    features.py        finger extension, pinch ratio, spread, palm roll,
                       MotionTracker, feature_vector
    smoothing.py       EMA, One Euro, PointerFilter
    gestures/
      spec.py          GESTURE_SPECS, EngineConfig, PENDING_APPROVAL
      classifiers.py   one score function per gesture
      engine.py        GestureEngine: smoothing, hysteresis, dwell,
                       cooldown, tracking loss, ML blend hook
      events.py        GestureEvent, RecognitionState
    actions.py         ControlMode, Action, binding tables, validators

  vision/
    capture.py         CameraCapture with injectable device factory
    detector.py        HandLandmarkerDetector (Tasks API, VIDEO mode)
    recorder.py        LandmarkRecorder + `python -m aircontrol.vision.recorder`

  automation/
    base.py            ActionExecutor protocol, NullExecutor, ExecutorUnavailable
    screen.py          ScreenBounds; Win32 injector space, Qt fallback, diagnostics
    keyboard.py        pynput keyboard + media keys + presentation key map
    mouse.py           pynput mouse
    system.py          SystemExecutor facade, ctypes window focus
    recorder.py        RecordingExecutor (test double)

  controllers/
    base.py            Controller protocol
    air_mouse.py       pointer, click/drag, right click, scroll, pause
    media.py           debounced media keys
    presentation.py    slide keys with an optional window guard
    manager.py         mode selection, enable flag, emergency stop, routing

  data/
    db.py              connection, pragmas, migrations, backup
    models.py          row dataclasses
    repository.py      typed CRUD + validation
    analytics.py       aggregate queries

  services/
    calibration.py     per-user profile → thresholds and gains
    practice.py        Training Arena sessions
    session.py         buffered gesture logging
    safety.py          enable/disable, emergency stop, global hotkeys

  ml/
    synth.py           parametric 21-landmark hand model
    dataset.py         labelled feature dataset
    train.py           softmax regression, numpy only
    inference.py       artifact loading, engine adapter
    metrics.py         confusion matrix, precision/recall/F1

  ui/
    theme.py           palette + stylesheet
    components.py      Card, StatTile, Pill, MeterBar, Sparkline, chips
    overlay.py         numpy frame → QImage, skeleton + HUD painting
    camera_thread.py   QThread: capture → detect → engine → controllers
    context.py         AppContext: services + callbacks handed to pages
    main_window.py     sidebar, header, stacked pages, shutdown
    app.py             QApplication bootstrap and dependency wiring
    pages/             dashboard, live_studio, air_mouse, media,
                       presentation, training, custom, analytics, settings
```

## Data flow, per frame

```
CameraCapture.read()            → Frame(image, timestamp)
HandLandmarkerDetector.detect() → list[HandFrame]        (raw landmarks)
GestureEngine.update(hands, now)
    ├─ plausibility + presence gate          → idle if no usable hand
    ├─ EMA smooth landmarks (alpha 0.5)
    ├─ to_canonical()                        → wrist origin, palm units
    ├─ extract_features()                    → HandFeatures
    ├─ score_all()                           → {gesture: 0..1}
    └─ state machine                         → list[GestureEvent] (0 or 1)
ControllerManager.handle(events, state, now)
    ├─ mode gate, enable gate
    └─ AirMouse / Media / Presentation controller
ActionExecutor (SystemExecutor, or RecordingExecutor in tests)
```

`now` is always the frame timestamp passed in by the caller. The engine never
calls the clock, which is what makes dwell, cooldown and release deterministic
in tests and in fixture replay.

## Coordinate spaces

Two pixel spaces meet in the air mouse, and mixing them is a bug that looks
like "the cursor cannot reach the taskbar":

| Space | Who reports it | Scale |
| --- | --- | --- |
| Qt **logical** | `QScreen.geometry()`, `availableGeometry()` | device-independent; 1920x1080 at 125% reads 1536x864 |
| **Device / injector** | `SetCursorPos`, `GetSystemMetrics`, pynput | the real desktop; 1920x1080 |

Rules this project follows:

- The air mouse maps into the **injector** space, resolved by
  `automation/screen.py`: Win32 `GetSystemMetrics` first (virtualised the same
  way as the injector, so it is correct for DPI-aware and DPI-unaware
  processes alike), Qt geometry x `devicePixelRatio` as a fallback.
- `availableGeometry()` is never used for cursor mapping: it excludes the
  taskbar by definition.
- The last addressable pixel is `width - 1`; the mapping pins the frame edge
  to it, and edge snapping closes the filter's asymptotic gap.
- `gain * sensitivity` is a **response curve**, not a range multiplier: 0 and 1
  stay fixed, so no setting can make an edge unreachable.
- Screen bounds and settings are pushed to the live controller
  (`set_screen_bounds`, `apply_air_mouse_config`), never captured once at
  construction.

Multi-monitor: the primary monitor is mapped; the virtual desktop is not.

## Threading

- **Main thread:** widgets only. It receives `frame_ready(QImage)` and
  `state_ready(dict)` over queued connections and repaints.
- **`CameraWorker` (QThread):** owns the capture, the detector, the engine, the
  controllers and the session buffer. Everything that can block lives here.
- **Preview throttling:** frames are emitted at `ui.preview_fps` (default 30)
  independently of detection; stale frames are dropped rather than queued, so
  the UI can never fall behind the camera.
- **Shutdown:** `stop()` clears a flag; `closeEvent` joins the thread with a
  3 s timeout, then ends the session and releases the camera. A QThread is
  never terminated.
- **SQLite:** writes are buffered in `SessionTracker` and flushed in batches,
  so the camera thread never blocks on disk.

## Recognition design decisions

| Decision | Why |
| --- | --- |
| Canonical landmarks before features | Removes distance, camera and handedness from every measurement; a threshold in pixels is a bug. |
| Two-evidence finger extension | Angle alone fails on a foreshortened finger; length ratio alone fails when the hand rotates out of plane. |
| Geometric mean for conjunctions | A slightly curved finger on an open palm should dent the score, not veto it — while two fully curled fingers must still lose badly. |
| Gated thumb, not scaled thumb | A thumbs-up with a half-tucked thumb is not a thumbs-up; the gate also separates a fist from a thumbs-up, which have identical finger states. |
| Hysteresis band 0.80/0.60 | A score hovering at a single threshold chatters; the gap plus a release count stops it. |
| Dwell counted in frames | A dropped frame must not shorten a hold by accident; wall-clock dwell would make behaviour depend on machine load. |
| Cooldown keyed by gesture | Holding a pose fires once; re-forming it quickly is blocked for 600 ms. |
| ML off by default | The geometric rules are what the fixtures and the evaluation cover. The classifier is an extension point with an honest label. |

## Persistence

SQLite in WAL mode, schema version 1, additive migrations.

| Table | Contents |
| --- | --- |
| `settings` | key/value JSON (UI preferences, air-mouse roles) |
| `calibration_profiles` | named per-user profiles, one active |
| `bindings` | gesture → action per mode, validated on load |
| `sessions` | start/end, counters, duration |
| `gesture_events` | gesture, confidence, executed, mode, timestamp |
| `practice_attempts` | target, recognised, correct, confidence |

No images, no landmark streams, no biometric data. `Repository` validates on
the way in and converts `sqlite3` errors into `RepositoryError`, so a corrupt
row degrades to defaults instead of reaching a controller.

## Extension points

- **A new gesture**: add a `GestureSpec` to `GESTURE_SPECS`, a score function
  to `GESTURE_CLASSIFIERS`, a nominal pose to `GESTURE_POSES`, and regenerate
  fixtures. No engine change.
- **A new action**: add a target to `MEDIA_TARGETS` / `PRESENTATION_TARGETS`
  and a mapping in `automation/keyboard.py`. The binding editor picks it up.
- **A new controller mode**: implement the `Controller` protocol, add a
  `ControlMode` member, route it in `ControllerManager.handle`.
- **A real ML model**: replace `ml/train.py` and keep the `ml_scorer` hook —
  the engine blends any callable that maps features to per-gesture scores.
