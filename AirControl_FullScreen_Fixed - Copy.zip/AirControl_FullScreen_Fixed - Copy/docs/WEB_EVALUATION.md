# Real-world recognition evaluation

**Not yet measured.**

No webcam clips have been recorded on this machine, so there is no real-world accuracy figure for AirControl. The numbers in `docs/EVALUATION.md` are measured on synthetic poses and describe the geometry, not a human hand.

To produce this report on Windows:

```bat
python scripts/evaluate_webcam.py --record --gesture PINCH --clips 10
python scripts/evaluate_webcam.py --record --gesture OPEN_PALM --clips 10
rem ... one run per gesture, plus NEGATIVE for near-miss clips
python scripts/evaluate_webcam.py
```

Aim for at least 10 clips per gesture at varied distance and lighting, plus 5 negative clips (relaxed hand, hand on a desk, hand holding an object, typing, mid-transition). The script replays each clip through the real engine and reports clip accuracy, per-gesture precision, recall and F1, and the false-positive rate on the negative clips.
