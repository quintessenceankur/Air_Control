# Project audit — the original AirControl prototype

This is the audit of the material supplied for the rebuild: eight Python
files and a MediaPipe model bundle. It records what existed, what worked, what
would have failed in front of a user, and what was carried forward.

## What was supplied

| File | Lines | Role |
| --- | --- | --- |
| `hand_detector.py` | 63 | MediaPipe Tasks HandLandmarker wrapper (VIDEO mode, 2 hands) |
| `landmark_processor.py` | 105 | Joint angles, finger booleans, pinch distance, pinch hysteresis |
| `gesture_recognizer.py` | 51 | `if/elif` chain mapping finger booleans to a gesture name |
| `gesture_stabilizer.py` | 27 | Majority vote over a 7-frame deque |
| `finger_test.py` | 247 | Blocking `cv2` loop that draws the whole pipeline on the frame |
| `hand_tracking_test.py` | 88 | Blocking loop that draws the skeleton |
| `webcam_test.py` | 22 | Opens the camera and shows the frame |
| `test_environment.py` | 20 | Prints library versions (not a test) |
| `hand_landmarker.task`, `hand_landmarker-2.task` | 7.5 MB each | Byte-identical MediaPipe hand landmarker bundles |

There was no application: no window, no configuration, no persistence, no
tests, no packaging. The entry points were three scripts that took over the
screen with `cv2.imshow`.

## What was sound, and was kept

- **MediaPipe Tasks with `RunningMode.VIDEO`** and a strictly increasing
  timestamp. The original guarded against non-monotonic timestamps; that
  guard is preserved in `vision/detector.py` because MediaPipe degrades
  silently without it.
- **Pinch normalised by palm width** (`||tip4 − tip8|| / ||5 − 17||`), not raw
  pixels. The original's hysteresis pair — 0.36 to engage, 0.48 to release —
  is inherited unchanged as `EngineConfig.pinch_enter_ratio` /
  `pinch_exit_ratio`, because it is the owner's tuned value, not a guess.
- **The seven-gesture vocabulary** and the hand shape behind each name.
- **The model bundle**: `hand_landmarker.task` is the standard MediaPipe
  float16 hand landmarker (7 819 105 bytes, MD5
  `15318430ea3851670fe9914116a9cfad`). It is compatible with
  `mediapipe==0.10.14`, so it ships unchanged in
  `aircontrol/resources/hand_landmarker.task`. The duplicate `-2` copy was not
  used.

## Faults found, and what replaced them

### 1. Recognition was a priority chain, not a classifier

`gesture_recognizer.recognize()` returned the first matching branch. `PINCH`
was tested first, so any hand with the thumb near the index — including an
open palm seen at an angle — was a pinch. There was no score, no runner-up and
no "unknown": every frame produced a confident answer.

**Replaced by** seven independent score functions in
`core/gestures/classifiers.py`, each returning 0..1, combined with a geometric
mean so one weak finger degrades the score instead of collapsing it. The
engine takes the argmax only if it clears the enter threshold; otherwise the
answer is "no gesture".

### 2. Finger state came from a single fixed angle

`angle > 155` (fingers) and `angle > 145` (thumb) with no second condition.
A finger pointing at the camera projects to a short, foreshortened chain whose
joint angle collapses, so it read as "curled" — the single biggest source of
misreads in the prototype.

**Replaced by** a two-evidence score: joint angle at PIP/DIP *and*
tip-to-wrist over PIP-to-wrist length ratio, both mapped through declared
bands. Either alone flickers; together they held up under the scale and noise
stress in `docs/EVALUATION.md`.

### 3. Stabilisation had no notion of "fired once"

`GestureStabilizer` held a majority vote. Once five of seven frames agreed, it
returned the gesture on *every* subsequent frame. Nothing downstream could
tell "the gesture just started" from "the gesture is still being held", so any
action wired to it would repeat at frame rate.

**Replaced by** a state machine in `core/gestures/engine.py` with per-gesture
`enter`/`exit` hysteresis, a dwell count, exactly one event per activation,
a release count and a cooldown. It also latches a cooldown across a one-frame
tracking dropout.

### 4. No distance or handedness normalisation in features

Angles are scale-invariant, so the original got away with raw landmarks — but
the thumb up/down test compared raw image `y` of the thumb tip and IP joint,
which flips under a modest hand tilt, and nothing handled a left hand
differently from a right one.

**Replaced by** `core/landmarks.to_canonical()`: wrist origin, palm-width
units, left hands mirrored. Every feature is computed from that frame, so one
classifier serves both hands, and the thumb direction is measured from the
thumb CMC joint (a full palm width of baseline) with a declared margin band.

### 5. The pipeline lived inside a blocking script

`finger_test.py` opened the camera, ran detection, decided gestures and drew
overlays in one `while True` loop with `cv2.waitKey`. There was no way to test
any of it: no fixture, no injection point, no clock, no executor boundary.

**Replaced by** four layers with hard boundaries — vision produces landmarks,
core decides, automation acts, UI renders — plus a `QThread` that owns the
loop. The engine takes an injected `now`, so all timed behaviour is testable,
and `automation/recorder.py` lets tests assert on actions without touching the
desktop.

### 6. Operational gaps

No configuration file, no logging, no error handling around camera open or
model load, a model path relative to the current working directory (so the
app only started from one folder), no graceful shutdown, no database, no
packaging. Camera open failure exited with `raise SystemExit` and no message.

**Replaced by** `config.py` (frozen-aware paths, atomic saves, validation),
rotating file logs, explicit `CameraError`/`DetectorError` exceptions surfaced
in the UI, a SQLite store with migrations, and a PyInstaller one-dir build
with an Inno Setup installer.

### 7. "Test" files that were not tests

`test_environment.py` printed versions; `webcam_test.py` opened a window. The
project had no test suite.

**Replaced by** 456 automated tests, including replay fixtures per gesture and
negative fixtures that assert *no* action fires.

## What the rebuild deliberately did differently

- **Precision over recall.** A gesture that needs a second attempt is usable;
  one that fires while the user is talking with their hands is not. Thresholds
  sit high, dwell is required, and negative poses are asserted in tests.
- **Specification as data.** Gestures, thresholds and bindings are tables in
  `spec.py` and `actions.py`, not branches. `spec.PENDING_APPROVAL` lists every
  value the rebuild chose.
- **Optional ML, honestly labelled.** A softmax classifier exists, is trained
  by a script, evaluated on held-out synthetic data and **disabled by
  default**, because a model trained on a synthetic hand has not earned the
  right to drive a real cursor.
