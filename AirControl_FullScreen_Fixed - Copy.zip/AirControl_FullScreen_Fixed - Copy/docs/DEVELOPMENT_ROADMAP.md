# Development roadmap

What is done, what is deliberately deferred, and what would be built next.
Each item names the file it would touch, so the work can be picked up without
re-deriving the design.

## Done in this build

- Seven-gesture recognition with hysteresis, dwell, cooldown and tracking-loss
  handling, replayable from fixtures.
- Air Mouse (pointer, click, drag, right click, scroll, pause), media and
  presentation controllers, with mode gating and an emergency stop.
- Nine-screen PySide6 application on a camera `QThread`.
- SQLite persistence: settings, calibration profiles, bindings, sessions,
  gesture events, practice history.
- Optional softmax classifier with a real training pipeline, evaluated on
  held-out synthetic data, off by default.
- 456 tests, 94.21% coverage on `core/` + `data/`.
- PyInstaller one-dir spec, Inno Setup installer, GitHub Actions for tests and
  the Windows build.

## Phase 1 — validate on real hardware (owner)

1. Record the evaluation corpus: 10 clips per gesture plus 5 negative clips,
   varied distance and lighting (`scripts/evaluate_webcam.py --record`).
2. Run the evaluation and read the confusion matrix.
3. Adjust `enter`/`exit` in `core/gestures/spec.py` only where a fixture
   justifies it, and record which fixture moved which threshold.
4. Add the recorded clips to `tests/fixtures/` so they become regression tests.

Exit criteria: macro-F1 ≥ 0.95 on real clips, false-positive rate on negatives
below 2%.

## Phase 2 — calibration that does something measurable

- A guided calibration wizard: hold each pose for three seconds, measure the
  user's actual score distribution, and derive per-user `enter`/`exit` values
  instead of a global multiplier.
- Store the distribution with the profile so it can be re-derived later.
- Files: `services/calibration.py`, `ui/pages/training.py`,
  `core/gestures/spec.py` (profile-aware specs).

## Phase 3 — two-handed gestures

The engine already accepts `requires_hands=2` in `GestureSpec` and selects
from a list of hands, but no vocabulary entry uses it. A two-handed gesture
needs: a pairing rule (nearest two hands), a combined feature extractor, and a
spec entry. Files: `core/gestures/engine.py`, `core/features.py`.

## Phase 4 — a learned classifier worth shipping

The current model is trained on a parametric hand, which is why it is off by
default. To make it the primary path:

1. Collect ≥ 2 000 labelled frames per gesture from ≥ 10 people, varied
   lighting, skin tone, camera and distance.
2. Split by *person*, not by frame, so the validation set is honest.
3. Compare against the geometric rules on the same split; keep whichever wins
   per class, and consider a small gradient-boosted model on the same features.
4. Ship it only if it beats the rules on held-out people.

Files: `ml/dataset.py` (real loader), `ml/train.py`, `ml/inference.py`.

## Phase 5 — quality of life

- Per-application profiles (different bindings for a browser and PowerPoint).
- A tray icon with enable/disable, so the window can stay closed.
- Dwell and cooldown sliders in Settings (they are spec constants today).
- A gesture-recording mode in the UI, producing fixtures without the CLI.
- Localisation: the UI strings are plain English literals in the page modules.

## Phase 6 — robustness

- Watchdog for the camera thread: if frames stop arriving, restart capture
  instead of showing a frozen preview.
- Frame pacing: drop frames when detection falls behind, rather than queueing.
- Memory soak test: 8 hours with the camera running, RSS flat.
- Handle display scaling changes (DPI) on the air-mouse coordinate mapping.

## Known gaps that are not planned

- One-file PyInstaller builds: MediaPipe's DLL resolution makes them fragile.
  One-dir plus an installer is the supported path.
- macOS/Linux automation: the interface exists, the backends do not.
- Cloud anything: the product is explicitly offline.
