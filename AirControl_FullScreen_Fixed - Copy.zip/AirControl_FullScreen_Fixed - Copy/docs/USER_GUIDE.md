# User guide

AirControl watches your hand through the webcam and turns seven hand poses
into desktop actions. Nothing happens until you enable control, and one
keystroke stops everything.

## First run

1. Start AirControl. The Dashboard shows the camera status.
2. If the camera pill stays grey, see [TROUBLESHOOTING.md](TROUBLESHOOTING.md).
3. Open **Live Gesture Studio** and hold an open palm about 50–80 cm from the
   camera, hand roughly upright. The `OPEN_PALM` score should pass 0.80.
4. Open **Air Mouse**, press **Activate Air Mouse**, then **Enable control** in
   the header.
5. Hold two fingers up and move your hand: the cursor follows your index
   fingertip.

Gesture control is always off at start-up. Enabling it is a deliberate action.

## The seven gestures

| Gesture | How to hold it | Notes |
| --- | --- | --- |
| **Open palm** | all five fingers straight, palm toward the camera | keep the thumb clearly away from the index |
| **Closed fist** | all five fingers curled into the palm, thumb folded over | a thumb sticking out reads as thumbs-up |
| **Pinch** | thumb tip and index tip touching | other fingers relaxed; do not spread the whole hand |
| **Two fingers** | index and middle up, ring and pinky folded | thumb position does not matter |
| **Three fingers** | index, middle and ring up, pinky folded | |
| **Thumbs up** | thumb up on screen, other four folded | works with the hand tilted, as long as the thumb points up |
| **Thumbs down** | thumb down on screen, other four folded | |

Hold a pose still for about a fifth of a second (five frames) — the engine
requires that dwell before it acts. It then fires **once** and waits 600 ms
before the same gesture can fire again, so holding a pose does not repeat an
action.

## Air Mouse

| Pose | What it does |
| --- | --- |
| Two fingers | move the cursor with your index fingertip |
| Pinch (quick) | left click |
| Pinch (hold ~0.25 s) then move | drag; release the pinch to drop |
| Three fingers | right click |
| Open palm | scroll: move your hand up or down |
| Closed fist | pause the air mouse until you change pose |

The outer 18% of the camera frame is ignored by default, so you do not have to
reach the edge of the view to reach the edge of the screen. That margin crops
the **camera frame**, never the screen: the full desktop — taskbar, all four
corners — is always reachable.

**Cursor speed** and **Sensitivity** shape how far the cursor travels for a
given hand movement (a response curve). They do not shrink the reachable area:
a slow setting means you move your hand further, not that you cannot get there.
The Air Mouse page shows the exact pixel space in use under **Desktop
coverage**, with a **Re-detect desktop size** button for after a resolution or
scaling change.

## Media and presentation

Media mode sends the system media keys; presentation mode sends the standard
slide keys (→, ←, F5, Esc). Each mode has its own mapping table — change a row
and press **Save mapping**. Presentation mode can be restricted to a window
whose title contains a given string (for example `PowerPoint`), so slide keys
are not sent while you are typing elsewhere.

Only one controller is active at a time. Switching mode resets the previous
one and releases anything it was holding.

## Training Arena

Choose a gesture, press **Start practice**, and hold the pose. Every time the
engine fires, the attempt is recorded: correct if it named the pose you were
asked for, incorrect otherwise. The counters and accuracy are yours, stored
locally, and shown again on the Analytics page.

This screen measures your recognition rate. It does **not** train a model —
AirControl ships with fixed recognition rules, and the app says so on the page.

## Custom Gesture Studio

Assign any gesture to any supported action for either controller, and see the
mapping that is currently live. Bindings are saved to your profile and applied
immediately.

## Analytics

Sessions, total gestures, actions performed, active time, gesture usage,
practice accuracy per gesture and recent sessions. Everything is counted from
your own recorded activity — there is no synthetic filler.

## Settings

- **Camera**: device index, resolution, mirroring, skeleton overlay.
- **Recognition**: landmark smoothing and detection confidence. Raise
  confidence if AirControl reacts to hands that are not trying to gesture.
- **Experimental ML classifier**: off by default. It blends a small model
  trained on synthetic poses with the geometric rules; the geometric path is
  the tested one.
- **Safety**: whether control starts enabled, the two global hotkeys, and an
  emergency stop button.
- **Data**: save settings, back up the database, restore defaults.

## Safety

| Hotkey | Action |
| --- | --- |
| **Ctrl+Alt+A** | toggle gesture control on/off (works anywhere) |
| **Ctrl+Alt+X** | emergency stop: disable control, release any held button, stay off |

Also always available: the **Emergency stop** button in the sidebar, the
button on the Dashboard, and the **Stop** button on each controller page.

## Privacy

- No video is recorded and no images are stored.
- Landmarks exist only in memory while a frame is processed.
- No network requests are made, ever.
- Your data is three files in `%APPDATA%\AirControl`: `config.json`,
  `aircontrol.db` and a log.
- The camera is open only while AirControl is running.

## Improving recognition for your hand

1. Use the **Training Arena** to find which gestures misfire for you.
2. In **Settings → Recognition**, adjust detection confidence; in
   **Calibration** (via Training Arena profiles) adjust gesture and pinch
   sensitivity.
3. Check the light: a hand lit from behind is a silhouette, and silhouettes
   lose fingertip detail.
4. Keep the whole hand in frame, including the wrist — the palm width is the
   scale reference for every measurement.
