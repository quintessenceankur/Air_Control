# Installation

## 1. Installing a release build (Windows 10 1903+ / Windows 11)

1. Run `AirControl-Setup-1.0.1.exe`.
2. The installer is per-user (`PrivilegesRequired=lowest`): no administrator
   rights, no UAC prompt. Default location: `%LOCALAPPDATA%\Programs\AirControl`.
3. Leave **Create a desktop icon** unticked unless you want one.
4. On the last page, **Launch AirControl** is ticked by default.
5. Windows will ask for camera permission the first time. Allow it, or set
   **Settings → Privacy & security → Camera → Let desktop apps access your
   camera** to On.

The installer bundles the MediaPipe model, so the application works offline
immediately. Nothing is downloaded at runtime.

### Uninstalling

Apps & Features → AirControl → Uninstall. You are asked whether to delete your
settings, calibration and usage history; answering No keeps them for a future
install.

## 2. Running from source

```bash
git clone <repository> AirControl_Rebuilt
cd AirControl_Rebuilt
python -m venv .venv
.venv\Scripts\activate            # Windows
# source .venv/bin/activate       # Linux/macOS (UI only; actions suppressed)
pip install -e ".[dev]"
python -m aircontrol --selftest
python -m aircontrol
```

`--selftest` checks the Python version, the bundled model, numpy, OpenCV,
MediaPipe, PySide6, the recognition engine (it runs a synthetic open palm
through it), the database and the desktop backend, then exits without opening
a window. It is the first thing to run when something is wrong.

### Requirements

| Component | Version | Notes |
| --- | --- | --- |
| Python | 3.11 (3.12 also tested) | 3.11 is the target |
| numpy | 1.26 – 2.x | |
| opencv-python | 4.9 – 5.x | tested on 4.10 and 5.0 |
| mediapipe | 0.10.14 | pinned: the Tasks API moves between minors |
| PySide6 | 6.7.3 | pinned |
| pynput | 1.7.7 | Windows only |
| pytest, pytest-cov | dev only | |
| pyinstaller | 6.6+ | packaging only |

## 3. Command-line options

```
python -m aircontrol                 launch the app
python -m aircontrol --selftest      verify the install and exit 0/1
python -m aircontrol --version       print the version
python -m aircontrol --camera 1      use camera index 1 for this run
python -m aircontrol --config PATH   use a specific config.json
python -m aircontrol --debug         verbose logging
python -m aircontrol --no-hotkeys    do not register global hotkeys
```

## 4. Configuration and data

| Path | Contents |
| --- | --- |
| `%APPDATA%\AirControl\config.json` | settings (camera, recognition, air mouse, safety) |
| `%APPDATA%\AirControl\aircontrol.db` | calibration, bindings, sessions, practice history |
| `%APPDATA%\AirControl\logs\aircontrol.log` | rotating log, 2 MB × 3 |

Optional environment overrides (none are required):

```
AIRCONTROL_DATA_DIR   override the data directory
AIRCONTROL_CAMERA     camera device index
AIRCONTROL_DB         database path
AIRCONTROL_MODEL      path to hand_landmarker.task
AIRCONTROL_LOG_LEVEL  DEBUG | INFO | WARNING | ERROR
```

## 5. Building the Windows executable

The binary is produced by CI or on a Windows machine; it cannot be built on
Linux.

```bat
pip install -e ".[dev]" pyinstaller
pytest -q
pyinstaller packaging\aircontrol.spec --noconfirm
dist\AirControl\AirControl.exe --selftest
dist\AirControl\AirControl.exe --version
iscc packaging\installer.iss
```

Expected artefacts:

- `dist\AirControl\` — one-dir build (`AirControl.exe` + `_internal\`)
- `dist\AirControl-debug\` — same code with a console window, for bug reports
- `dist\AirControl-Setup-1.0.1.exe` — installer

One-dir is deliberate: MediaPipe resolves native DLLs relative to the
executable, and one-file mode unpacks to a temporary directory on every
launch, which breaks that resolution and adds seconds of start-up.

CI: `.github/workflows/build-windows.yml` runs the test suite, builds, runs
`--selftest` against the produced binary, verifies the model shipped inside
`_internal\aircontrol\resources\`, and builds the installer with Inno Setup.

## 6. Verifying a build

1. `AirControl.exe --selftest` prints `OK`.
2. Launch the app: the Dashboard should show *Camera active* once a frame
   arrives.
3. Open **Live Gesture Studio**, hold an open palm: the score for `OPEN_PALM`
   should climb above 0.80 and the gesture should appear in the panel.
4. **Air Mouse → Activate Air Mouse → Enable control**, then move two fingers.
5. Press **Ctrl+Alt+X**: control must switch off immediately and the pill in
   the header must read *Control off*.
6. Move the cursor to each corner and onto the taskbar: the whole desktop must
   be reachable. `python scripts\verify_screen_mapping.py` prints the pixel
   space AirControl is using, without moving the cursor.
