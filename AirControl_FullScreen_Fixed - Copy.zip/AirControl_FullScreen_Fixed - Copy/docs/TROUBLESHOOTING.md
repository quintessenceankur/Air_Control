# Troubleshooting

## The camera does not open

**Symptom:** the header pill stays grey, Live Gesture Studio says *Camera
unavailable*, and the log has `camera 0 could not be opened`.

1. Check Windows **Settings → Privacy & security → Camera**: *Camera access*
   on, *Let desktop apps access your camera* on.
2. Close other applications that hold the camera (Teams, Zoom, OBS, the
   Windows Camera app). Only one process can own it.
3. Try another device index: `python -m aircontrol --camera 1`, or change it in
   **Settings → Camera**.
4. Lower the resolution in Settings to 640×480 — some integrated cameras refuse
   1080p at 30 fps.
5. If it is an external camera, replug it and check Device Manager for a
   warning icon.

## The model file is missing

**Symptom:** `hand landmarker model not found at …`.

`aircontrol/resources/hand_landmarker.task` must exist (7 819 105 bytes). In a
packaged build it lives in `_internal\aircontrol\resources\`. Reinstall, or
point `AIRCONTROL_MODEL` at a copy.

## Gestures are recognised but the wrong one fires

- **Thumbs up/down confused with a fist.** The thumb must be clearly out of the
  fist. Fold the other four fingers fully and extend the thumb away from the
  index.
- **Open palm read as three fingers.** Straighten the ring finger completely,
  and keep the thumb away from the index — a thumb tucked against the palm
  lowers the palm score.
- **Pinch not detected.** Touch the thumb *tip* to the index *tip*; a pinch near
  the second knuckle does not close the distance enough. If your fingers are
  short, raise pinch sensitivity in calibration.
- **Nothing fires at all.** Hold the pose still for about 0.2 s. The engine
  requires five consecutive frames above the enter threshold.

## It fires when I am not trying to gesture

1. Turn control off when you are not using it — that is the intended workflow,
   and Ctrl+Alt+A does it instantly.
2. Raise **Settings → Recognition → Detection confidence**.
3. Keep the camera view to yourself: a hand in the background can trigger a
   gesture.
4. Check whether the *pause* pose (closed fist in Air Mouse) is what you want
   between gestures.

## The cursor cannot reach the edges or the taskbar

Fixed in 1.0.1: the mapping used Qt's logical geometry and `availableGeometry`,
so at 125% scaling it reached only 80% of the desktop, and the taskbar strip
was excluded even at 100%. If you are on an older build, update.

If it still happens:

1. Open **Air Mouse** and read the **Desktop coverage** card. It shows the
   pixel space in use, e.g. `1920 x 1080 pixels (x 0-1919, y 0-1079)
   [win32 GetSystemMetrics]`.
2. If those numbers are smaller than your real resolution, press
   **Re-detect desktop size**.
3. Run `python scripts\verify_screen_mapping.py` — it prints every coordinate
   space (Qt logical, Qt physical, Win32 injector, virtual desktop) and the
   pixels each hand corner maps to, without moving the cursor.
4. Check **Cursor speed** and **Sensitivity**: they shape the response curve,
   never the reachable area, so they cannot cause this on a current build.
   A very large **Active area margin** only means you must move your hand
   further, not that the edge is unreachable.
5. If the numbers look right but the cursor still stops short, the injector is
   probably writing into a different space than the one reported — send the
   output of step 3 with a bug report.

## The cursor is jittery or overshoots

- Raise **Smoothing** on the Air Mouse page (it lowers the One Euro cutoff).
- Increase the **dead zone** if the pointer creeps while your hand is still.
- Lower **Cursor speed** or **Sensitivity** if small movements cross the screen.
- Reduce the **active area margin** if you cannot reach the screen edges.
- Poor lighting increases landmark jitter more than anything else; light your
  hand from the front.

## Media keys do nothing

Some applications do not respond to system media keys (a browser tab that is
not the active media session, for example). Test with Windows Media Player or
Spotify first. Volume keys are handled by Windows itself and should always
work; if they do not, the backend is not loaded — check the log for
`desktop automation unavailable`.

## Slide keys go to the wrong window

Set the **Window guard** on the Presentation page (for example `PowerPoint`).
Without a guard, AirControl sends keys to whatever is focused.

## Hotkeys do not respond

- Another application may already own Ctrl+Alt+A or Ctrl+Alt+X; change them in
  `%APPDATA%\AirControl\config.json` (`safety.toggle_hotkey`,
  `safety.emergency_hotkey`) and restart.
- Hotkeys need the desktop backend (`pynput`). If the log says the backend is
  unavailable, the buttons in the window still work.

## The window is slow or the preview stutters

- Lower **Settings → Camera → Resolution**.
- Lower the preview rate (`ui.preview_fps` in `config.json`, default 30).
- Turn off the skeleton overlay; drawing 21 landmarks per hand per frame is
  cheap but not free.
- Close other camera applications.

## "Gesture control off" will not stay on

The manager disables itself on: emergency stop, mode change, and application
shutdown. Enabling is always explicit. If it disables itself repeatedly, check
the log for `emergency stop engaged` — something is calling it, and the most
likely cause is the hotkey firing from a stuck key.

## Windows antivirus flags the executable

The installer is unsigned unless the owner signs it in CI. SmartScreen shows
"More info → Run anyway". Signing with a code-signing certificate removes the
warning; see the optional signing step in
`.github/workflows/build-windows.yml`.

## Reset everything

**Settings → Data → Restore defaults**, or delete `%APPDATA%\AirControl`.
Deleting the folder loses calibration, mappings and history but nothing else.

## Collecting information for a bug report

1. `AirControl.exe --selftest` output.
2. `%APPDATA%\AirControl\logs\aircontrol.log`.
3. What you were doing, which controller was active, and whether the pill read
   *Control on*.
4. If recognition is involved: the gesture scores shown in Live Gesture Studio
   at the moment it misfired.
