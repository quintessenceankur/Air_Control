# Delivery report

AirControl rebuilt from scratch as `AirControl_Rebuilt`. The original files
were read as a reference and left untouched.

---

## 1. Features implemented

**Recognition (the priority)**

- MediaPipe Tasks HandLandmarker, VIDEO mode, up to two hands, monotonic
  timestamps, injectable device factory, explicit `CameraError` / `DetectorError`.
- Scale-, translation- and handedness-invariant landmark normalisation.
- Per-finger extension from two independent evidence sources, normalised pinch
  ratio, finger spread, palm roll, palm facing (diagnostic), fingertip pointer,
  windowed hand motion.
- Seven gesture scores (0..1) as pure functions, combined with geometric means
  and gated thumb evidence.
- Engine: EMA smoothing, per-gesture enter/exit hysteresis, frame-counted
  dwell, one event per activation, release count, per-gesture cooldown that
  survives a one-frame dropout, immediate idle on tracking loss, optional ML
  blend.
- Replayable from JSONL fixtures with an injected clock; 20 fixtures.

**Controllers**

- Air Mouse: fingertip cursor with active-region mapping, One Euro / EMA / no
  smoothing, dead zone, click-vs-drag discrimination, right click, velocity
  scroll with rate limiting, latched pause.
- Media: six media actions with a per-action guard interval.
- Presentation: slide navigation with an optional foreground-window guard.
- Manager: one active mode, explicit enable, emergency stop, action listener.

**Application**

- Nine screens: Dashboard, Live Gesture Studio, Air Mouse, Media, Presentation,
  Training Arena, Custom Gesture Studio, Analytics, Settings.
- Dark themed component library (cards, stat tiles, pills, meters, sparkline,
  sliders, toggle rows, gesture chips).
- Camera loop on a `QThread`; UI never blocks; preview throttled independently.
- Training Arena records real hit rates (and says it is not training a model).
- Custom Gesture Studio remaps any gesture to any action for either controller.

**Data and services**

- SQLite (WAL) with migrations: settings, calibration profiles, bindings,
  sessions, gesture events, practice attempts, plus backup.
- Analytics: totals, per-gesture usage, daily activity, per-gesture practice
  accuracy, mean confidence.
- Calibration profiles that scale thresholds and cursor gain.
- Buffered session logging so the video thread never blocks on disk.
- Safety: enable/disable, global hotkeys, emergency stop, mode gating.

**ML (optional, off by default)**

- Parametric hand model, labelled dataset builder, numpy softmax regression,
  JSON artifact, inference adapter, metrics module.

---

## 2. Files and modules created

248 files, ~11 200 lines of Python.

```
aircontrol/
  __main__.py, config.py, logging_setup.py
  core/          landmarks.py, features.py, smoothing.py, actions.py,
                 gestures/{spec,classifiers,engine,events}.py
  vision/        capture.py, detector.py, recorder.py
  automation/    base.py, keyboard.py, mouse.py, system.py, recorder.py
  controllers/   base.py, air_mouse.py, media.py, presentation.py, manager.py
  data/          db.py, models.py, repository.py, analytics.py
  services/      calibration.py, practice.py, session.py, safety.py
  ml/            synth.py, dataset.py, train.py, inference.py, metrics.py
  ui/            theme.py, components.py, overlay.py, camera_thread.py,
                 context.py, main_window.py, app.py,
                 pages/{base,dashboard,live_studio,air_mouse,media,presentation,
                        training,custom,analytics,settings,binding_editor}.py
  resources/     hand_landmarker.task, icons/{aircontrol.png,aircontrol.ico}
  models/        gesture_classifier.json
tests/           conftest.py, 17 unit files, 2 integration, 1 performance,
                 20 fixture clips + metadata
packaging/       aircontrol.spec, installer.iss, version_info.txt
scripts/         generate_fixtures.py, train_ml.py, evaluate_synthetic.py,
                 evaluate_webcam.py
docs/            PROJECT_AUDIT, ARCHITECTURE, INSTALLATION, USER_GUIDE,
                 TESTING_REPORT, EVALUATION, WEB_EVALUATION, TROUBLESHOOTING,
                 DEVELOPMENT_ROADMAP, LICENSE, evaluation JSON
.github/workflows/  test.yml, build-windows.yml
pyproject.toml, requirements.txt, README.md
```

---

## 3. Dependencies

Runtime: `numpy>=1.26,<3`, `opencv-python>=4.9,<6`, `mediapipe==0.10.14`,
`PySide6==6.7.3`, `pynput==1.7.7` (Windows only).
Dev: `pytest>=8`, `pytest-cov>=5`, `pyinstaller>=6.6`.

MediaPipe and PySide6 are pinned because both break across minor bumps. The
supplied `hand_landmarker.task` (7 819 105 bytes, MD5
`15318430ea3851670fe9914116a9cfad`) is the standard float16 hand landmarker and
is compatible with 0.10.14, so it ships unchanged.

---

## 4. Tests executed

```
pytest -q                                            456 passed, 3 deselected
pytest --cov=aircontrol --cov-report=term            88.29% (2297 statements)
pytest --cov=aircontrol.core --cov=aircontrol.data   94.21% (985 statements)
pytest -m performance -s -q                          3 passed
python -m aircontrol --selftest                      OK (exit 0)
python scripts/evaluate_synthetic.py                 completed, wrote EVALUATION.md
python scripts/train_ml.py                           completed, wrote artifact
python scripts/generate_fixtures.py                  20 fixtures written
```

---

## 5. Test results

456 passed, 0 failed, 3 deselected (performance, by design). Two warnings:
deprecation notices from `google.protobuf` under Python 3.12, unrelated to
this code.

Coverage gate (85% on `core/` + `data/`) met at 94.21%.

Detail per file, per requirement, and the full list of what could not run is in
[docs/TESTING_REPORT.md](TESTING_REPORT.md).

---

## 6. Recognition evaluation results

Synthetic held-out poses (1 440 samples per condition), from
`scripts/evaluate_synthetic.py`:

| Condition | Per-frame macro-F1 | Clip-level macro-F1 | Clip FP rate |
| --- | --- | --- | --- |
| nominal | 0.981 | 0.987 | 0.017 |
| far from camera | 0.873 | 0.994 | 0.017 |
| high landmark noise | 0.810 | 0.987 | 0.017 |
| rolled hand | 0.955 | 0.987 | 0.017 |

Weakest classes at nominal: `THUMBS_DOWN` (F1 0.87 before the thumb-gate fix,
0.98 after) and `CLOSED_FIST` (precision 0.78 before the gate, 0.94 after).
The gate that fixed them is documented in `core/gestures/classifiers.py`.

Optional ML classifier, held-out synthetic set: macro-F1 0.997. **This is not
evidence of real-world quality** — training and test data come from the same
parametric hand model. It is off by default.

**No real-world accuracy figure exists for this build.** There was no camera.
`docs/WEB_EVALUATION.md` states this and gives the recording workflow.

---

## 7. Performance measurements

| Measurement | Result (this container) |
| --- | --- |
| `GestureEngine.update` | 903 frames/s, 1.108 ms/frame |
| Feature extraction | 0.754 ms/call |
| Air-mouse tick with One Euro | 0.015 ms |

MediaPipe inference and camera capture dominate in practice and were not
measurable without hardware. No numbers are claimed for the packaged Windows
build.

---

## 8. Features not fully verified

| Item | Status |
| --- | --- |
| Live webcam capture | Code complete, exercised only with a fake device in tests |
| Real cursor/key injection | `pynput` backends complete, never executed (Linux, no desktop) |
| Global hotkeys | Registration tested with an injected backend; real listener untested |
| Windows `.exe` and installer | Spec, ISS and CI written; **binary not built** |
| Windows camera permission flow | Untested |
| Real-world recognition accuracy | Unmeasured — needs the owner's webcam |
| MediaPipe inference latency | Unmeasured |
| Presentation window focus (`ctypes`) | Windows-only path, unexercised |

---

## 9. Known bugs and limitations

1. Recognition thresholds were tuned against a synthetic hand; expect to adjust
   them once real clips exist.
2. `THUMBS_UP`/`THUMBS_DOWN` lose accuracy when the hand is rolled far from
   vertical, because direction is measured in image space.
3. A hand holding a mug or resting in a fist-shaped pose will fire
   `CLOSED_FIST`. Mitigations are mode gating, the pause pose and the
   emergency stop; the geometry cannot distinguish the two.
4. One hand is classified per frame (the nearer one); no two-handed gesture
   exists in the vocabulary.
5. The ML classifier is trained on synthetic data and disabled by default.
6. `pynput` is not installed on Linux (it needs `evdev`), so the app runs
   there with all actions suppressed — by design.
7. The Settings "restore defaults" path resets configuration and user data but
   requires a restart to re-open the camera with new settings.
8. `PresentationPage._apply_guard` persists only the config file, not the guard
   string itself; the guard is reapplied per session.

---

## 10. Running the application

Windows release: install `AirControl-Setup-1.0.1.exe`, launch **AirControl**,
allow camera access, then **Air Mouse → Activate Air Mouse → Enable control**.

From source:

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -e ".[dev]"
python -m aircontrol --selftest
python -m aircontrol
```

Stop everything instantly with **Ctrl+Alt+X**. Toggle control with
**Ctrl+Alt+A**.

---

## 11. Building the Windows executable

On Windows (CI does this in `.github/workflows/build-windows.yml`):

```bat
pip install -e ".[dev]" pyinstaller
pytest -q
pyinstaller packaging\aircontrol.spec --noconfirm
dist\AirControl\AirControl.exe --selftest
dist\AirControl\AirControl.exe --version
iscc packaging\installer.iss
```

Artefacts: `dist\AirControl\` (one-dir), `dist\AirControl-debug\` (console
build for bug reports), `dist\AirControl-Setup-1.0.1.exe`.

The binary was **not** produced or verified in this environment: PyInstaller
cannot cross-compile a Windows executable from Linux. First-run checks for the
owner: antivirus/SmartScreen warning on the unsigned installer, the model
present in `_internal\aircontrol\resources\`, and camera permission granted.
