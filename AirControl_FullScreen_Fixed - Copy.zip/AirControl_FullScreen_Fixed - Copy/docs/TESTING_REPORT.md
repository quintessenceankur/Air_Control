# Testing report

Everything below was executed in the build environment (Debian 12, Python
3.12.13, no camera, no display, no Windows). Commands and results are quoted
as they came back.

## 1. What was run

```bash
pytest -q
# 456 passed, 3 deselected, 2 warnings in 49.75s

pytest -q --cov=aircontrol --cov-report=term
# 456 passed, 3 deselected — TOTAL 2455 statements, 267 missed, 89.12%

pytest -q --cov=aircontrol.core --cov=aircontrol.data --cov-report=term
# TOTAL 985 statements, 57 missed, 94.21%  (gate: 85%)

pytest -m performance -s -q
# 3 passed, 456 deselected
```

The three deselected tests are the performance measurements, which are
excluded from the default run because their thresholds depend on the machine.

## 2. Test inventory

| File | Tests | Covers |
| --- | --- | --- |
| `tests/unit/test_screen_mapping.py` | 73 | full-desktop mapping: corners at six resolutions, margin, gain/sensitivity, smoothing, dead zone, DPI 100/125/150/200%, bounds plumbing, settings propagation |
| `tests/unit/test_engine_replay.py` | 121 | every fixture × (events, determinism, smoothing-invariance, timestamp order, threshold, cooldown) |
| `tests/unit/test_classifiers.py` | 29 | per-gesture scores, argmax, negatives, scale/rotation invariance, thumb direction, pinch guard |
| `tests/unit/test_controllers.py` | 28 | air mouse pointer/click/drag/scroll/pause, media, presentation, manager safety gates |
| `tests/unit/test_config.py` | 23 | defaults, round-trip, corrupt files, validation, env overrides, frozen paths |
| `tests/unit/test_features.py` | 21 | extension, pinch ratio, spread, roll, pointer, motion tracker, feature vector |
| `tests/unit/test_ml.py` | 18 | metrics, dataset split, training, artifact round-trip, inference, engine blending |
| `tests/unit/test_repository.py` | 18 | schema, migrations, settings, profiles, bindings, sessions, events, analytics, backup, open failure (cross-platform) |
| `tests/unit/test_engine_state.py` | 17 | dwell, hysteresis, release, cooldown, switching, reset, two hands, ML blend |
| `tests/unit/test_spec_actions.py` | 16 | vocabulary integrity, binding completeness, validation errors |
| `tests/unit/test_landmarks.py` | 16 | normalisation, scale/translation/rotation invariance, degenerate input, smoothing |
| `tests/unit/test_services.py` | 15 | calibration, practice, session buffering, safety arming, hotkey registration |
| `tests/unit/test_ui_smoke.py` | 15 | all nine pages, state routing, emergency stop, overlay, camera worker, camera failure, Air Mouse settings → live controller, desktop coverage card |
| `tests/unit/test_smoothing.py` | 11 | EMA, One Euro, pointer filter strategies |
| `tests/unit/test_engine_tracking.py` | 11 | missing hand, low presence, partial landmarks, partial hold discard, dropout cooldown |
| `tests/integration/test_end_to_end.py` | 10 | landmarks → engine → manager → recorded OS calls, per mode |
| `tests/unit/test_capture.py` | 8 | camera open failure, mirroring, read failures, idempotent close |
| `tests/unit/test_detector.py` | 6 | real MediaPipe model: load, blank frame, timestamp monotonicity, missing model |
| **Total** | **456** | |

20 fixture files drive the replay tests: 7 gesture holds, 3 far-from-camera
holds, 2 transition clips, 1 tracking-loss clip, 5 negative poses, 1 no-hand
clip and 1 low-presence clip.

## 3. Requirements from the brief, and where each is tested

| Requirement | Test |
| --- | --- |
| Landmark processing | `test_landmarks.py`, `test_features.py` |
| Gesture classification | `test_classifiers.py` |
| Gesture stabilisation | `test_engine_state.py` |
| Synthetic landmark tests | all of the above; `ml/synth.py` |
| Gesture transitions | `test_engine_replay.py::transition_palm_pinch_palm`, `test_engine_state.py::test_switches_…` |
| No-hand detection | `test_engine_tracking.py`, `negative_no_hand` fixture |
| Pinch hysteresis | `test_engine_state.py::test_hysteresis_…`, `test_classifiers.py::test_pinch_…` |
| Air mouse state | `test_controllers.py` (click vs drag, pause latch, dead zone, scroll rate) |
| Controller integration | `tests/integration/test_end_to_end.py` |
| Database | `test_repository.py` |
| Configuration | `test_config.py` |
| UI smoke | `test_ui_smoke.py` (offscreen Qt) |
| Camera initialisation | `test_capture.py`, `test_ui_smoke.py::test_camera_worker_processes_frames…` |
| Camera failure | `test_capture.py::test_read_failure_…`, `test_ui_smoke.py::test_camera_worker_reports_a_missing_camera` |
| Application shutdown | `test_ui_smoke.py::test_close_event_stops_cleanly`, worker stop test |
| Performance | `tests/performance/test_performance.py` |

No test moves a real cursor or types a real key: every controller test uses
`RecordingExecutor`, and the UI test wires the same double into the manager.

## 4. Coverage

| Scope | Coverage |
| --- | --- |
| `aircontrol/core` + `aircontrol/data` (the gate) | **94.21%** |
| Whole package | **89.12%** |

Lowest-covered modules: `logging_setup.py` (0%, exercised only at process
start), `repository.py` (86%, mostly defensive error branches), `ml/metrics.py`
(89%). The gate applies to `core/` and `data/`; chasing a number on `ui/` or
`vision/` would mean testing Qt painting rather than behaviour.

## 5. Recognition evaluation

Measured by `python scripts/evaluate_synthetic.py` on held-out poses; full
tables in [EVALUATION.md](EVALUATION.md).

| Condition | Per-frame macro-F1 | Clip-level macro-F1 | Clip false-positive rate |
| --- | --- | --- | --- |
| nominal | 0.981 | 0.987 | 0.017 |
| far from camera | 0.873 | 0.994 | 0.017 |
| high landmark noise | 0.810 | 0.987 | 0.017 |
| rolled hand | 0.955 | 0.987 | 0.017 |

Clip level is the product-relevant number: the engine smooths landmarks and
requires a five-frame dwell, so an ambiguous frame usually resolves in
context. One negative clip in 60 fired a gesture at clip level — that is the
false-positive rate the design optimises, and it is not zero.

**These are synthetic results.** The generator is a parametric hand model, so
these figures describe separability of that model, not accuracy on a human
hand. No real-world figure exists for this build; see
[WEB_EVALUATION.md](WEB_EVALUATION.md) for the recording workflow.

The engineering target was macro-F1 ≥ 0.95 on a representative validation set.
It is met on synthetic nominal and clip-level data and **not** met per-frame
under the two stress conditions (0.873 far, 0.810 noisy). Those are reported
as measured, not rounded up.

## 6. Performance

Measured with `pytest -m performance -s -q` on this machine (containerised,
shared CPU — treat as a lower bound for a laptop):

| Measurement | Result |
| --- | --- |
| `GestureEngine.update` | 903 frames/s (1.108 ms/frame) |
| Feature extraction | 0.754 ms/call |
| Air-mouse tick (One Euro) | 0.015 ms |

Camera capture and MediaPipe inference dominate real-world frame cost and were
not measurable without a camera. On a typical laptop, MediaPipe hand
landmarking at 720p runs in the 15–30 ms range, which is why the pipeline is
structured to keep the UI off that path rather than to make inference faster.

No benchmark numbers are quoted for the packaged Windows build: it was not
built here.

## 7. What could not be tested here, and how to verify it

| Not tested | Why | How to verify |
| --- | --- | --- |
| Live camera capture | no camera device | run `python -m aircontrol`, confirm *Camera active* and a preview |
| Real key/mouse injection | no desktop, `pynput` not installed (Linux needs `evdev`) | on Windows, activate Air Mouse and move; watch the cursor |
| Global hotkeys | `pynput` global listeners are Windows-only | press Ctrl+Alt+A and Ctrl+Alt+X |
| Windows camera permission flow | no Windows | first launch prompt; Settings → Privacy → Camera |
| Windows `.exe` and installer | cannot build a Windows binary on Linux | `pyinstaller packaging\aircontrol.iss` steps in INSTALLATION.md §5 |
| Real-world accuracy | needs a human hand | `python scripts/evaluate_webcam.py --record …` then rerun without `--record` |
| MediaPipe inference timing | no camera, no GPU | check the fps readout in Live Gesture Studio |

## 8. Manual smoke checklist (Windows)

1. `AirControl.exe --selftest` → `OK`.
2. Dashboard shows *Camera active*.
3. Live Gesture Studio: open palm passes 0.80 and appears as the recognised gesture.
4. Air Mouse: two fingers move the cursor; quick pinch clicks; long pinch drags and drops.
5. Media: thumbs up raises the volume exactly once while held for two seconds.
6. Presentation: two fingers advance a slide in PowerPoint.
7. Ctrl+Alt+X stops everything; the header pill reads *Control off*.
8. Close the window: no orphan process, camera light goes out.
