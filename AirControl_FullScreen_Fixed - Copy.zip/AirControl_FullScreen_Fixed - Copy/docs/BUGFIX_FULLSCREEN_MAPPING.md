# Bug fix: the air mouse could not reach the whole desktop

Status: fixed, tested on Linux. **Windows behaviour is not verified by the
author** — no Windows machine was available. A one-command check for the
owner's machine is provided at the end.

## Symptom

The cursor moved correctly but a margin of the desktop was unreachable,
worst at the bottom edge and the taskbar. Lowering **Active area margin** to
3% changed nothing.

Reported environment: Windows 11, Python 3.11.9, Qt geometry 1536x864, Qt
available geometry 1536x816, device pixel ratio 1.25, pynput backend. A direct
pynput test reaching `(1535, 863)` did reach the physical corner.

## Root cause

Not one bug but three, all confirmed by reading and running the shipped code.
The taskbar was simply the part of the screen that all three cut off first.

### 1. Qt *logical* geometry was used as the cursor space

`aircontrol/ui/app.py` did:

```python
screen = QGuiApplication.primaryScreen()
size = (screen.availableGeometry().width(), screen.availableGeometry().height())
manager = ControllerManager(..., screen_size=size)
```

`QScreen.geometry()` is in **logical** pixels. At 125% scaling a 1920x1080
desktop reports 1536x864. The controller clamped its output to
`(width - 1, height - 1)` in that space, and the injector wrote those numbers
as **device** pixels — so the cursor could only reach 80% of the width and 80%
of the height.

Measured with the shipped code:

| injector space | old bottom-right | reachable |
| --- | --- | --- |
| 1920x1080 (DPI-aware process) | (1535, 863) | 80% x 80% |
| 1536x864 (DPI-virtualised process) | (1535, 815) | 100% x 94% |

Both rows lose the bottom band, which is where the taskbar lives. That is why
the symptom pointed at the taskbar.

### 2. `availableGeometry()` excludes the taskbar by definition

Even in the DPI-virtualised case above, `availableGeometry` is 1536x**816** —
48 logical pixels shorter than the screen. The taskbar strip was excluded from
the mapping before any scaling was applied. The air mouse must use the *full*
screen, never the available area.

### 3. `gain * sensitivity` shrank the range instead of shaping the response

```python
scale = max(0.05, self.config.gain * self.config.sensitivity)
nx = 0.5 + (nx - 0.5) * scale      # range shrinks about the centre
```

With the cursor-speed slider below 100%, the outer desktop became
unreachable *by design*: at gain 0.5 the corner mapped to 60% of the screen.
Nothing in the UI said so.

### 4. Two propagation bugs that hid the problem

- `PointerFilter` was built once in `__init__` from `min_cutoff`/`beta`, so
  changing **Smoothing** and pressing Apply did nothing until restart.
- `screen_size` was captured at construction, so a resolution or scaling change
  (or a wrong initial value) persisted for the life of the process.

### 5. `MouseExecutor.screen_size()` returned the cursor position

```python
return tuple(Controller().position)   # a point, not a size
```

Unused by the app, so it was not the cause of this symptom, but it is wrong and
would have clamped any future caller to a single pixel. Fixed.

## The fix

### `aircontrol/automation/screen.py` (new)

`ScreenBounds` — a validated pixel rectangle with `max_x`/`max_y`, `clamp()`
and a `source` label so the log says where the numbers came from.

The space is resolved in this order:

1. **Win32 `GetSystemMetrics(SM_CXSCREEN/SM_CYSCREEN)`.** Windows virtualises
   these metrics in exactly the same way as `SetCursorPos`, for both DPI-aware
   and DPI-unaware processes, so the queried size is always the space the
   injector writes to. This is why the fix does not need to know the process
   DPI awareness — the ambiguity in the report does not affect the answer.
2. **Qt geometry x `devicePixelRatio`** as a fallback for platforms without
   Win32 (development on Linux, where actions are suppressed anyway).
3. A logged 1920x1080 default if neither works.

`describe_environment()` logs every space involved (Qt logical, Qt physical,
Win32 injector, virtual desktop) so a future report needs no guessing.
Multi-monitor is detected and warned about: AirControl maps the **primary**
monitor only.

### `aircontrol/controllers/air_mouse.py`

- Mapping is now: crop the frame by `active_region` → apply a **signed power
  response curve** from `gain * sensitivity` → scale to `[0, width-1]` of the
  resolved bounds. The curve pins 0→0, 0.5→0.5 and 1→1, so **no gain setting
  can make an edge unreachable**; it only changes how far a mid-range hand
  movement travels. Gain still means "cursor speed" to the user.
- Edge snapping: when the mapped target is a boundary pixel, the filtered value
  is snapped onto it within 2 px (`EDGE_SNAP_PX`), which closes the asymptotic
  gap the One Euro filter and the dead zone would otherwise leave. The dead
  zone keeps working along an edge (jitter is still suppressed once the cursor
  is on the boundary) and is bypassed only while a requested boundary is still
  unreached.
- Floating-point near-misses (`0.9999999999999999` from `(1-0.3-0.3)/0.4`) are
  pinned to exact 0/1, so the last pixel is exactly `width - 1`.
- `set_screen_bounds()` re-targets and clamps the cursor.
- `apply_config()` adopts new settings **and rebuilds the pointer filter**.

### `aircontrol/controllers/manager.py`

`screen_bounds` property, `set_screen_bounds()`, `apply_air_mouse_config()`,
and bounds plumbed into the controller (a plain `(w, h)` tuple is still
accepted for compatibility).

### `aircontrol/ui/app.py`

Resolves the injector space at start-up, logs the diagnostics, passes the
bounds to the manager, and supplies a `screen_resolver` so the UI can re-detect.

### `aircontrol/ui/pages/air_mouse.py`

- New **Desktop coverage** card showing the live bounds
  (`1536 x 864 pixels (x 0-1535, y 0-863) [win32 GetSystemMetrics]`) and a
  **Re-detect desktop size** button.
- **Apply cursor settings** now builds a validated config copy, pushes it
  through `context.apply_air_mouse_config()` (so the filter is rebuilt) and
  saves it.

### `aircontrol/automation/mouse.py`

`screen_size()` asks Win32 for the real metrics instead of returning the cursor
position.

## What is preserved

Gesture recognition, click/drag/scroll, the pause pose, mode gating, the
emergency stop and hotkeys are untouched; the mapping is the only behaviour
that changed, plus the settings propagation path. No click gesture is enabled
by the tests — every test drives `RecordingExecutor`.

## Regression tests

`tests/unit/test_screen_mapping.py` (73 tests) plus four UI tests in
`tests/unit/test_ui_smoke.py`:

- `(0,0)` → top-left and `(1,1)` → bottom-right, at 1000x500, 1280x720,
  1536x864, 1920x1080, 2560x1440 and 3840x2160.
- All four corners reachable through the full tick path (filter + dead zone).
- The last row/column is addressable (pixel 863, not 815).
- Margin 0%, 3%, 18%, 30%: the screen edge is reached at `margin`, and beyond
  the margin still clamps to the edge.
- Gain and sensitivity at 0.2/0.5/1.0/1.5/3.0 (all combinations): boundaries
  always reachable; the mid-range response still changes.
- Smoothing (`one_euro`, `ema`, `none`) never permanently restricts the range;
  a 25 px dead zone still reaches the corner; jitter is still suppressed
  mid-screen and along an edge.
- Screen dimensions reach the controller via tuple, `ScreenBounds`,
  `set_screen_bounds`, and the manager; non-zero origins are honoured.
- `apply_config` rebuilds the filter and switches strategy; the manager
  propagates it; the Air Mouse page propagates it and shows the bounds.
- DPI: logical 1920x1080 at DPR 1.0/1.25/1.5/2.0 → physical 1920/2400/2880/3840;
  the reporter's 1536x864 logical at 1.25 → 1920x1080; `availableGeometry` is
  never used for mapping; Win32 wins over Qt; fallbacks behave.
- `MouseExecutor.screen_size()` returns a size, not a cursor position.

## Results

```
pytest -q                                       456 passed, 3 deselected
pytest -q --cov=aircontrol --cov-report=term    89.12% overall
pytest -q --cov=aircontrol.core --cov=aircontrol.data   94.21%
```

## Windows verification — not performed by the author

There was no Windows machine in the build environment, so nothing below is
claimed as verified. The owner can confirm in one command:

```bat
python scripts\verify_screen_mapping.py
```

Expected on the reporter's machine (1920x1080 at 125%):

```
win32 metrics : 1920x1080 at (0,0) [win32 GetSystemMetrics]
qt physical   : 1920x1080 at (0,0) [qt geometry x1.25 dpr]
chosen space  : 1920x1080 at (0,0) [win32 GetSystemMetrics]
addressable   : x 0-1919, y 0-1079
corners reachable: YES
```

If the injector really is DPI-virtualised (which the reported pynput test at
`(1535, 863)` suggests), the Win32 line will read `1536x864`, `addressable`
`x 0-1535, y 0-863`, and the corners are still reachable — the fix works in
both cases, which is the point of asking Win32 rather than assuming.

Then, in the app: **Air Mouse** should show the same numbers in the *Desktop
coverage* card; move a two-finger pose to the bottom-right and confirm the
cursor sits on the last pixel with the taskbar visible; check the log line
`air mouse maps the full desktop: ...` in `%APPDATA%\AirControl\logs\aircontrol.log`.

## Known follow-ups (not part of this fix)

- Multi-monitor: the primary monitor is mapped; spanning the virtual desktop
  would need `SM_XVIRTUALSCREEN`-based bounds and is deliberately out of scope.
- `CalibrationService.apply_to()` multiplies `air_mouse.gain` by
  `cursor_speed` on every launch; with the default profile (1.0) it is a no-op,
  but a non-default profile compounds across restarts. Fixing it means storing
  a base gain rather than mutating the loaded one.
